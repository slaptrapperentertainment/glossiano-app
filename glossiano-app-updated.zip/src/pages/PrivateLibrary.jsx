import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Lock, Play, Music } from 'lucide-react';
import TrackCard from '@/components/music/TrackCard';

export default function PrivateLibrary() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);

        // Auto-grant premium membership to app owner
        if (userData?.email === 'slaptrapperentertainment@gmail.com') {
          await base44.functions.invoke('grantOwnerMembership', {});
        }
      } catch (err) {
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUser();
  }, []);

  const { data: subscription } = useQuery({
    queryKey: ['membershipSubscription', user?.email],
    queryFn: () => base44.entities.MembershipSubscription.filter(
      { fan_email: user?.email, status: 'active' },
      '-created_date',
      1
    ),
    enabled: !!user?.email
  });

  const { data: memberTracks = [] } = useQuery({
    queryKey: ['memberOnlyTracks'],
    queryFn: () => base44.entities.Track.filter({ members_only: true })
  });

  const isMember = subscription && subscription.length > 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-black flex items-center justify-center">
        <div className="animate-pulse">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-black p-6">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="text-center">
              <Lock className="h-12 w-12 mx-auto mb-4 text-amber-500" />
              <CardTitle className="text-2xl">Private Library</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <p className="text-gray-300">
                Sign in to access exclusive Glossiano tracks available to members only.
              </p>
              <Button
                onClick={() => base44.auth.redirectToLogin()}
                className="bg-amber-500 hover:bg-amber-600"
              >
                Sign In to Access
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!isMember) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-black p-6">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="text-center">
              <Lock className="h-12 w-12 mx-auto mb-4 text-amber-500" />
              <CardTitle className="text-2xl">Members Only</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <p className="text-gray-300">
                Join as a member to unlock exclusive Glossiano tracks and premium content.
              </p>
              <div className="bg-slate-700/50 rounded-lg p-4 text-left space-y-2 text-sm text-gray-200">
                <p className="font-semibold text-amber-400">Member Benefits:</p>
                <ul className="space-y-1">
                  <li>✓ Access to exclusive private music library</li>
                  <li>✓ Stream high-quality tracks</li>
                  <li>✓ Early access to new releases</li>
                  <li>✓ Behind-the-scenes content</li>
                </ul>
              </div>
              <Button
                onClick={() => base44.auth.redirectToLogin(`/memberships`)}
                className="bg-amber-500 hover:bg-amber-600 w-full"
              >
                Explore Memberships
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-black p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Private Library</h1>
          <p className="text-gray-400">Exclusive Glossiano tracks for members</p>
        </div>

        {memberTracks.length === 0 ? (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="text-center py-12">
              <Music className="h-12 w-12 mx-auto mb-4 text-gray-600" />
              <p className="text-gray-400">No exclusive tracks available yet</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {memberTracks.map((track) => (
              <TrackCard
                key={track.id}
                track={track}
                isMemberOnly={true}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}