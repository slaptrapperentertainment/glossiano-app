import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Music2, Heart, Users, ExternalLink, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function ArtistDetail() {
  const [isFollowing, setIsFollowing] = useState(false);
  const [isLoadingFollow, setIsLoadingFollow] = useState(false);
  const navigate = useNavigate();

  const urlParams = new URLSearchParams(window.location.search);
  const artistId = urlParams.get('id');

  const { data: artist, isLoading: artistLoading } = useQuery({
    queryKey: ['artist', artistId],
    queryFn: () => artistId ? base44.entities.Artist.get(artistId) : null,
    enabled: !!artistId
  });

  const { data: tracks = [] } = useQuery({
    queryKey: ['artist-tracks', artist?.name],
    queryFn: () => artist ? base44.entities.Track.filter({ artist: artist.name }, '-created_date') : [],
    enabled: !!artist
  });

  const handleFollowToggle = async () => {
    if (!artist) return;

    setIsLoadingFollow(true);
    try {
      const user = await base44.auth.me();
      if (!user) {
        toast.error('Please log in to follow artists');
        return;
      }

      if (isFollowing) {
        // Unfollow
        const existing = await base44.entities.Follower.filter({
          fan_email: user.email,
          artist_name: artist.name
        });
        if (existing.length > 0) {
          await base44.entities.Follower.delete(existing[0].id);
        }
        setIsFollowing(false);
        toast.success(`Unfollowed ${artist.name}`);
      } else {
        // Follow
        await base44.entities.Follower.create({
          fan_email: user.email,
          fan_name: user.full_name || 'Fan',
          artist_name: artist.name,
          is_following: true,
          notification_preference: 'both'
        });
        setIsFollowing(true);
        toast.success(`Following ${artist.name} - get notified about new releases!`);
      }
    } catch (error) {
      toast.error('Failed to update follow status');
    } finally {
      setIsLoadingFollow(false);
    }
  };

  if (artistLoading) {
    return <div className="min-h-screen bg-black flex items-center justify-center text-white">Loading...</div>;
  }

  if (!artist) {
    return <div className="min-h-screen bg-black flex items-center justify-center text-white">Artist not found</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black">
      {/* Back Button */}
      <div className="pt-6 px-4">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-yellow-400 hover:text-yellow-300 transition"
        >
          <ArrowLeft className="h-5 w-5" />
          Go Back
        </button>
      </div>

      {/* Banner */}
      <div className="relative h-64 md:h-96 overflow-hidden">
        <img
          src={artist.banner || artist.image}
          alt={artist.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>

        {/* Artist Info Overlay */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute bottom-0 left-0 right-0 p-6 z-10"
        >
          <div className="flex gap-6 items-end">
            <img
              src={artist.image}
              alt={artist.name}
              className="w-32 h-32 rounded-lg object-cover border-4 border-yellow-500/50 shadow-2xl"
            />
            <div className="flex-1 pb-2">
              <h1 className="text-4xl md:text-6xl font-black text-white mb-2">{artist.name}</h1>
              {artist.genre && (
                <p className="text-yellow-400 text-lg font-semibold mb-3">{artist.genre}</p>
              )}
              <div className="flex gap-6 text-gray-300 text-sm">
                {artist.follower_count > 0 && (
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span>{artist.follower_count} followers</span>
                  </div>
                )}
                {artist.release_count > 0 && (
                  <div className="flex items-center gap-2">
                    <Music2 className="h-4 w-4" />
                    <span>{artist.release_count} tracks</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex gap-3 mb-12 flex-wrap"
        >
          <Button
            onClick={handleFollowToggle}
            disabled={isLoadingFollow}
            className={`px-8 py-3 font-bold rounded-full flex items-center gap-2 ${
              isFollowing
                ? 'bg-pink-600 hover:bg-pink-700 text-white'
                : 'bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white'
            }`}
          >
            <Heart className={`h-5 w-5 ${isFollowing ? 'fill-current' : ''}`} />
            {isFollowing ? 'Following' : 'Follow'}
          </Button>

          {artist.spotify_url && (
            <a href={artist.spotify_url} target="_blank" rel="noopener noreferrer">
              <Button className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-full font-bold flex items-center gap-2">
                <Music2 className="h-5 w-5" />
                Spotify
                <ExternalLink className="h-4 w-4" />
              </Button>
            </a>
          )}

          {artist.apple_music_url && (
            <a href={artist.apple_music_url} target="_blank" rel="noopener noreferrer">
              <Button className="bg-gray-900 hover:bg-gray-800 text-white px-8 py-3 rounded-full font-bold border border-gray-700 flex items-center gap-2">
                <Music2 className="h-5 w-5" />
                Apple Music
                <ExternalLink className="h-4 w-4" />
              </Button>
            </a>
          )}

          {artist.instagram_url && (
            <a href={artist.instagram_url} target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white px-6 py-3 rounded-full font-bold">
                Instagram
                <ExternalLink className="h-4 w-4 ml-2" />
              </Button>
            </a>
          )}
        </motion.div>

        {/* Bio */}
        {artist.bio && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-12"
          >
            <h2 className="text-2xl font-bold text-white mb-4">About</h2>
            <p className="text-gray-300 text-lg leading-relaxed">{artist.bio}</p>
          </motion.div>
        )}

        {/* Discography */}
        {tracks.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h2 className="text-2xl font-bold text-white mb-6">Discography</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {tracks.map((track) => (
                <Card key={track.id} className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30 hover:border-yellow-500/60 transition">
                  <CardContent className="p-4">
                    {track.cover_image && (
                      <img
                        src={track.cover_image}
                        alt={track.title}
                        className="w-full aspect-square object-cover rounded-lg mb-4"
                      />
                    )}
                    <h4 className="text-white font-semibold line-clamp-2">{track.title}</h4>
                    {track.album && (
                      <p className="text-gray-400 text-sm mt-1">{track.album}</p>
                    )}
                    {track.year && (
                      <p className="text-gray-500 text-xs mt-1">{track.year}</p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}