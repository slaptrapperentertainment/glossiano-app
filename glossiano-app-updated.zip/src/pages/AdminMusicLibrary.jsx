import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import AdminTracks from '@/pages/AdminTracks';
import { ArrowLeft } from 'lucide-react';

export default function AdminMusicLibrary() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const userData = await base44.auth.me();
        if (userData?.email === 'slaptrapperentertainment@gmail.com') {
          setUser(userData);
        } else {
          toast.error('Access denied. Admin only.');
          navigate(createPageUrl('Home'));
        }
      } catch (err) {
        navigate(createPageUrl('Home'));
      } finally {
        setLoading(false);
      }
    };
    checkAuth();
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-pulse text-white">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-950 to-black p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <Button
          onClick={() => navigate(createPageUrl('AdminDashboard'))}
          variant="ghost"
          className="text-gray-400 hover:text-white mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>

        <AdminTracks />
      </div>
    </div>
  );
}