import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Filter, ArrowRight, Users } from 'lucide-react';
import ArtistCard from '@/components/artist/ArtistCard';

export default function Artists() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');
  const [sortBy, setSortBy] = useState('followers');

  const { data: artists = [] } = useQuery({
    queryKey: ['all-artists'],
    queryFn: () => base44.entities.Artist.list('-follower_count', 100),
    initialData: []
  });

  const genres = ['all', ...new Set(artists.map(a => a.genre).filter(Boolean))];

  const filteredArtists = artists
    .filter(artist => {
      const matchesSearch = artist.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        artist.genre?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        artist.location?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesGenre = selectedGenre === 'all' || artist.genre === selectedGenre;
      return matchesSearch && matchesGenre;
    })
    .sort((a, b) => {
      if (sortBy === 'followers') return (b.follower_count || 0) - (a.follower_count || 0);
      if (sortBy === 'streams') return (b.total_streams || 0) - (a.total_streams || 0);
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      return 0;
    });

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black py-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4">
            Discover Artists
          </h1>
          <p className="text-gray-300 text-lg mb-8">
            Browse our collection of talented artists, follow your favorites, and get updates on new releases
          </p>

          {/* Search */}
          <div className="max-w-2xl mx-auto mb-6">
            <div className="relative">
              <Search className="absolute left-4 top-3 h-5 w-5 text-yellow-400" />
              <Input
                placeholder="Search artists, genres, or locations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 bg-black/50 border-yellow-500/30 text-white"
              />
            </div>
          </div>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex flex-wrap gap-4 items-center justify-between mb-8 bg-black/30 p-4 rounded-lg border border-yellow-500/20"
        >
          <div className="flex items-center gap-2 flex-wrap">
            <Filter className="h-4 w-4 text-yellow-400" />
            <span className="text-white text-sm font-medium">Genre:</span>
            <div className="flex flex-wrap gap-2">
              {genres.map(genre => (
                <Badge
                  key={genre}
                  onClick={() => setSelectedGenre(genre)}
                  className={`cursor-pointer ${
                    selectedGenre === genre
                      ? 'bg-gradient-to-r from-pink-600 to-yellow-500'
                      : 'bg-black/50 hover:bg-black/70 border-yellow-500/30'
                  }`}
                >
                  {genre.charAt(0).toUpperCase() + genre.slice(1)}
                </Badge>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-white text-sm font-medium">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-black/50 border border-yellow-500/30 text-white rounded px-3 py-1 text-sm"
            >
              <option value="followers">Most Followers</option>
              <option value="streams">Most Streams</option>
              <option value="name">Name A-Z</option>
            </select>
          </div>
        </motion.div>

        {/* Artists Grid */}
        {filteredArtists.length === 0 ? (
          <div className="text-center py-20">
            <Users className="h-20 w-20 mx-auto mb-4 text-gray-600" />
            <p className="text-gray-400 text-lg mb-4">No artists found</p>
            <Button
              onClick={() => {
                setSearchQuery('');
                setSelectedGenre('all');
              }}
              variant="outline"
              className="border-yellow-500/30"
            >
              Clear Filters
            </Button>
          </div>
        ) : (
          <>
            <p className="text-gray-400 mb-6 text-sm">
              Showing {filteredArtists.length} artist{filteredArtists.length !== 1 ? 's' : ''}
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredArtists.map((artist, index) => (
                <ArtistCard key={artist.id} artist={artist} index={index} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}