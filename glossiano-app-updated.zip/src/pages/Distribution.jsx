import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Rocket, BarChart3, Music, Check, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import DistributionForm from '@/components/distribution/DistributionForm';
import DistributionDashboard from '@/components/distribution/DistributionDashboard';
import DistributionPricing from '@/components/distribution/DistributionPricing';
import ServicesShowcase from '@/components/distribution/ServicesShowcase';
import CompetitiveAdvantages from '@/components/distribution/CompetitiveAdvantages';
import PlaylistCuratorManager from '@/components/admin/PlaylistCuratorManager';
import DistributionHistory from '@/components/distribution/DistributionHistory';
import DistributionOnboarding from '@/components/distribution/DistributionOnboarding';

export default function Distribution() {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [trackData, setTrackData] = useState(null);
  const [showOnboarding, setShowOnboarding] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuthorization = async () => {
      try {
        const user = await base44.auth.me();
        if (user) {
          setIsAuthorized(true);
          // Get track data from sessionStorage if it exists
          const storedTrack = sessionStorage.getItem('distributionTrack');
          if (storedTrack) {
            setTrackData(JSON.parse(storedTrack));
            sessionStorage.removeItem('distributionTrack');
          }
        } else {
          navigate(createPageUrl('Home'));
        }
      } catch {
        navigate(createPageUrl('Home'));
      }
      setIsLoading(false);
    };
    checkAuthorization();
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black to-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-xl">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return null;
  }

  if (showOnboarding) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <DistributionOnboarding onStart={() => setShowOnboarding(false)} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black py-16 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4">
            MUSIC DISTRIBUTION
          </h1>
          <p className="text-gray-300 text-lg mb-8">
            Upload once. Distribute to all major streaming platforms. Keep 100% of your royalties.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-4 mb-12">
          <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Rocket className="h-5 w-5 text-yellow-400" />
                Unlimited Releases
              </CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300 text-sm">
              Distribute unlimited singles, EPs, and albums to all platforms
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Check className="h-5 w-5 text-yellow-400" />
                Keep 100% Royalties
              </CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300 text-sm">
              We don't take a cut. All streaming revenue goes directly to you
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-yellow-400" />
                Real-Time Analytics
              </CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300 text-sm">
              Track streams, earnings, and performance across all platforms
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="submit" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-black/50 border border-pink-500/30">
            <TabsTrigger value="submit" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Music className="h-4 w-4 mr-2" />
              Submit Release
            </TabsTrigger>
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <BarChart3 className="h-4 w-4 mr-2" />
              My Releases
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Music className="h-4 w-4 mr-2" />
              Distribution History
            </TabsTrigger>
            <TabsTrigger value="playlists" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Zap className="h-4 w-4 mr-2" />
              Playlist Pitching
            </TabsTrigger>
          </TabsList>

          <TabsContent value="submit" className="mt-6">
            <DistributionForm track={trackData} />
          </TabsContent>

          <TabsContent value="dashboard" className="mt-6">
            <DistributionDashboard />
          </TabsContent>

          <TabsContent value="history" className="mt-6">
            <DistributionHistory />
          </TabsContent>

          <TabsContent value="playlists" className="mt-6">
            <PlaylistCuratorManager />
          </TabsContent>
        </Tabs>

        <div className="mt-16">
          <CompetitiveAdvantages />
        </div>

        <DistributionPricing />
        
        <ServicesShowcase />
      </div>
    </div>
  );
}