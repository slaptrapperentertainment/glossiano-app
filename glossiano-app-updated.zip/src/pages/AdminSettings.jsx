import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Settings, Save, Link as LinkIcon, Music, Upload, Trash2, Palette, FileText } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

export default function AdminSettings() {
  const [paymentLink, setPaymentLink] = useState('');
  const [uploadingAudio, setUploadingAudio] = useState(false);
  const [audioUrls, setAudioUrls] = useState([]);
  const [storeName, setStoreName] = useState('');
  const [storeEmail, setStoreEmail] = useState('');
  const [storePhone, setStorePhone] = useState('');
  const [storeAddress, setStoreAddress] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [primaryColor, setPrimaryColor] = useState('#d97706');
  const [aboutUs, setAboutUs] = useState('');
  const queryClient = useQueryClient();

  const { data: settings = [], isLoading } = useQuery({
    queryKey: ['settings'],
    queryFn: () => base44.entities.Settings.list('', 1)
  });

  useEffect(() => {
    if (settings[0]) {
      setPaymentLink(settings[0].payment_link || '');
      setAudioUrls(settings[0].dj_audio_urls || []);
      setStoreName(settings[0].store_name || '');
      setStoreEmail(settings[0].store_email || '');
      setStorePhone(settings[0].store_phone || '');
      setStoreAddress(settings[0].store_address || '');
      setLogoUrl(settings[0].logo_url || '');
      setPrimaryColor(settings[0].primary_color || '#d97706');
      setAboutUs(settings[0].about_us || '');
    }
  }, [settings]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (settings[0]) {
        return base44.entities.Settings.update(settings[0].id, data);
      } else {
        return base44.entities.Settings.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['settings'] });
      toast.success('Configuración guardada exitosamente');
    },
    onError: () => {
      toast.error('Error al guardar la configuración');
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate({ 
      payment_link: paymentLink,
      dj_audio_urls: audioUrls,
      store_name: storeName,
      store_email: storeEmail,
      store_phone: storePhone,
      store_address: storeAddress,
      logo_url: logoUrl,
      primary_color: primaryColor,
      about_us: aboutUs
    });
  };

  const handleAudioUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      toast.error('Por favor selecciona un archivo de audio');
      return;
    }

    if (audioUrls.length >= 3) {
      toast.error('Máximo 3 archivos de audio permitidos');
      return;
    }

    const maxSize = 150 * 1024 * 1024; // 150MB
    if (file.size > maxSize) {
      toast.error('El archivo es muy grande. Máximo 150MB');
      return;
    }

    setUploadingAudio(true);
    toast.info('Subiendo archivo... esto puede tardar unos minutos');
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setAudioUrls([...audioUrls, file_url]);
      toast.success('Audio subido exitosamente');
    } catch (error) {
      console.error('Error uploading audio:', error);
      toast.error(`Error al subir el audio: ${error.message || 'Intenta con un archivo más pequeño o en formato MP3'}`);
    } finally {
      setUploadingAudio(false);
    }
  };

  const removeAudio = (index) => {
    setAudioUrls(audioUrls.filter((_, i) => i !== index));
    toast.success('Audio eliminado');
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Por favor selecciona una imagen');
      return;
    }

    setUploadingLogo(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setLogoUrl(file_url);
      toast.success('Logo subido exitosamente');
    } catch (error) {
      toast.error('Error al subir el logo');
    } finally {
      setUploadingLogo(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-4xl mx-auto px-4 md:px-6 py-8">
        <div className="flex items-center gap-3 mb-8">
          <Settings className="h-8 w-8 text-neutral-900" />
          <h1 className="text-3xl font-bold text-neutral-900">Configuración de la Tienda</h1>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-amber-600" />
                Información de la Tienda
              </CardTitle>
              <CardDescription>
                Configura el nombre, logo y datos de contacto de tu tienda
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="store_name">Nombre de la Tienda</Label>
                <Input
                  id="store_name"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="VINTAGE RECORDS"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="logo">Logotipo</Label>
                <Input
                  id="logo"
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  disabled={uploadingLogo}
                />
                {uploadingLogo && <p className="text-sm text-neutral-500">Subiendo logo...</p>}
                {logoUrl && (
                  <div className="mt-2">
                    <img src={logoUrl} alt="Logo" className="h-16 w-16 object-contain border rounded" />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="store_email">Email de Contacto</Label>
                <Input
                  id="store_email"
                  type="email"
                  value={storeEmail}
                  onChange={(e) => setStoreEmail(e.target.value)}
                  placeholder="contacto@vintagerecords.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="store_phone">Teléfono</Label>
                <Input
                  id="store_phone"
                  type="tel"
                  value={storePhone}
                  onChange={(e) => setStorePhone(e.target.value)}
                  placeholder="+1 234 567 8900"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="store_address">Dirección</Label>
                <Input
                  id="store_address"
                  value={storeAddress}
                  onChange={(e) => setStoreAddress(e.target.value)}
                  placeholder="123 Main St, City, Country"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="primary_color">Color Principal</Label>
                <div className="flex gap-2">
                  <Input
                    id="primary_color"
                    type="color"
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="w-20 h-10"
                  />
                  <Input
                    type="text"
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    placeholder="#d97706"
                    className="flex-1"
                  />
                </div>
                <p className="text-xs text-neutral-500">
                  Este color se usará en botones, enlaces y acentos
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="about_us">Sobre Nosotros</Label>
                <Textarea
                  id="about_us"
                  value={aboutUs}
                  onChange={(e) => setAboutUs(e.target.value)}
                  placeholder="Escribe la historia de tu tienda..."
                  rows={5}
                />
                <p className="text-xs text-neutral-500">
                  Este texto aparecerá en la sección Sobre Nosotros
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LinkIcon className="h-5 w-5 text-amber-600" />
                Link de Pago
              </CardTitle>
              <CardDescription>
                Configura el link de pago donde serán redirigidos los clientes al finalizar el checkout
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label htmlFor="payment_link">URL del Link de Pago</Label>
                <Input
                  id="payment_link"
                  type="url"
                  placeholder="https://checkout.stripe.com/..."
                  value={paymentLink}
                  onChange={(e) => setPaymentLink(e.target.value)}
                  className="font-mono text-sm"
                />
                <p className="text-sm text-neutral-500">
                  Puede ser un link de Stripe, PayPal, Mercado Pago, o cualquier otra plataforma de pago
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Music className="h-5 w-5 text-amber-600" />
                Audio DJ
              </CardTitle>
              <CardDescription>
                Sube un archivo MP3 para reproducir música de fondo en la tienda
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="audio_file">Archivos de Audio (MP3 - Max 150MB c/u, hasta 3 archivos)</Label>
                <div className="flex gap-2">
                  <Input
                    id="audio_file"
                    type="file"
                    accept="audio/*"
                    onChange={handleAudioUpload}
                    disabled={uploadingAudio || audioUrls.length >= 3}
                    className="flex-1"
                  />
                  {uploadingAudio && (
                    <Button disabled className="w-24">
                      <Upload className="mr-2 h-4 w-4 animate-pulse" />
                      Subiendo...
                    </Button>
                  )}
                </div>
                <p className="text-xs text-neutral-500">
                  Los audios se reproducirán aleatoriamente. {audioUrls.length}/3 archivos
                </p>
              </div>

              {audioUrls.length > 0 && (
                <div className="space-y-2">
                  {audioUrls.map((url, index) => (
                    <div key={index} className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Music className="h-4 w-4 text-green-600" />
                          <span className="text-sm font-medium text-green-900">Audio {index + 1}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeAudio(index)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <audio src={url} controls className="w-full" />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <h4 className="font-semibold text-amber-900 mb-2">💡 Sugerencia</h4>
            <p className="text-sm text-amber-800">
              Los detalles del pedido se guardarán localmente en el navegador del cliente. 
              Asegúrate de que tu plataforma de pago tenga un campo de notas o descripción 
              donde el cliente pueda incluir su información de pedido.
            </p>
          </div>

          <div className="flex justify-end">
            <Button 
              onClick={handleSubmit}
              className="bg-neutral-900 hover:bg-neutral-800"
              disabled={saveMutation.isPending}
            >
              <Save className="mr-2 h-4 w-4" />
              {saveMutation.isPending ? 'Guardando...' : 'Guardar Toda la Configuración'}
            </Button>
          </div>
        </div>

        {paymentLink && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Vista Previa</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-neutral-100 rounded p-4">
                <p className="text-sm text-neutral-600 mb-2">Link configurado:</p>
                <a 
                  href={paymentLink} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-amber-600 hover:text-amber-700 underline break-all"
                >
                  {paymentLink}
                </a>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}