import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Checkbox } from '@/components/ui/checkbox';
import { Search, SlidersHorizontal, X, Layers, Grid3x3 } from 'lucide-react';
import { motion } from 'framer-motion';
import ProductCard from '@/components/products/ProductCard';
import StackView from '@/components/catalog/StackView';

export default function Catalog() {
  const urlParams = new URLSearchParams(window.location.search);
  const initialCategory = urlParams.get('category') || '';
  const showSearch = urlParams.get('search') === 'true';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [selectedDecade, setSelectedDecade] = useState('');
  const [selectedConditions, setSelectedConditions] = useState([]);
  const [sortBy, setSortBy] = useState('newest');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [viewMode, setViewMode] = useState('stack'); // 'stack' or 'grid'

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list('-created_date', 200)
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: () => base44.entities.Category.list('display_order', 50)
  });

  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(p => 
        p.title?.toLowerCase().includes(query) ||
        p.artist_brand?.toLowerCase().includes(query) ||
        p.description?.toLowerCase().includes(query)
      );
    }

    if (selectedCategory) {
      result = result.filter(p => p.category === selectedCategory);
    }

    if (selectedDecade) {
      result = result.filter(p => p.decade === selectedDecade);
    }

    if (selectedConditions.length > 0) {
      result = result.filter(p => selectedConditions.includes(p.condition));
    }

    switch (sortBy) {
      case 'price_low':
        result.sort((a, b) => (a.price || 0) - (b.price || 0));
        break;
      case 'price_high':
        result.sort((a, b) => (b.price || 0) - (a.price || 0));
        break;
      case 'oldest':
        result.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        break;
      default:
        result.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }

    return result;
  }, [products, searchQuery, selectedCategory, selectedDecade, selectedConditions, sortBy]);

  const conditions = [
    { value: 'mint', label: 'Mint' },
    { value: 'near_mint', label: 'Near Mint' },
    { value: 'very_good', label: 'Very Good' },
    { value: 'good', label: 'Good' },
    { value: 'fair', label: 'Fair' }
  ];

  const decades = ['80s', '90s', '2000s', '2010s'];

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('');
    setSelectedDecade('');
    setSelectedConditions([]);
  };

  const activeFiltersCount = [
    selectedCategory,
    selectedDecade,
    selectedConditions.length > 0
  ].filter(Boolean).length;

  const FilterContent = () => (
    <div className="space-y-8">
      {/* Categories */}
      <div>
        <h4 className="text-xs uppercase tracking-widest text-neutral-500 mb-4">Category</h4>
        <div className="space-y-2">
          <button
            onClick={() => setSelectedCategory('')}
            className={`block w-full text-left py-2 text-sm transition-colors ${
              !selectedCategory ? 'text-amber-600 font-medium' : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            All Categories
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.slug)}
              className={`block w-full text-left py-2 text-sm transition-colors ${
                selectedCategory === cat.slug ? 'text-amber-600 font-medium' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Decade */}
      <div>
        <h4 className="text-xs uppercase tracking-widest text-neutral-500 mb-4">Decade</h4>
        <div className="space-y-2">
          <button
            onClick={() => setSelectedDecade('')}
            className={`block w-full text-left py-2 text-sm transition-colors ${
              !selectedDecade ? 'text-amber-600 font-medium' : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            All Decades
          </button>
          {decades.map(decade => (
            <button
              key={decade}
              onClick={() => setSelectedDecade(decade)}
              className={`block w-full text-left py-2 text-sm transition-colors ${
                selectedDecade === decade ? 'text-amber-600 font-medium' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              {decade}
            </button>
          ))}
        </div>
      </div>

      {/* Condition */}
      <div>
        <h4 className="text-xs uppercase tracking-widest text-neutral-500 mb-4">Condition</h4>
        <div className="space-y-3">
          {conditions.map(condition => (
            <label key={condition.value} className="flex items-center gap-3 cursor-pointer">
              <Checkbox
                checked={selectedConditions.includes(condition.value)}
                onCheckedChange={(checked) => {
                  if (checked) {
                    setSelectedConditions([...selectedConditions, condition.value]);
                  } else {
                    setSelectedConditions(selectedConditions.filter(c => c !== condition.value));
                  }
                }}
              />
              <span className="text-sm text-neutral-600">{condition.label}</span>
            </label>
          ))}
        </div>
      </div>

      {activeFiltersCount > 0 && (
        <Button variant="outline" onClick={clearFilters} className="w-full">
          Clear All Filters
        </Button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-neutral-900">
              {selectedCategory ? categories.find(c => c.slug === selectedCategory)?.name || 'Catalog' : 'All Products'}
            </h1>
            <p className="text-neutral-500 mt-1">
              {filteredProducts.length} {filteredProducts.length === 1 ? 'item' : 'items'}
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Search */}
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-400" />
              <Input
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-neutral-50 border-neutral-200"
                autoFocus={showSearch}
              />
            </div>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40 hidden md:flex">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="oldest">Oldest</SelectItem>
                <SelectItem value="price_low">Price: Low to High</SelectItem>
                <SelectItem value="price_high">Price: High to Low</SelectItem>
              </SelectContent>
            </Select>

            {/* View Mode Toggle */}
            <div className="flex border rounded-lg overflow-hidden">
              <Button
                variant={viewMode === 'stack' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('stack')}
                className="rounded-none"
              >
                <Layers className="h-4 w-4 mr-1" />
                Stack
              </Button>
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-none"
              >
                <Grid3x3 className="h-4 w-4 mr-1" />
                Grid
              </Button>
            </div>

            {/* Mobile Filters */}
            <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="outline" size="icon" className="relative">
                  <SlidersHorizontal className="h-4 w-4" />
                  {activeFiltersCount > 0 && (
                    <span className="absolute -top-1 -right-1 h-5 w-5 bg-amber-500 text-white text-xs rounded-full flex items-center justify-center">
                      {activeFiltersCount}
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                </SheetHeader>
                <div className="mt-6">
                  <FilterContent />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Active Filters Tags */}
        {(selectedCategory || selectedDecade || selectedConditions.length > 0) && (
          <div className="flex flex-wrap gap-2 mb-6">
            {selectedCategory && (
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-neutral-100 text-sm rounded-full">
                {categories.find(c => c.slug === selectedCategory)?.name}
                <button onClick={() => setSelectedCategory('')}>
                  <X className="h-3 w-3" />
                </button>
              </span>
            )}
            {selectedDecade && (
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-neutral-100 text-sm rounded-full">
                {selectedDecade}
                <button onClick={() => setSelectedDecade('')}>
                  <X className="h-3 w-3" />
                </button>
              </span>
            )}
            {selectedConditions.map(cond => (
              <span key={cond} className="inline-flex items-center gap-1 px-3 py-1 bg-neutral-100 text-sm rounded-full">
                {conditions.find(c => c.value === cond)?.label}
                <button onClick={() => setSelectedConditions(selectedConditions.filter(c => c !== cond))}>
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
        )}

        <div className="flex gap-8">
          {/* Desktop Sidebar */}
          {viewMode === 'grid' && (
            <aside className="hidden md:block w-64 flex-shrink-0">
              <FilterContent />
            </aside>
          )}

          {/* Products Display */}
          <div className="flex-1">
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-square bg-neutral-200 mb-3" />
                    <div className="h-4 bg-neutral-200 w-1/2 mb-2" />
                    <div className="h-5 bg-neutral-200 w-3/4 mb-2" />
                    <div className="h-5 bg-neutral-200 w-1/4" />
                  </div>
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-neutral-500 mb-4">No products found</p>
                <Button variant="outline" onClick={clearFilters}>
                  Clear Filters
                </Button>
              </div>
            ) : viewMode === 'stack' ? (
              <StackView products={filteredProducts} />
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}