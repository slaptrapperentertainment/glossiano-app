import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Search, ShoppingCart, Music2, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { useCart } from '@/components/cart/CartContext';

const merchCategories = [
  { id: 'clothing', label: 'Clothing', icon: '👕' },
  { id: 'vinyl', label: 'Vinyl Records', icon: '💿' },
  { id: 'hats', label: 'Hats & Caps', icon: '🧢' },
  { id: 'poster', label: 'Posters', icon: '📄' },
  { id: 'toys', label: 'Collectibles', icon: '🎁' },
  { id: 'other', label: 'Other', icon: '⭐' }
];

export default function MerchStore() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const { addToCart } = useCart();

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['merch-products'],
    queryFn: () => base44.entities.Product.list('-created_date', 100)
  });

  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.title?.toLowerCase().includes(query) ||
        p.artist_brand?.toLowerCase().includes(query) ||
        p.description?.toLowerCase().includes(query)
      );
    }

    if (selectedCategory) {
      result = result.filter(p => p.category === selectedCategory);
    }

    switch (sortBy) {
      case 'price_low':
        result.sort((a, b) => (a.price || 0) - (b.price || 0));
        break;
      case 'price_high':
        result.sort((a, b) => (b.price || 0) - (a.price || 0));
        break;
      default:
        result.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }

    return result;
  }, [products, searchQuery, selectedCategory, sortBy]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black">
      {/* Hero Section */}
      <section className="relative py-16 px-4 bg-gradient-to-br from-pink-900/40 to-black border-b border-yellow-500/20">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4">
              SLAP TRAPPER MERCH
            </h1>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              Official merchandise and exclusive drops. Limited edition pieces for true fans.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Search & Sort Controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              placeholder="Search merchandise..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-black/50 border-yellow-500/30 text-white h-12"
            />
          </div>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-40 bg-black/50 border-yellow-500/30 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="price_low">Price: Low to High</SelectItem>
              <SelectItem value="price_high">Price: High to Low</SelectItem>
            </SelectContent>
          </Select>

          <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" className="border-yellow-500/30 text-white hover:bg-yellow-500/10 md:hidden">
                <Filter className="h-5 w-5 mr-2" />
                Filters
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-black border-yellow-500/30">
              <SheetHeader>
                <SheetTitle className="text-white">Categories</SheetTitle>
              </SheetHeader>
              <div className="mt-6 space-y-2">
                <button
                  onClick={() => { setSelectedCategory(''); setFiltersOpen(false); }}
                  className={`w-full text-left py-3 px-4 rounded transition-colors ${
                    !selectedCategory
                      ? 'bg-yellow-500/20 text-yellow-400'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  All Merch
                </button>
                {merchCategories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => { setSelectedCategory(cat.id); setFiltersOpen(false); }}
                    className={`w-full text-left py-3 px-4 rounded transition-colors flex items-center gap-2 ${
                      selectedCategory === cat.id
                        ? 'bg-yellow-500/20 text-yellow-400'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    <span>{cat.icon}</span> {cat.label}
                  </button>
                ))}
              </div>
            </SheetContent>
          </Sheet>
        </div>

        <div className="flex gap-8">
          {/* Desktop Sidebar */}
          <aside className="hidden md:block w-56 flex-shrink-0">
            <div className="sticky top-4 bg-gradient-to-br from-pink-900/30 to-black border border-yellow-500/20 rounded-lg p-6">
              <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                <Music2 className="h-5 w-5 text-yellow-400" />
                Categories
              </h3>
              <div className="space-y-2">
                <button
                  onClick={() => setSelectedCategory('')}
                  className={`w-full text-left py-2 px-3 rounded transition-colors text-sm ${
                    !selectedCategory
                      ? 'bg-yellow-500/20 text-yellow-400 font-medium'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  All Merch
                </button>
                {merchCategories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`w-full text-left py-2 px-3 rounded transition-colors text-sm flex items-center gap-2 ${
                      selectedCategory === cat.id
                        ? 'bg-yellow-500/20 text-yellow-400 font-medium'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    <span className="text-lg">{cat.icon}</span>
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* Products Grid */}
          <div className="flex-1">
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-square bg-gray-800 rounded-lg mb-4" />
                    <div className="h-4 bg-gray-800 w-3/4 mb-2" />
                    <div className="h-4 bg-gray-800 w-1/2" />
                  </div>
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-20">
                <Music2 className="h-16 w-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400 mb-4">No merchandise found</p>
                <Button
                  onClick={() => { setSearchQuery(''); setSelectedCategory(''); }}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black"
                >
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4 }}
                    className="group"
                  >
                    <div className="relative aspect-square overflow-hidden rounded-lg bg-black mb-4 border border-yellow-500/20 group-hover:border-yellow-500/50 transition-all">
                      <img
                        src={product.main_image}
                        alt={product.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      {product.stock === 0 ? (
                        <div className="absolute inset-0 bg-black/70 flex items-center justify-center rounded-lg">
                          <span className="text-white font-bold text-lg">SOLD OUT</span>
                        </div>
                      ) : (
                        <Button
                          onClick={() => addToCart(product)}
                          className="absolute bottom-3 left-3 right-3 bg-yellow-500 hover:bg-yellow-600 text-black font-bold opacity-0 group-hover:opacity-100 transition-opacity"
                          size="sm"
                        >
                          <ShoppingCart className="mr-2 h-4 w-4" />
                          Add to Cart
                        </Button>
                      )}
                    </div>
                    <div className="space-y-2">
                      <p className="text-xs text-gray-400 uppercase tracking-wider">
                        {merchCategories.find(c => c.id === product.category)?.label || product.category}
                      </p>
                      <h3 className="font-semibold text-white group-hover:text-yellow-400 transition-colors line-clamp-2">
                        {product.title}
                      </h3>
                      <p className="text-2xl font-bold text-yellow-400">
                        ${product.price?.toFixed(2)}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}