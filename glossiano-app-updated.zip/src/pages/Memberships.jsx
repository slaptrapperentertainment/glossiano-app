import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, Music, Gift, Users } from 'lucide-react';
import { toast } from 'sonner';
import MembershipCard from '@/components/memberships/MembershipCard';

export default function MembershipsPage() {
  const [selectedTierId, setSelectedTierId] = useState(null);
  const [isSubscribing, setIsSubscribing] = useState(false);

  const { data: memberships = [] } = useQuery({
    queryKey: ['memberships'],
    queryFn: async () => {
      const response = await base44.functions.invoke('getMemberships', {});
      return response.data.memberships;
    },
    initialData: []
  });

  const { data: userSubscription } = useQuery({
    queryKey: ['userSubscription'],
    queryFn: async () => {
      try {
        const response = await base44.functions.invoke('getUserSubscription', {});
        return response.data.subscription;
      } catch {
        return null;
      }
    }
  });

  const handleSelectMembership = async (membershipId, billingCycle) => {
    if (!membershipId) return;

    setSelectedTierId(membershipId);
    setIsSubscribing(true);

    try {
      const response = await base44.functions.invoke('subscribeMembership', {
        membership_tier_id: membershipId,
        billing_cycle: billingCycle
      });

      if (response.data.success) {
        toast.success(`Welcome to the membership! Check your email for details.`);
        // Refetch subscription after successful subscription
        window.location.reload();
      } else {
        toast.error(response.data.error || 'Failed to subscribe');
      }
    } catch (error) {
      toast.error('Error subscribing: ' + error.message);
    } finally {
      setIsSubscribing(false);
      setSelectedTierId(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden py-12 md:py-20 px-4"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-pink-600/10 via-purple-600/10 to-yellow-600/10 blur-3xl"></div>

        <div className="relative max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Support the Movement
          </h1>
          <p className="text-lg md:text-xl text-gray-300 mb-6">
            Join our community and get exclusive access to unreleased music, behind-the-scenes content, and more
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 max-w-4xl mx-auto">
            {[
              { icon: Music, label: 'Early Access', desc: 'New music first' },
              { icon: Gift, label: 'Exclusive Content', desc: 'BTS videos' },
              { icon: Heart, label: 'Supporter Benefits', desc: 'Special perks' },
              { icon: Users, label: 'Community', desc: 'Discord access' }
            ].map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-lg p-4"
              >
                <item.icon className="w-8 h-8 text-pink-500 mx-auto mb-2" />
                <p className="font-semibold text-white text-sm">{item.label}</p>
                <p className="text-xs text-gray-400">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Membership Cards Section */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {memberships.map((membership, idx) => {
            const isPopular = idx === 1;
            const isCurrentTier = userSubscription?.membership_tier_id === membership.id;

            return (
              <MembershipCard
                key={membership.id}
                membership={membership}
                isPopular={isPopular}
                isCurrentTier={isCurrentTier}
                onSelectMonthly={(id) => handleSelectMembership(id, 'monthly')}
                onSelectYearly={(id) => handleSelectMembership(id, 'yearly')}
              />
            );
          })}
        </div>

        {memberships.length === 0 && (
          <div className="text-center py-16">
            <Music className="w-16 h-16 mx-auto mb-4 text-gray-500" />
            <p className="text-gray-400">No membership tiers available yet</p>
          </div>
        )}
      </div>

      {/* Current Subscription Info */}
      {userSubscription && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl mx-auto px-4 py-8 mb-16"
        >
          <Card className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border-green-500/40">
            <CardHeader>
              <CardTitle className="text-white">Your Membership</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="text-gray-300">
                <span className="font-semibold">Tier:</span> {userSubscription.tier_name}
              </p>
              <p className="text-gray-300">
                <span className="font-semibold">Billing:</span> {userSubscription.billing_cycle === 'monthly' ? 'Monthly' : 'Yearly'}
              </p>
              <p className="text-gray-300">
                <span className="font-semibold">Renews:</span> {new Date(userSubscription.renewal_date).toLocaleDateString()}
              </p>
              {userSubscription.monthly_bonus && (
                <p className="text-gray-300 pt-2">
                  <span className="font-semibold">Next Bonus:</span> {userSubscription.monthly_bonus}
                </p>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* FAQ Section */}
      <div className="max-w-4xl mx-auto px-4 py-16 border-t border-gray-800">
        <h2 className="text-3xl font-bold text-white mb-8">FAQ</h2>

        <div className="space-y-6">
          {[
            {
              q: 'Can I change my membership tier?',
              a: 'Yes, you can upgrade or downgrade your membership at any time. Changes take effect on your next billing cycle.'
            },
            {
              q: 'What payment methods do you accept?',
              a: 'We accept all major credit cards and payment methods through Stripe.'
            },
            {
              q: 'Is there a cancellation fee?',
              a: 'No, you can cancel your membership anytime without any additional fees. You\'ll keep access until the end of your current billing period.'
            },
            {
              q: 'What if I have payment issues?',
              a: 'Contact our support team and we\'ll help you resolve any payment problems.'
            }
          ].map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <h3 className="font-semibold text-white mb-2">{item.q}</h3>
              <p className="text-gray-400">{item.a}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}