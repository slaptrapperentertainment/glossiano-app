import React from 'react';
import { motion } from 'framer-motion';
import { Music } from 'lucide-react';
import MusicPlayerComponent from '@/components/music/MusicPlayer';

export default function MusicPlayer() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block mb-6">
            <div className="bg-gradient-to-br from-pink-600 to-yellow-500 p-4 rounded-full">
              <Music className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4">
            MUSIC PLAYER
          </h1>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Stream, search, and enjoy Glossiano's exclusive tracks. Play local uploads or discover new music on Spotify.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <MusicPlayerComponent />
        </motion.div>
      </div>
    </div>
  );
}