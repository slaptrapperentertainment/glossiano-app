import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import ArtistCard from '@/components/artist/ArtistCard';

export default function ArtistBrowser() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');

  const { data: allArtists = [] } = useQuery({
    queryKey: ['all-artists'],
    queryFn: () => base44.entities.Artist.list('-created_date'),
    initialData: []
  });

  const genres = ['all', ...new Set(allArtists.map(a => a.genre).filter(Boolean))];

  const filteredArtists = allArtists.filter(artist => {
    const matchesSearch = artist.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      artist.bio?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === 'all' || artist.genre === selectedGenre;
    return matchesSearch && matchesGenre;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black py-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4">
            ARTIST BROWSER
          </h1>
          <p className="text-gray-300 text-lg mb-8">
            Discover and follow your favorite emerging and established artists
          </p>

          {/* Search */}
          <div className="max-w-2xl mx-auto mb-6">
            <Input
              placeholder="Search artists by name or genre..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-black/50 border-yellow-500/30 text-white pl-10"
              icon={<Search className="h-5 w-5" />}
            />
          </div>

          {/* Genre Filter */}
          <div className="flex flex-wrap gap-2 justify-center items-center mb-8">
            <Filter className="h-4 w-4 text-yellow-400 mr-2" />
            {genres.map(genre => (
              <Badge
                key={genre}
                onClick={() => setSelectedGenre(genre)}
                className={`cursor-pointer ${
                  selectedGenre === genre
                    ? 'bg-gradient-to-r from-pink-600 to-yellow-500'
                    : 'bg-black/50 hover:bg-black/70 border-yellow-500/30'
                }`}
              >
                {genre.charAt(0).toUpperCase() + genre.slice(1)}
              </Badge>
            ))}
          </div>
        </motion.div>

        {/* Artists Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArtists.map((artist, index) => (
            <ArtistCard key={artist.id} artist={artist} index={index} />
          ))}
        </div>

        {filteredArtists.length === 0 && (
          <div className="text-center py-20">
            <p className="text-gray-400 text-lg mb-4">No artists found matching your search</p>
            <p className="text-gray-500 text-sm">Try different keywords or filters</p>
          </div>
        )}

        <div className="text-center mt-12 text-gray-400 text-sm">
          Showing {filteredArtists.length} artist{filteredArtists.length !== 1 ? 's' : ''}
        </div>
      </div>
    </div>
  );
}