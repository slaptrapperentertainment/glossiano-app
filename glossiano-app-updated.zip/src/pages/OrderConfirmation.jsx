import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { CheckCircle, Package, Mail, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import { useCart } from '@/components/cart/CartContext';

export default function OrderConfirmation() {
  const { clearCart } = useCart();
  
  // Get order details from localStorage
  const orderDetails = JSON.parse(localStorage.getItem('last_order') || '{}');

  useEffect(() => {
    // Clear cart when order confirmation loads
    clearCart();
  }, []);

  if (!orderDetails.items || orderDetails.items.length === 0) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center px-4">
        <div className="text-center">
          <p className="text-neutral-500 mb-4">No se encontró información del pedido</p>
          <Link to={createPageUrl('Home')}>
            <Button>
              <Home className="mr-2 h-4 w-4" />
              Volver al Inicio
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50 py-12 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Success Header */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-3">
            ¡Gracias por tu pedido!
          </h1>
          <p className="text-neutral-600 text-lg">
            Hemos recibido tu solicitud y nos pondremos en contacto contigo pronto
          </p>
        </motion.div>

        {/* Order Summary Card */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-lg shadow-md p-6 md:p-8 mb-6"
        >
          <div className="flex items-center gap-3 mb-6 pb-6 border-b">
            <Package className="h-6 w-6 text-amber-600" />
            <h2 className="text-xl font-bold text-neutral-900">Resumen del Pedido</h2>
          </div>

          {/* Customer Info */}
          {orderDetails.customer && (
            <div className="mb-8 pb-6 border-b">
              <h3 className="font-semibold text-neutral-900 mb-3">Información del Cliente</h3>
              <div className="space-y-2 text-sm">
                <p className="text-neutral-600">
                  <span className="font-medium">Nombre:</span> {orderDetails.customer.name}
                </p>
                <p className="text-neutral-600">
                  <span className="font-medium">Email:</span> {orderDetails.customer.email}
                </p>
                <p className="text-neutral-600">
                  <span className="font-medium">Teléfono:</span> {orderDetails.customer.phone}
                </p>
                {orderDetails.customer.address && (
                  <p className="text-neutral-600">
                    <span className="font-medium">Dirección:</span> {orderDetails.customer.address}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Order Items */}
          <div className="space-y-4 mb-6">
            <h3 className="font-semibold text-neutral-900">Productos</h3>
            {orderDetails.items.map((item, index) => (
              <div key={index} className="flex gap-4 py-3 border-b last:border-0">
                <img
                  src={item.main_image}
                  alt={item.title}
                  className="w-16 h-16 object-cover rounded"
                />
                <div className="flex-1">
                  <h4 className="font-medium text-neutral-900">{item.title}</h4>
                  {item.artist_brand && (
                    <p className="text-sm text-neutral-500">{item.artist_brand}</p>
                  )}
                  <p className="text-sm text-neutral-600 mt-1">
                    Cantidad: {item.quantity}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-neutral-900">
                    ${(item.price * item.quantity).toFixed(2)}
                  </p>
                  <p className="text-sm text-neutral-500">
                    ${item.price.toFixed(2)} c/u
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Total */}
          <div className="pt-6 border-t">
            <div className="flex justify-between items-center mb-2">
              <span className="text-neutral-600">Subtotal</span>
              <span className="font-medium text-neutral-900">
                ${orderDetails.subtotal?.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-neutral-600">Envío</span>
              <span className="font-medium text-neutral-900">
                ${orderDetails.shipping?.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center pt-4 border-t mt-4">
              <span className="text-xl font-bold text-neutral-900">Total</span>
              <span className="text-xl font-bold text-amber-600">
                ${orderDetails.total?.toFixed(2)}
              </span>
            </div>
          </div>
        </motion.div>

        {/* Next Steps */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-amber-50 rounded-lg p-6 mb-8"
        >
          <div className="flex items-start gap-3">
            <Mail className="h-6 w-6 text-amber-600 mt-1" />
            <div>
              <h3 className="font-semibold text-neutral-900 mb-2">
                ¿Qué sigue?
              </h3>
              <ul className="text-sm text-neutral-700 space-y-2">
                <li>• Recibirás un correo de confirmación en breve</li>
                <li>• Nos pondremos en contacto contigo para coordinar el pago y envío</li>
                <li>• Si tienes preguntas, contáctanos por email o redes sociales</li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to={createPageUrl('Home')}>
            <Button variant="outline" className="w-full sm:w-auto">
              <Home className="mr-2 h-4 w-4" />
              Volver al Inicio
            </Button>
          </Link>
          <Link to={createPageUrl('Catalog')}>
            <Button className="w-full sm:w-auto bg-neutral-900 hover:bg-neutral-800">
              <Package className="mr-2 h-4 w-4" />
              Seguir Comprando
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}