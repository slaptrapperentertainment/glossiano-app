import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Instagram, Twitter, Youtube, Music2, Play } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ProductCard from '@/components/products/ProductCard';
import { Button } from '@/components/ui/button';

export default function Artist() {
  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list('-created_date', 50)
  });

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section with Artist Image */}
      <section className="relative h-[60vh] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-pink-900/50 via-black to-black">
          <div className="absolute inset-0 bg-[url('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6996ccbe40dedb6ea38067cd/f51840d1f_800x800-9564824--E041FC77-36E3-4E34-93D9D56CC39D2CB0--0--1721828--493FDA602D0B43E588286CF054699C6121.jpg')] bg-cover bg-center opacity-30"></div>
        </div>
        
        <div className="relative h-full flex items-end pb-16 px-4">
          <div className="max-w-7xl mx-auto w-full">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4">
                SLAP TRAPPER
              </h1>
              <p className="text-2xl md:text-3xl text-yellow-400 font-bold mb-4">ENTERTAINMENT</p>
              <p className="text-gray-300 text-lg max-w-2xl">
                Independent artist and producer bringing authentic street sounds and premium beats from the underground.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Bio Section */}
      <section className="py-16 px-4 bg-gradient-to-b from-black via-pink-950/10 to-black">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-black text-white mb-8">
              ABOUT THE <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">ARTIST</span>
            </h2>
            <div className="space-y-4 text-gray-300 text-lg leading-relaxed">
              <p>
                Slap Trapper Entertainment is redefining the sound of modern hip-hop and trap music. 
                With a unique blend of hard-hitting beats, authentic lyrics, and innovative production, 
                we're bringing the real underground sound to the mainstream.
              </p>
              <p>
                From the studio to the streets, every track is crafted with passion and precision. 
                Our mission is to create music that resonates with the culture and speaks truth to the experience.
              </p>
              <p>
                Join the movement. Stream our music, follow our journey, and be part of something real.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Social Media Links */}
      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-black text-white mb-8">
              CONNECT <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">WITH US</span>
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
               <a 
                 href="https://open.spotify.com/artist/6k9SnEyc22WsxHZTlu2w0X" 
                 target="_blank" 
                 rel="noopener noreferrer"
                 className="flex flex-col items-center p-8 bg-gradient-to-br from-green-900/30 to-black border border-green-500/30 hover:border-green-400 hover:shadow-lg hover:shadow-green-500/30 transition-all duration-300 rounded-lg group"
               >
                 <Music2 className="h-12 w-12 text-green-400 group-hover:text-green-300 transition-colors mb-4" />
                 <span className="text-white font-bold">Spotify</span>
               </a>

               <a 
                 href="https://music.apple.com/artist/glossiano" 
                 target="_blank" 
                 rel="noopener noreferrer"
                 className="flex flex-col items-center p-8 bg-gradient-to-br from-pink-900/30 to-black border border-pink-500/30 hover:border-pink-400 hover:shadow-lg hover:shadow-pink-500/30 transition-all duration-300 rounded-lg group"
               >
                 <Music2 className="h-12 w-12 text-pink-400 group-hover:text-pink-300 transition-colors mb-4" />
                 <span className="text-white font-bold">Apple Music</span>
               </a>

               <a 
                 href="https://www.youtube.com/@Glossiano" 
                 target="_blank" 
                 rel="noopener noreferrer"
                 className="flex flex-col items-center p-8 bg-gradient-to-br from-red-900/30 to-black border border-red-500/30 hover:border-red-400 hover:shadow-lg hover:shadow-red-500/30 transition-all duration-300 rounded-lg group"
               >
                 <Youtube className="h-12 w-12 text-red-400 group-hover:text-red-300 transition-colors mb-4" />
                 <span className="text-white font-bold">YouTube Music</span>
               </a>

               <a 
                 href="https://www.instagram.com/glossiano" 
                 target="_blank" 
                 rel="noopener noreferrer"
                 className="flex flex-col items-center p-8 bg-gradient-to-br from-purple-900/30 to-black border border-purple-500/30 hover:border-purple-400 hover:shadow-lg hover:shadow-purple-500/30 transition-all duration-300 rounded-lg group"
               >
                 <Instagram className="h-12 w-12 text-purple-400 group-hover:text-purple-300 transition-colors mb-4" />
                 <span className="text-white font-bold">Instagram</span>
               </a>

               <a 
                 href="https://twitter.com/glossiano" 
                 target="_blank" 
                 rel="noopener noreferrer"
                 className="flex flex-col items-center p-8 bg-gradient-to-br from-blue-900/30 to-black border border-blue-500/30 hover:border-blue-400 hover:shadow-lg hover:shadow-blue-500/30 transition-all duration-300 rounded-lg group"
               >
                 <Twitter className="h-12 w-12 text-blue-400 group-hover:text-blue-300 transition-colors mb-4" />
                 <span className="text-white font-bold">Twitter/X</span>
               </a>

               <a 
                 href="https://soundcloud.com/glossiano" 
                 target="_blank" 
                 rel="noopener noreferrer"
                 className="flex flex-col items-center p-8 bg-gradient-to-br from-orange-900/30 to-black border border-orange-500/30 hover:border-orange-400 hover:shadow-lg hover:shadow-orange-500/30 transition-all duration-300 rounded-lg group"
               >
                 <Music2 className="h-12 w-12 text-orange-400 group-hover:text-orange-300 transition-colors mb-4" />
                 <span className="text-white font-bold">SoundCloud</span>
               </a>
             </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Track/Video */}
      <section className="py-16 px-4 bg-gradient-to-b from-black via-pink-950/10 to-black">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-black text-white mb-8">
              FEATURED <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">RELEASE</span>
            </h2>
            <div className="bg-gradient-to-br from-pink-900/30 to-black border border-yellow-500/30 rounded-lg overflow-hidden">
              <div className="aspect-video bg-black flex items-center justify-center relative overflow-hidden">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6996ccbe40dedb6ea38067cd/f51840d1f_800x800-9564824--E041FC77-36E3-4E34-93D9D56CC39D2CB0--0--1721828--493FDA602D0B43E588286CF054699C6121.jpg"
                  alt="GLOSSIANO - 307 GOLD"
                  className="w-full h-full object-cover opacity-60"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                  <Button className="bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white px-12 py-6 text-xl font-bold rounded-full shadow-2xl">
                    <Play className="mr-3 h-8 w-8" />
                    Play Now
                  </Button>
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-3xl font-black text-white mb-2">GLOSSIANO - 307 GOLD</h3>
                <p className="text-yellow-400 font-bold mb-4">Produced by Glossy</p>
                <p className="text-gray-300">
                  The latest drop featuring fire beats and authentic street vibes. Experience the sound that's taking the underground by storm.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Discography */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="flex items-center justify-between mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-black text-white">
              COMPLETE <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">DISCOGRAPHY</span>
            </h2>
            <Link 
              to={createPageUrl('Catalog')} 
              className="text-sm text-yellow-400 hover:text-yellow-300 transition-colors flex items-center gap-2 font-medium"
            >
              View All
            </Link>
          </motion.div>
          
          {products.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {products.map((product, idx) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: idx * 0.05 }}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Music2 className="h-16 w-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No releases yet. Stay tuned for new drops!</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}