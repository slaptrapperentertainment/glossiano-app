import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Music2, Trash2, Edit, Search, Plus, Upload, Rocket } from 'lucide-react';
import { toast } from 'sonner';
import TrackForm from '@/components/admin/TrackForm';
import BulkImportTrack from '@/components/admin/BulkImportTrack';

export default function AdminTracks() {
  const [showForm, setShowForm] = useState(false);
  const [editingTrack, setEditingTrack] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [distributingTrack, setDistributingTrack] = useState(null);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: tracks = [], isLoading } = useQuery({
    queryKey: ['glossiano-tracks-admin'],
    queryFn: () => base44.entities.Track.list('-created_date', 100)
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Track.delete(id),
    onSuccess: () => {
      toast.success('✓ Track deleted');
      queryClient.invalidateQueries({ queryKey: ['glossiano-tracks'] });
    }
  });

  const filteredTracks = tracks.filter(t =>
    t.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.artist?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    total: tracks.length,
    forSale: tracks.filter(t => t.for_sale).length,
    featured: tracks.filter(t => t.featured).length,
    membersOnly: tracks.filter(t => t.members_only).length
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-black text-white mb-2 flex items-center gap-3">
            <Music2 className="h-10 w-10 text-yellow-400" />
            Manage Tracks
          </h1>
          <p className="text-gray-400">Add, edit, and organize your music library</p>
        </motion.div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Tracks', value: stats.total, color: 'from-pink-600 to-pink-900' },
            { label: 'For Sale', value: stats.forSale, color: 'from-yellow-600 to-yellow-900' },
            { label: 'Featured', value: stats.featured, color: 'from-purple-600 to-purple-900' },
            { label: 'Members Only', value: stats.membersOnly, color: 'from-blue-600 to-blue-900' }
          ].map((stat, idx) => (
            <Card key={idx} className={`bg-gradient-to-br ${stat.color} border-0`}>
              <CardContent className="p-6 text-center">
                <p className="text-gray-200 text-sm font-semibold">{stat.label}</p>
                <p className="text-3xl font-black text-white mt-2">{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tabs */}
        <Tabs defaultValue="list" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-black/50 border border-pink-500/30 mb-8">
            <TabsTrigger value="list" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Music2 className="h-4 w-4 mr-2" />
              My Tracks
            </TabsTrigger>
            <TabsTrigger value="add" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Plus className="h-4 w-4 mr-2" />
              Add Track
            </TabsTrigger>
            <TabsTrigger value="import" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Upload className="h-4 w-4 mr-2" />
              Bulk Import
            </TabsTrigger>
          </TabsList>

          {/* List Tab */}
          <TabsContent value="list" className="space-y-6">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-500" />
              <Input
                placeholder="Search by title or artist..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-black/50 border-yellow-500/20"
              />
            </div>

            {/* Tracks List */}
            {isLoading ? (
              <div className="text-center py-12 text-gray-400">
                <p>Loading tracks...</p>
              </div>
            ) : filteredTracks.length === 0 ? (
              <Card className="bg-black/50 border-yellow-500/20 text-center py-12">
                <p className="text-gray-400">No tracks yet. Start by adding one!</p>
              </Card>
            ) : (
              <div className="space-y-3">
                {filteredTracks.map((track) => (
                  <motion.div
                    key={track.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <Card className="bg-black/50 border-yellow-500/20 hover:border-yellow-500/40 transition-all">
                      <CardContent className="p-4 flex items-center justify-between gap-4">
                        {/* Track Info */}
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-white truncate">{track.title}</h3>
                          <p className="text-yellow-400 text-sm">{track.artist}</p>
                          <div className="flex gap-2 mt-2 flex-wrap">
                            {track.featured && <Badge className="bg-purple-600 text-white">⭐ Featured</Badge>}
                            {track.for_sale && <Badge className="bg-green-600 text-white">${track.price}</Badge>}
                            {track.members_only && <Badge className="bg-blue-600 text-white">🔒 Members</Badge>}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-2">
                          <Button
                            onClick={() => {
                              sessionStorage.setItem('distributionTrack', JSON.stringify(track));
                              navigate(createPageUrl('Distribution'));
                            }}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            <Rocket className="h-4 w-4" />
                          </Button>
                          <Button
                            onClick={() => setEditingTrack(track)}
                            size="sm"
                            className="bg-yellow-600 hover:bg-yellow-700 text-white"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            onClick={() => {
                              if (confirm('Delete this track?')) {
                                deleteMutation.mutate(track.id);
                              }
                            }}
                            disabled={deleteMutation.isPending}
                            size="sm"
                            variant="destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Add Tab */}
          <TabsContent value="add">
            {editingTrack ? (
              <div className="space-y-4">
                <TrackForm
                  track={editingTrack}
                  onSuccess={() => setEditingTrack(null)}
                  onCancel={() => setEditingTrack(null)}
                />
              </div>
            ) : showForm ? (
              <div className="space-y-4">
                <TrackForm
                  onSuccess={() => setShowForm(false)}
                  onCancel={() => setShowForm(false)}
                />
              </div>
            ) : (
              <Button
                onClick={() => setShowForm(true)}
                className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white font-bold py-6 text-lg"
              >
                <Plus className="h-5 w-5 mr-2" />
                Add New Track
              </Button>
            )}
          </TabsContent>

          {/* Bulk Import Tab */}
          <TabsContent value="import">
            <BulkImportTrack onSuccess={() => queryClient.invalidateQueries({ queryKey: ['glossiano-tracks'] })} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}