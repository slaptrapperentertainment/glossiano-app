import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, MessageCircle } from 'lucide-react';
import FollowButton from '@/components/fan/FollowButton';
import FanMessageForm from '@/components/fan/FanMessageForm';
import FanMessageCard from '@/components/fan/FanMessageCard';

export default function FanWall() {
  const queryClient = useQueryClient();

  const { data: messages = [] } = useQuery({
    queryKey: ['fanMessages'],
    queryFn: () => base44.entities.FanMessage.filter(
      { status: { $in: ['approved', 'flagged'] } },
      '-is_featured,-created_date'
    )
  });

  const { data: followers = [] } = useQuery({
    queryKey: ['glossianoFollowers'],
    queryFn: () => base44.entities.Follower.filter({ is_following: true })
  });

  const handleMessagePosted = () => {
    queryClient.invalidateQueries({ queryKey: ['fanMessages'] });
  };

  const handleMessageFlagged = () => {
    queryClient.invalidateQueries({ queryKey: ['fanMessages'] });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-black p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-white">Fan Wall</h1>
          <p className="text-gray-400 text-lg">
            Connect with Glossiano and the community
          </p>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 mt-8">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="pt-6">
                <div className="flex items-center justify-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{followers.length}</p>
                    <p className="text-sm text-gray-400">Followers</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="pt-6">
                <div className="flex items-center justify-center gap-2">
                  <MessageCircle className="h-5 w-5 text-amber-500" />
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{messages.length}</p>
                    <p className="text-sm text-gray-400">Messages</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Follow Button */}
          <div className="flex justify-center pt-4">
            <FollowButton />
          </div>
        </div>

        {/* Message Form */}
        <FanMessageForm onMessagePosted={handleMessagePosted} />

        {/* Messages Grid */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-6">Messages</h2>
          {messages.length === 0 ? (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="text-center py-12">
                <MessageCircle className="h-12 w-12 mx-auto mb-4 text-gray-600" />
                <p className="text-gray-400">No messages yet. Be the first!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => (
                <FanMessageCard
                  key={message.id}
                  message={message}
                  onMessageFlagged={handleMessageFlagged}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}