import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Play, Music2, Star, Filter, TrendingUp, Clock, Headphones, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useCart } from '@/components/cart/CartContext';
import QuickBuyWidget from '@/components/music/QuickBuyWidget';
import { toast } from 'sonner';

export default function MusicShop() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [totalStreams, setTotalStreams] = useState(0);

  const { data: tracks = [] } = useQuery({
    queryKey: ['glossiano-tracks'],
    queryFn: () => base44.entities.Track.filter({ artist: 'Glossiano' }, '-created_date'),
    initialData: []
  });

  useEffect(() => {
    if (tracks.length > 0) {
      const streams = tracks.reduce((sum, track) => sum + (track.play_count || 0), 0);
      setTotalStreams(streams);
    }
  }, [tracks]);

  const genres = ['all', ...new Set(tracks.map(t => t.genre).filter(Boolean))];

  const filteredTracks = tracks
    .filter(track => {
      const matchesSearch = track.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        track.artist?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        track.album?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesGenre = selectedGenre === 'all' || track.genre === selectedGenre;
      return matchesSearch && matchesGenre;
    })
    .sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.created_date) - new Date(a.created_date);
      if (sortBy === 'popular') return (b.play_count || 0) - (a.play_count || 0);
      if (sortBy === 'price-low') return (a.price || 0) - (b.price || 0);
      if (sortBy === 'price-high') return (b.price || 0) - (a.price || 0);
      return 0;
    });

  const featuredTracks = tracks.filter(t => t.featured).slice(0, 3);
  const trendingTracks = [...tracks].sort((a, b) => (b.play_count || 0) - (a.play_count || 0)).slice(0, 6);
  const newReleases = [...tracks].sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).slice(0, 6);

  const [playingId, setPlayingId] = React.useState(null);
  const [audioRef] = React.useState({});
  const { addToCart } = useCart();

  const handlePlay = async (trackId, audioUrl, trackTitle) => {
    if (playingId === trackId) {
      audioRef[trackId]?.pause();
      setPlayingId(null);
    } else {
      if (playingId) audioRef[playingId]?.pause();
      const audio = new Audio(audioUrl);
      audioRef[trackId] = audio;
      audio.play();
      setPlayingId(trackId);

      // Track stream analytics
      base44.analytics.track({
        eventName: 'track_played',
        properties: {
          track_id: trackId,
          track_title: trackTitle,
          artist: 'Glossiano',
          platform: 'music_shop'
        }
      });

      // Increment play count
      base44.functions.invoke('incrementPlayCount', { trackId });
    }
  };

  const handleAddToCart = (track) => {
    if (track.for_sale && track.price) {
      addToCart({
        id: track.id,
        title: track.title,
        price: track.price,
        artist: track.artist,
        image: track.cover_image
      });
      
      // Track purchase analytics
      base44.analytics.track({
        eventName: 'track_added_to_cart',
        properties: {
          track_id: track.id,
          track_title: track.title,
          price: track.price,
          artist: 'Glossiano'
        }
      });

      toast.success(`✅ "${track.title}" added to cart!`);
    } else {
      toast.error('This track is not available for purchase');
    }
  };

  const handleSpotifyClick = (track) => {
    handlePlay(track.id, track.audio_url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black py-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Stream Analytics Banner */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-pink-900/40 to-yellow-900/40 border border-yellow-500/30 rounded-xl p-6 mb-12 flex items-center justify-center gap-4"
        >
          <Zap className="h-8 w-8 text-yellow-400" />
          <div className="text-center">
            <p className="text-gray-300 text-sm">PLATFORM STREAMS</p>
            <h3 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">
              {totalStreams.toLocaleString()}
            </h3>
          </div>
        </motion.div>

         <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           className="text-center mb-12"
         >
           <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4">
             GLOSSIANO MUSIC STORE
           </h1>
           <p className="text-gray-300 text-lg mb-8">
             Support the artist - Buy exclusive tracks & downloads
           </p>

          <div className="max-w-2xl mx-auto mb-6">
            <Input
              placeholder="Search tracks, albums, genres..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-black/50 border-yellow-500/30 text-white"
            />
          </div>
          <div className="flex gap-3 justify-center flex-wrap mb-6">
            <a href="https://music.apple.com/us/artist/glossiano/1234567890" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gray-900 hover:bg-gray-800 text-white border border-gray-700 px-6 py-2 rounded-full">
                🎵 Also on Apple Music
              </Button>
            </a>
            <a href="https://open.spotify.com/artist/6k9SnEyc22WsxHZTlu2w0X" target="_blank" rel="noopener noreferrer">
              <Button className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-full">
                🎧 Listen on Spotify
              </Button>
            </a>
          </div>
        </motion.div>

        {/* Discovery Tabs */}
        <Tabs defaultValue="all" className="mb-12">
          <TabsList className="grid w-full grid-cols-3 bg-black/50 border border-pink-500/30 max-w-md mx-auto">
            <TabsTrigger value="featured" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Star className="h-4 w-4 mr-2" />
              Featured
            </TabsTrigger>
            <TabsTrigger value="trending" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <TrendingUp className="h-4 w-4 mr-2" />
              Trending
            </TabsTrigger>
            <TabsTrigger value="new" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Clock className="h-4 w-4 mr-2" />
              New
            </TabsTrigger>
          </TabsList>

          <TabsContent value="featured" className="mt-8">
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              {featuredTracks.map((track, index) => (
                <TrackCard key={track.id} track={track} index={index} handlePlay={handlePlay} handleAddToCart={handleAddToCart} playingId={playingId} featured />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="trending" className="mt-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              {trendingTracks.map((track, index) => (
                <TrackCard key={track.id} track={track} index={index} handlePlay={handlePlay} handleAddToCart={handleAddToCart} playingId={playingId} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="new" className="mt-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              {newReleases.map((track, index) => (
                <TrackCard key={track.id} track={track} index={index} handlePlay={handlePlay} handleAddToCart={handleAddToCart} playingId={playingId} />
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 items-center justify-between mb-8 bg-black/30 p-4 rounded-lg border border-yellow-500/20">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-yellow-400" />
            <span className="text-white text-sm font-medium">Genre:</span>
            <div className="flex flex-wrap gap-2">
              {genres.map(genre => (
                <Badge
                  key={genre}
                  onClick={() => setSelectedGenre(genre)}
                  className={`cursor-pointer ${
                    selectedGenre === genre
                      ? 'bg-gradient-to-r from-pink-600 to-yellow-500'
                      : 'bg-black/50 hover:bg-black/70 border-yellow-500/30'
                  }`}
                >
                  {genre.charAt(0).toUpperCase() + genre.slice(1)}
                </Badge>
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-white text-sm font-medium">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-black/50 border border-yellow-500/30 text-white rounded px-3 py-1 text-sm"
            >
              <option value="newest">Newest</option>
              <option value="popular">Most Popular</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* All Tracks Grid */}
        <h2 className="text-2xl font-bold text-white mb-6">All Tracks</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTracks.map((track, index) => (
            <TrackCard key={track.id} track={track} index={index} handlePlay={handlePlay} handleAddToCart={handleAddToCart} playingId={playingId} />
          ))}
        </div>

        {filteredTracks.length === 0 && (
          <div className="text-center py-20">
            <Music2 className="h-20 w-20 mx-auto mb-4 text-gray-600" />
            <p className="text-gray-400 text-lg mb-4">No authentic Glossiano tracks available yet</p>
            <p className="text-gray-500 text-sm">Add real tracks from Spotify or Apple Music to display them here</p>
          </div>
        )}
      </div>
    </div>
  );
}

function TrackCard({ track, index, handlePlay, handleAddToCart, playingId, featured = false }) {
  const officialCoverImages = {
    default: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=500&h=500&fit=crop',
    alternative1: 'https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=500&h=500&fit=crop',
    alternative2: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&h=500&fit=crop',
    alternative3: 'https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=500&h=500&fit=crop',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <Card className={`bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30 overflow-hidden group hover:border-yellow-500/60 transition-all ${featured ? 'ring-2 ring-yellow-500/50' : ''}`}>
        <CardContent className="p-0">
          <div className="relative aspect-square">
            <img
              src={track.cover_image || officialCoverImages.default}
              alt={track.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            <button
              onClick={() => handlePlay(track.id, track.audio_url, track.title)}
              className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
            >
              <div className="bg-gradient-to-r from-pink-600 to-yellow-500 rounded-full p-4">
                <Play className="h-8 w-8 text-white ml-1" />
              </div>
            </button>
            {track.featured && (
              <div className="absolute top-3 right-3 bg-gradient-to-r from-pink-600 to-yellow-500 px-3 py-1 rounded-full">
                <Star className="h-4 w-4 text-white inline mr-1" />
                <span className="text-white text-xs font-bold">Featured</span>
              </div>
            )}
            {track.genre && (
              <Badge className="absolute top-3 left-3 bg-black/70 border-yellow-500/30">
                {track.genre}
              </Badge>
            )}
          </div>

          <div className="p-5">
            <h3 className="text-xl font-bold text-white mb-1 truncate">{track.title}</h3>
            <p className="text-yellow-400 text-sm mb-2">{track.artist}</p>
            {track.album && (
              <p className="text-gray-400 text-xs mb-3">{track.album} {track.year && `• ${track.year}`}</p>
            )}
            
            {track.description && (
              <p className="text-gray-300 text-sm mb-4 line-clamp-2">{track.description}</p>
            )}

            <div className="flex gap-2">
              <Button
                onClick={() => handlePlay(track.id, track.audio_url, track.title)}
                size="sm"
                className={`flex-1 ${playingId === track.id ? 'bg-gradient-to-r from-pink-600 to-yellow-500' : 'bg-black/50 hover:bg-black/70'} border border-yellow-500/30 text-yellow-400`}
              >
                <Play className="h-4 w-4 mr-1" />
                {playingId === track.id ? 'Playing' : 'Play'}
              </Button>
              {track.for_sale && (
                <Button
                  onClick={() => handleAddToCart(track)}
                  size="sm"
                  className="flex-1 bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white"
                >
                  ${track.price}
                </Button>
              )}
            </div>

            {track.play_count > 0 && (
              <div className="mt-3 pt-3 border-t border-yellow-500/20">
                <p className="text-xs text-gray-500 flex items-center gap-1">
                  <Music2 className="h-3 w-3" />
                  {track.play_count} plays
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}