import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useCart } from '@/components/cart/CartContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Lock, Zap } from 'lucide-react';
import { toast } from 'sonner';

export default function Checkout() {
  const { cart, total, itemCount, clearCart } = useCart();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isOwner, setIsOwner] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        setIsOwner(userData?.email === 'slaptrapperentertainment@gmail.com');
      } catch (err) {
        setUser(null);
      }
    };
    fetchUser();
  }, []);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    country: '',
    postal_code: '',
    notes: ''
  });

  const { data: settings = [] } = useQuery({
    queryKey: ['settings'],
    queryFn: () => base44.entities.Settings.list('', 1)
  });

  const paymentLink = settings[0]?.payment_link;

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.name || !formData.email || !formData.phone) {
      toast.error('Please complete all required fields');
      return;
    }

    try {
      toast.loading('Processing order...');

      // Store order details for confirmation
      const orderDetails = {
        customer: formData,
        items: cart,
        subtotal: total,
        total: total,
        timestamp: new Date().toISOString()
      };
      localStorage.setItem('last_order', JSON.stringify(orderDetails));

      if (isOwner) {
        // Process free order for app owner
        const response = await base44.functions.invoke('processFreeOrder', {
          cart: cart,
          customerName: formData.name,
          customerEmail: formData.email,
          customerPhone: formData.phone,
          shippingAddress: {
            address: formData.address,
            city: formData.city,
            country: formData.country,
            postal_code: formData.postal_code
          }
        });

        if (response.data.orderId) {
          clearCart();
          navigate(createPageUrl('OrderConfirmation') + `?orderId=${response.data.orderId}&free=true`);
        } else {
          toast.error('Failed to process order');
        }
      } else {
        // Create Stripe checkout session for regular users
        const response = await base44.functions.invoke('createStripeCheckout', {
          cart: cart,
          customerEmail: formData.email
        });

        if (response.data.url) {
          window.location.href = response.data.url;
        } else {
          toast.error('Failed to create checkout session');
        }
      }
    } catch (error) {
      console.error('Checkout error:', error);
      toast.error('Failed to process order. Please try again.');
    }
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center px-4">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-neutral-900 mb-2">Your cart is empty</h2>
          <p className="text-neutral-600 mb-6">Add items before checking out</p>
          <Link to={createPageUrl('MusicShop')}>
            <Button className="bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600">
              Browse Music
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-5xl mx-auto px-4 md:px-6 py-8">
        <Link to={createPageUrl('Cart')} className="inline-flex items-center text-sm text-neutral-600 hover:text-neutral-900 mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Volver al Carrito
        </Link>

        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-neutral-900">Secure Checkout</h1>
          {isOwner && (
            <div className="flex items-center gap-2 bg-yellow-50 px-4 py-2 rounded-lg border border-yellow-200">
              <Zap className="h-5 w-5 text-yellow-600" />
              <span className="text-sm font-semibold text-yellow-700">Free checkout (Owner)</span>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="grid lg:grid-cols-3 gap-8">
          {/* Customer Info */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg p-6">
              <h2 className="text-xl font-semibold text-neutral-900 mb-6">Contact Information</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre Completo *</Label>
                  <Input
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="phone">Teléfono *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-6">
              <h2 className="text-xl font-semibold text-neutral-900 mb-6">Shipping Address</h2>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="address">Dirección *</Label>
                  <Input
                    id="address"
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">Ciudad *</Label>
                    <Input
                      id="city"
                      required
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="postal_code">Código Postal *</Label>
                    <Input
                      id="postal_code"
                      required
                      value={formData.postal_code}
                      onChange={(e) => setFormData({ ...formData, postal_code: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="country">País *</Label>
                  <Input
                    id="country"
                    required
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Notas del Pedido (opcional)</Label>
                  <Textarea
                    id="notes"
                    rows={3}
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Instrucciones especiales de entrega..."
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg p-6 sticky top-6">
              <h2 className="text-xl font-semibold text-neutral-900 mb-4">Resumen del Pedido</h2>
              
              <div className="space-y-3 mb-6 max-h-64 overflow-y-auto">
                {cart.map(item => (
                  <div key={item.id} className="flex gap-3">
                    <img src={item.main_image} alt={item.title} className="w-16 h-16 object-cover rounded" />
                    <div className="flex-1 text-sm">
                      <p className="font-medium text-neutral-900">{item.title}</p>
                      <p className="text-neutral-500">Cantidad: {item.quantity}</p>
                      <p className="font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4 space-y-2 mb-6">
                <div className="flex justify-between text-neutral-600">
                  <span>Subtotal</span>
                  <span>${total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-lg font-bold text-neutral-900">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>

              <Button 
                type="submit" 
                className={`w-full py-6 ${
                  isOwner 
                    ? 'bg-green-600 hover:bg-green-700' 
                    : 'bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600'
                }`}
              >
                <Lock className="mr-2 h-4 w-4" />
                {isOwner ? 'Complete Order (Free)' : 'Pay with Stripe'}
              </Button>

              <p className="text-xs text-neutral-500 text-center mt-4">
                {isOwner ? '✓ Free order - No payment required' : '🔒 Secure payment powered by Stripe'}
              </p>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}