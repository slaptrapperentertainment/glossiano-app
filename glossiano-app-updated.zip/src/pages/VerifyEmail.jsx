import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useSearchParams, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { CheckCircle2, XCircle, Loader2, Music2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function VerifyEmail() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  
  const [status, setStatus] = useState('verifying'); // verifying, success, error
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!token) {
      setStatus('error');
      setMessage('Invalid verification link');
      return;
    }

    const verifyEmail = async () => {
      try {
        const response = await base44.functions.invoke('confirmEmailVerification', { token });
        
        if (response.data.success) {
          setStatus('success');
          setMessage(response.data.message);
        } else {
          setStatus('error');
          setMessage(response.data.error || 'Verification failed');
        }
      } catch (error) {
        setStatus('error');
        setMessage('Something went wrong. Please try again.');
      }
    };

    verifyEmail();
  }, [token]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black flex items-center justify-center px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-md w-full"
      >
        <div className="bg-gradient-to-br from-pink-900/40 to-black border border-yellow-500/40 rounded-2xl p-8 text-center">
          {status === 'verifying' && (
            <>
              <Loader2 className="h-16 w-16 text-yellow-400 animate-spin mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-white mb-2">Verifying Your Email...</h1>
              <p className="text-gray-400">Please wait a moment</p>
            </>
          )}

          {status === 'success' && (
            <>
              <CheckCircle2 className="h-16 w-16 text-green-400 mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-white mb-2">You're In! 🔥</h1>
              <p className="text-gray-300 mb-6">{message}</p>
              <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-4 mb-6">
                <p className="text-sm text-yellow-200">
                  Check your inbox for a welcome email with exclusive content!
                </p>
              </div>
              <Link to={createPageUrl('Home')}>
                <Button className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600">
                  <Music2 className="mr-2 h-5 w-5" />
                  Explore Music
                </Button>
              </Link>
            </>
          )}

          {status === 'error' && (
            <>
              <XCircle className="h-16 w-16 text-red-400 mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-white mb-2">Verification Failed</h1>
              <p className="text-gray-300 mb-6">{message}</p>
              <Link to={createPageUrl('MusicStudio')}>
                <Button className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600">
                  Try Again
                </Button>
              </Link>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}