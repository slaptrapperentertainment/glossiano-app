import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { BarChart3, Package, MessageSquare, Settings, LogOut, Lock, Music } from 'lucide-react';
import { toast } from 'sonner';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const userData = await base44.auth.me();
        if (userData?.email === 'slaptrapperentertainment@gmail.com') {
          setUser(userData);
        } else {
          toast.error('Access denied. Admin only.');
          navigate(createPageUrl('Home'));
        }
      } catch (err) {
        navigate(createPageUrl('Home'));
      } finally {
        setLoading(false);
      }
    };
    checkAuth();
  }, [navigate]);

  const { data: orders = [] } = useQuery({
    queryKey: ['orders'],
    queryFn: () => base44.entities.Order.list('-created_date', 10),
    enabled: !!user
  });

  const { data: fanMessages = [] } = useQuery({
    queryKey: ['fanMessages'],
    queryFn: () => base44.entities.FanMessage.filter({ status: 'pending' }),
    enabled: !!user
  });

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
    enabled: !!user
  });

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-pulse text-white">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const menuItems = [
    {
      title: 'Music Library',
      description: 'Add, organize & manage tracks',
      icon: Music,
      color: 'from-purple-900 to-purple-600',
      link: createPageUrl('AdminMusicLibrary'),
      stats: 'Organize'
    },
    {
      title: 'Merchandise',
      description: 'Manage products, inventory & orders',
      icon: Package,
      color: 'from-blue-900 to-blue-600',
      link: createPageUrl('AdminMerch'),
      stats: `${products.length} products`
    },
    {
      title: 'Fan Wall',
      description: 'Moderate & manage fan messages',
      icon: MessageSquare,
      color: 'from-pink-900 to-pink-600',
      link: createPageUrl('AdminFanWall'),
      stats: `${fanMessages.length} pending`
    },
    {
      title: 'Settings',
      description: 'Store configuration & branding',
      icon: Settings,
      color: 'from-yellow-900 to-yellow-600',
      link: createPageUrl('AdminSettings'),
      stats: 'Configure'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-950 to-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Lock className="h-8 w-8 text-yellow-400" />
              <h1 className="text-4xl md:text-5xl font-black text-white">ADMIN DASHBOARD</h1>
            </div>
            <p className="text-gray-400">Welcome, {user.full_name || user.email}</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-red-500/50 text-red-400 hover:bg-red-500/10"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <Card className="bg-gradient-to-br from-blue-900/30 to-black border-blue-500/30">
            <CardContent className="p-6">
              <p className="text-gray-400 text-sm">Total Products</p>
              <p className="text-3xl font-bold text-blue-400">{products.length}</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-pink-900/30 to-black border-pink-500/30">
            <CardContent className="p-6">
              <p className="text-gray-400 text-sm">Pending Messages</p>
              <p className="text-3xl font-bold text-pink-400">{fanMessages.length}</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-green-900/30 to-black border-green-500/30">
            <CardContent className="p-6">
              <p className="text-gray-400 text-sm">Recent Orders</p>
              <p className="text-3xl font-bold text-green-400">{orders.length}</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-yellow-900/30 to-black border-yellow-500/30">
            <CardContent className="p-6">
              <p className="text-gray-400 text-sm">Status</p>
              <p className="text-3xl font-bold text-yellow-400">✓ Active</p>
            </CardContent>
          </Card>
        </div>

        {/* Menu Items */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const href = item.link;
            
            return (
              <button
                key={item.title}
                onClick={item.onClick || (() => navigate(href))}
                className="text-left"
              >
                <Card className={`bg-gradient-to-br ${item.color} border-yellow-500/30 hover:border-yellow-400 transition-all hover:shadow-lg hover:shadow-yellow-500/20 cursor-pointer h-full`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <Icon className="h-8 w-8 text-yellow-300" />
                      <span className="text-xs bg-yellow-500/20 text-yellow-300 px-3 py-1 rounded-full">
                        {item.stats}
                      </span>
                    </div>
                    <CardTitle className="text-2xl text-white mt-4">{item.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-200">{item.description}</p>
                  </CardContent>
                </Card>
              </button>
            );
          })}
        </div>

        {/* Recent Orders */}
        {orders.length > 0 && (
          <Card className="bg-gradient-to-br from-gray-900/50 to-black border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white">Recent Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {orders.slice(0, 5).map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-3 bg-black/50 rounded-lg border border-gray-700/30">
                    <div>
                      <p className="text-white font-medium">{order.customer_name}</p>
                      <p className="text-sm text-gray-400">{order.items?.length || 0} items • ${order.total_amount.toFixed(2)}</p>
                    </div>
                    <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                      order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                      order.status === 'shipped' ? 'bg-blue-500/20 text-blue-400' :
                      order.status === 'paid' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-gray-500/20 text-gray-400'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}