import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Music2, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';

import MusicPlayer from '@/components/music/MusicPlayer';
import FeaturedMusicSection from '@/components/home/FeaturedMusicSection';
import ArtistSpotlight from '@/components/artist/ArtistSpotlight';
import TopAlbums from '@/components/home/TopAlbums';
import BeatsShowcase from '@/components/home/BeatsShowcase';

const GLOSSIANO_SPOTIFY = 'https://open.spotify.com/artist/6k9SnEyc22WsxHZTlu2w0X';
const GLOSSIANO_APPLE_MUSIC = 'https://music.apple.com/us/artist/glossiano/1234567890';

export default function Home() {
  const { data: tracks = [] } = useQuery({
    queryKey: ['glossiano-tracks'],
    queryFn: () => base44.entities.Track.filter({ artist: 'Glossiano' }, '-featured')
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
         {/* Animated Background */}
         <div className="absolute inset-0 bg-gradient-to-br from-pink-900/30 via-black to-yellow-900/20">
           <a href={GLOSSIANO_SPOTIFY} target="_blank" rel="noopener noreferrer" className="absolute inset-0 block hover:opacity-80 transition-opacity">
             <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=1920')] opacity-10 bg-cover bg-center mix-blend-overlay"></div>
           </a>
         </div>
        
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="relative z-10 text-center px-4 max-w-5xl mx-auto"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mb-8"
          >
            <h1 className="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4 tracking-tight">
              SLAP TRAPPER
            </h1>
            <div className="text-2xl md:text-4xl font-bold text-yellow-400 mb-2 tracking-widest">
              ENTERTAINMENT
            </div>
          </motion.div>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="text-gray-300 text-lg md:text-xl mb-10 max-w-2xl mx-auto font-light leading-relaxed"
          >
            Premium beats, exclusive tracks, and fire music straight from the underground.
            Elevate your sound with Slap Trapper.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="flex gap-4 justify-center flex-wrap"
          >
            <a href={GLOSSIANO_SPOTIFY} target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white px-8 py-6 text-lg font-bold rounded-full shadow-2xl shadow-pink-500/50">
                <Music2 className="mr-2 h-5 w-5" />
                Listen on Spotify
              </Button>
            </a>
            <a href={GLOSSIANO_APPLE_MUSIC} target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-gray-900 to-black hover:from-gray-800 hover:to-gray-900 text-white px-8 py-6 text-lg font-bold rounded-full shadow-2xl border border-gray-700">
                <Music2 className="mr-2 h-5 w-5" />
                Listen on Apple Music
              </Button>
            </a>
            <Link to={createPageUrl('MusicShop')}>
              <Button className="bg-gradient-to-r from-yellow-500 to-pink-600 hover:from-yellow-600 hover:to-pink-700 text-white px-8 py-6 text-lg font-bold rounded-full shadow-2xl shadow-yellow-500/50">
                <Music2 className="mr-2 h-5 w-5" />
                Buy Tracks
              </Button>
            </Link>
          </motion.div>
        </motion.div>

        {/* Decorative Elements */}
        <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black to-transparent"></div>
      </section>



      {/* Beats Showcase - BeatStars Style */}
      <BeatsShowcase />

      {/* Top Albums Section */}
      <TopAlbums />

      {/* Featured Music & Shop Section */}
      <section className="max-w-7xl mx-auto">
        <FeaturedMusicSection />
      </section>

      {/* Artist Spotlight */}
      <ArtistSpotlight />

      {/* Music Player Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent via-pink-950/10 to-transparent">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-5xl font-black text-white mb-4">
              LISTEN <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">NOW</span>
            </h2>
            <p className="text-gray-400 text-lg">Stream the latest tracks and hottest beats from Glossiano on all platforms</p>
          </motion.div>
          <MusicPlayer />
        </div>
      </section>



      {/* CTA Banner */}
      <section className="py-24 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-pink-900 via-yellow-900/50 to-pink-900"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1598387846567-f72f6fe8bc56?w=1920')] opacity-10 bg-cover bg-center mix-blend-overlay"></div>
        
        <div className="relative max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Music2 className="h-16 w-16 text-yellow-400 mx-auto mb-6" />
            <h2 className="text-4xl md:text-6xl font-black text-white mb-6 leading-tight">
              READY TO ELEVATE YOUR SOUND?
            </h2>
            <p className="text-gray-200 text-lg mb-10 font-light max-w-2xl mx-auto">
              Stream and purchase exclusive Glossiano tracks. Premium beats straight from the underground, available on Spotify, Apple Music, and all major platforms.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <a href={GLOSSIANO_SPOTIFY} target="_blank" rel="noopener noreferrer">
                <Button className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg font-bold rounded-full">
                  Spotify
                </Button>
              </a>
              <a href={GLOSSIANO_APPLE_MUSIC} target="_blank" rel="noopener noreferrer">
                <Button className="bg-gray-900 hover:bg-gray-800 text-white px-8 py-3 text-lg font-bold rounded-full border border-gray-700">
                  Apple Music
                </Button>
              </a>
              <Link to={createPageUrl('MusicShop')}>
                <Button className="bg-gradient-to-r from-yellow-400 to-pink-500 text-black hover:from-yellow-500 hover:to-pink-600 px-8 py-3 text-lg font-bold rounded-full">
                  Buy Directly
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}