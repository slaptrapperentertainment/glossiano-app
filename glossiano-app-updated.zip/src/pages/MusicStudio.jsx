import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Upload, Wand2, Youtube, Instagram, Music2, Loader2, CheckCircle2, Radio, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import LiveStreamPlayer from '@/components/streaming/LiveStreamPlayer';
import FanList from '@/components/marketing/FanList';
import AddFanForm from '@/components/marketing/AddFanForm';
import EmailCampaign from '@/components/marketing/EmailCampaign';
import ImportFans from '@/components/marketing/ImportFans';

export default function MusicStudio() {
  const [audioFile, setAudioFile] = useState(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [masteredUrl, setMasteredUrl] = useState('');
  const [masteringPreset, setMasteringPreset] = useState('medium');
  const [isUploading, setIsUploading] = useState(false);
  const [isMastering, setIsMastering] = useState(false);
  const [isPostingYT, setIsPostingYT] = useState(false);
  const [isPostingIG, setIsPostingIG] = useState(false);
  const [selectedFanEmails, setSelectedFanEmails] = useState([]);
  const [showEmailCampaign, setShowEmailCampaign] = useState(false);

  // YouTube fields
  const [ytTitle, setYtTitle] = useState('');
  const [ytDescription, setYtDescription] = useState('');
  const [ytTags, setYtTags] = useState('');

  // Instagram fields
  const [igImage, setIgImage] = useState(null);
  const [igImageUrl, setIgImageUrl] = useState('');
  const [igCaption, setIgCaption] = useState('');

  const handleAudioUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setAudioFile(file);
    setIsUploading(true);

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setAudioUrl(file_url);
      toast.success('Audio file uploaded successfully!');
    } catch (error) {
      toast.error('Failed to upload audio: ' + error.message);
    } finally {
      setIsUploading(false);
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIgImage(file);
    setIsUploading(true);

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setIgImageUrl(file_url);
      toast.success('Image uploaded successfully!');
    } catch (error) {
      toast.error('Failed to upload image: ' + error.message);
    } finally {
      setIsUploading(false);
    }
  };

  const handleMasterAudio = async () => {
    if (!audioUrl) {
      toast.error('Please upload an audio file first');
      return;
    }

    setIsMastering(true);

    try {
      const response = await base44.functions.invoke('masterAudio', {
        audioFileUrl: audioUrl,
        preset: masteringPreset,
      });

      setMasteredUrl(response.data.masteredFileUrl);
      toast.success('Audio mastered successfully!');
    } catch (error) {
      toast.error('Failed to master audio: ' + error.message);
    } finally {
      setIsMastering(false);
    }
  };

  const handlePostToYouTube = async () => {
    if (!ytTitle || !masteredUrl) {
      toast.error('Please provide title and mastered audio');
      return;
    }

    setIsPostingYT(true);

    try {
      const response = await base44.functions.invoke('uploadToYouTube', {
        videoFile: masteredUrl,
        title: ytTitle,
        description: ytDescription,
        tags: ytTags.split(',').map(t => t.trim()),
      });

      toast.success('Successfully uploaded to YouTube!');
      window.open(response.data.videoUrl, '_blank');
    } catch (error) {
      toast.error('Failed to upload to YouTube: ' + error.message);
    } finally {
      setIsPostingYT(false);
    }
  };

  const handlePostToInstagram = async () => {
    if (!igImageUrl || !igCaption) {
      toast.error('Please provide image and caption');
      return;
    }

    setIsPostingIG(true);

    try {
      await base44.functions.invoke('postToInstagram', {
        imageUrl: igImageUrl,
        caption: igCaption,
      });

      toast.success('Successfully posted to Instagram!');
    } catch (error) {
      toast.error('Failed to post to Instagram: ' + error.message);
    } finally {
      setIsPostingIG(false);
    }
  };

  const handleSendEmailToFans = (emails) => {
    setSelectedFanEmails(emails);
    setShowEmailCampaign(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/20 to-black py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4">
            MUSIC STUDIO
          </h1>
          <p className="text-gray-300 text-lg">
            AI-Powered Mastering, Distribution & Fan Marketing
          </p>
        </motion.div>

        <Tabs defaultValue="distribution" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-black/50 border border-yellow-500/30 mb-8">
            <TabsTrigger value="distribution" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Music2 className="h-4 w-4 mr-2" />
              Distribution
            </TabsTrigger>
            <TabsTrigger value="marketing" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
              <Users className="h-4 w-4 mr-2" />
              Fan Marketing
            </TabsTrigger>
          </TabsList>

          <TabsContent value="distribution" className="space-y-8">
            {/* Live Streaming Section */}
            <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Radio className="h-6 w-6 text-red-500" />
                  Live Streaming
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Stream live performances and studio sessions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <LiveStreamPlayer 
                  streamName="slap-trapper-live" 
                  accountId="your-account-id"
                />
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-8">
          {/* Audio Upload & Mastering */}
          <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Wand2 className="h-6 w-6 text-yellow-400" />
                AI Audio Mastering
              </CardTitle>
              <CardDescription className="text-gray-400">
                Upload and master your tracks with AI technology
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Upload Audio File
                </label>
                <div className="flex items-center gap-2">
                  <Input
                    type="file"
                    accept="audio/*"
                    onChange={handleAudioUpload}
                    disabled={isUploading}
                    className="bg-black/50 border-yellow-500/30 text-white"
                  />
                  {audioUrl && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                </div>
              </div>

              {audioUrl && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Mastering Preset
                    </label>
                    <Select value={masteringPreset} onValueChange={setMasteringPreset}>
                      <SelectTrigger className="bg-black/50 border-yellow-500/30 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="heavy">Heavy</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    onClick={handleMasterAudio}
                    disabled={isMastering}
                    className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600"
                  >
                    {isMastering ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Mastering...
                      </>
                    ) : (
                      <>
                        <Wand2 className="mr-2 h-4 w-4" />
                        Master Audio
                      </>
                    )}
                  </Button>
                </>
              )}

              {masteredUrl && (
                <div className="bg-black/30 p-4 rounded-lg border border-green-500/30">
                  <p className="text-green-400 text-sm flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4" />
                    Audio mastered successfully!
                  </p>
                  <audio controls className="w-full mt-2">
                    <source src={masteredUrl} type="audio/mpeg" />
                  </audio>
                </div>
              )}
            </CardContent>
          </Card>

          {/* YouTube Upload */}
          <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Youtube className="h-6 w-6 text-red-500" />
                YouTube Upload
              </CardTitle>
              <CardDescription className="text-gray-400">
                Upload your mastered track to YouTube
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Video Title
                </label>
                <Input
                  value={ytTitle}
                  onChange={(e) => setYtTitle(e.target.value)}
                  placeholder="Enter video title"
                  className="bg-black/50 border-yellow-500/30 text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Description
                </label>
                <Textarea
                  value={ytDescription}
                  onChange={(e) => setYtDescription(e.target.value)}
                  placeholder="Enter video description"
                  className="bg-black/50 border-yellow-500/30 text-white"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Tags (comma separated)
                </label>
                <Input
                  value={ytTags}
                  onChange={(e) => setYtTags(e.target.value)}
                  placeholder="hip-hop, trap, beats"
                  className="bg-black/50 border-yellow-500/30 text-white"
                />
              </div>

              <Button
                onClick={handlePostToYouTube}
                disabled={!masteredUrl || isPostingYT}
                className="w-full bg-red-600 hover:bg-red-700"
              >
                {isPostingYT ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Youtube className="mr-2 h-4 w-4" />
                    Upload to YouTube
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Instagram Post */}
          <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Instagram className="h-6 w-6 text-pink-500" />
                Instagram Post
              </CardTitle>
              <CardDescription className="text-gray-400">
                Share your release on Instagram
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Upload Cover Image
                </label>
                <div className="flex items-center gap-2">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    disabled={isUploading}
                    className="bg-black/50 border-yellow-500/30 text-white"
                  />
                  {igImageUrl && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                </div>
              </div>

              {igImageUrl && (
                <img
                  src={igImageUrl}
                  alt="Preview"
                  className="w-full h-48 object-cover rounded-lg"
                />
              )}

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Caption
                </label>
                <Textarea
                  value={igCaption}
                  onChange={(e) => setIgCaption(e.target.value)}
                  placeholder="Write your caption..."
                  className="bg-black/50 border-yellow-500/30 text-white"
                  rows={4}
                />
              </div>

              <Button
                onClick={handlePostToInstagram}
                disabled={!igImageUrl || isPostingIG}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {isPostingIG ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Posting...
                  </>
                ) : (
                  <>
                    <Instagram className="mr-2 h-4 w-4" />
                    Post to Instagram
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
          </TabsContent>

          <TabsContent value="marketing" className="space-y-8">
            <div className="grid gap-8">
              {/* Email Campaign */}
              {showEmailCampaign && selectedFanEmails.length > 0 && (
                <EmailCampaign 
                  selectedEmails={selectedFanEmails}
                  onClose={() => {
                    setShowEmailCampaign(false);
                    setSelectedFanEmails([]);
                  }}
                />
              )}

              {/* Import Real Contacts */}
              <ImportFans />

              {/* Add Fan Form */}
              <AddFanForm />

              {/* Fan List */}
              <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Users className="h-6 w-6 text-yellow-400" />
                    West Coast Bay Area Rap Fans
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Your fan database - reach real supporters of Bay Area hip-hop
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <FanList onSendEmail={handleSendEmailToFans} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}