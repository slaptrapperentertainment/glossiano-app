import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Music, Users, DollarSign, Filter, Download, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import PredictiveEarnings from '@/components/analytics/PredictiveEarnings';
import AudienceInsights from '@/components/analytics/AudienceInsights';
import TrendingPlatforms from '@/components/analytics/TrendingPlatforms';
import SmartRecommendations from '@/components/analytics/SmartRecommendations';

const COLORS = ['#fbbf24', '#ec4899', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b'];

export default function Analytics() {
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [selectedRelease, setSelectedRelease] = useState('all');

  const { data: distributions = [] } = useQuery({
    queryKey: ['distributions'],
    queryFn: () => base44.entities.Distribution.list()
  });

  const { data: aiInsights = null, isLoading: insightsLoading } = useQuery({
    queryKey: ['analyticsInsights', distributions],
    queryFn: async () => {
      if (distributions.length === 0) return null;
      const response = await base44.functions.invoke('generateAnalyticsInsights', {
        distributions: distributions.slice(0, 10)
      });
      return response.data;
    },
    enabled: distributions.length > 0,
    staleTime: 60 * 60 * 1000 // 1 hour
  });

  // Filter data based on selections
  const filteredData = useMemo(() => {
    let filtered = [...distributions];

    if (selectedRelease !== 'all') {
      filtered = filtered.filter(d => d.id === selectedRelease);
    }

    if (dateRange.start) {
      filtered = filtered.filter(d => new Date(d.created_date) >= new Date(dateRange.start));
    }

    if (dateRange.end) {
      filtered = filtered.filter(d => new Date(d.created_date) <= new Date(dateRange.end));
    }

    return filtered;
  }, [distributions, selectedRelease, dateRange]);

  // Calculate summary stats
  const stats = useMemo(() => {
    const totalStreams = filteredData.reduce((sum, d) => sum + (d.total_streams || 0), 0);
    const totalEarnings = filteredData.reduce((sum, d) => sum + (d.estimated_earnings || 0), 0);
    const avgStreamsPerRelease = filteredData.length > 0 ? Math.round(totalStreams / filteredData.length) : 0;
    const activeReleases = filteredData.filter(d => d.status === 'live').length;

    return { totalStreams, totalEarnings, avgStreamsPerRelease, activeReleases };
  }, [filteredData]);

  // Streams over time data
  const streamsOverTime = useMemo(() => {
    const grouped = {};
    filteredData.forEach(release => {
      const month = new Date(release.created_date).toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short' 
      });
      if (!grouped[month]) grouped[month] = 0;
      grouped[month] += release.total_streams || 0;
    });
    return Object.entries(grouped).map(([month, streams]) => ({ month, streams }));
  }, [filteredData]);

  // Platform breakdown
  const platformData = useMemo(() => {
    const platforms = {};
    filteredData.forEach(release => {
      (release.platforms_live || []).forEach(platform => {
        platforms[platform] = (platforms[platform] || 0) + (release.total_streams || 0);
      });
    });
    return Object.entries(platforms)
      .map(([name, value]) => ({ name: name.replace(/_/g, ' ').toUpperCase(), value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [filteredData]);

  // Revenue per release
  const revenueByRelease = useMemo(() => {
    return filteredData
      .filter(d => d.estimated_earnings > 0)
      .sort((a, b) => b.estimated_earnings - a.estimated_earnings)
      .slice(0, 10)
      .map(d => ({
        name: `${d.release_title.substring(0, 15)}...`,
        revenue: Math.round(d.estimated_earnings),
        fullName: d.release_title
      }));
  }, [filteredData]);

  // Listener demographics (simulated)
  const demographics = [
    { name: '18-24', value: 28 },
    { name: '25-34', value: 35 },
    { name: '35-44', value: 20 },
    { name: '45-54', value: 12 },
    { name: '55+', value: 5 }
  ];

  const handleExport = () => {
    const csvContent = [
      ['Release', 'Streams', 'Revenue', 'Platforms Live', 'Status'],
      ...filteredData.map(d => [
        d.release_title,
        d.total_streams,
        d.estimated_earnings.toFixed(2),
        d.platforms_live?.length || 0,
        d.status
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'analytics.csv';
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-pink-950/10 to-black p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-black text-white mb-2">
            Analytics <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">Dashboard</span>
          </h1>
          <p className="text-gray-400">Track your releases, streams, revenue, and audience insights</p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8 bg-gradient-to-r from-pink-900/20 to-black border border-yellow-500/20 rounded-xl p-6"
        >
          <div className="flex items-center gap-4 mb-4">
            <Filter className="h-5 w-5 text-yellow-400" />
            <h2 className="text-lg font-bold text-white">Filters</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Start Date</label>
              <Input
                type="date"
                value={dateRange.start}
                onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                className="bg-black/50 border-yellow-500/30 text-white"
              />
            </div>
            <div>
              <label className="text-sm text-gray-400 mb-2 block">End Date</label>
              <Input
                type="date"
                value={dateRange.end}
                onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                className="bg-black/50 border-yellow-500/30 text-white"
              />
            </div>
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Release</label>
              <select
                value={selectedRelease}
                onChange={(e) => setSelectedRelease(e.target.value)}
                className="w-full px-3 py-2 bg-black/50 border border-yellow-500/30 rounded-md text-white text-sm"
              >
                <option value="all">All Releases</option>
                {distributions.map(d => (
                  <option key={d.id} value={d.id}>{d.release_title}</option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <Button
                onClick={() => setDateRange({ start: '', end: '' }) || setSelectedRelease('all')}
                variant="outline"
                className="w-full border-yellow-500/30 text-gray-300"
              >
                Reset Filters
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8"
        >
          {[
            { icon: TrendingUp, label: 'Total Streams', value: stats.totalStreams.toLocaleString(), color: 'text-yellow-400' },
            { icon: DollarSign, label: 'Total Earnings', value: `$${stats.totalEarnings.toFixed(2)}`, color: 'text-green-400' },
            { icon: Music, label: 'Avg Streams/Release', value: stats.avgStreamsPerRelease.toLocaleString(), color: 'text-pink-400' },
            { icon: Users, label: 'Active Releases', value: stats.activeReleases, color: 'text-blue-400' }
          ].map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <Card key={idx} className="bg-gradient-to-br from-pink-900/20 to-black border-yellow-500/20">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-gray-400 text-sm mb-2">{stat.label}</p>
                      <p className="text-2xl font-bold text-white">{stat.value}</p>
                    </div>
                    <Icon className={`h-8 w-8 ${stat.color}`} />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </motion.div>

        {/* AI Insights Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8 bg-gradient-to-r from-cyan-900/20 to-black border border-cyan-500/20 rounded-xl p-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <Sparkles className="h-5 w-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-white">AI-Powered Insights</h2>
          </div>
          <p className="text-gray-400 text-sm">Advanced analytics to grow your music career</p>
        </motion.div>

        {/* AI Insights Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <PredictiveEarnings data={aiInsights} isLoading={insightsLoading} />
          <AudienceInsights data={aiInsights} isLoading={insightsLoading} />
          <TrendingPlatforms data={aiInsights} isLoading={insightsLoading} />
          <SmartRecommendations data={aiInsights} isLoading={insightsLoading} />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Streams Over Time */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gradient-to-br from-pink-900/20 to-black border-yellow-500/20 h-full">
              <CardHeader>
                <CardTitle className="text-white">Streams Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                {streamsOverTime.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={streamsOverTime}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#4b5563" />
                      <XAxis dataKey="month" stroke="#9ca3af" />
                      <YAxis stroke="#9ca3af" />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }}
                        formatter={(value) => value.toLocaleString()}
                      />
                      <Line type="monotone" dataKey="streams" stroke="#fbbf24" strokeWidth={2} dot={{ fill: '#ec4899' }} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-gray-400 text-center py-12">No data available</p>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Top Platforms */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-gradient-to-br from-pink-900/20 to-black border-yellow-500/20 h-full">
              <CardHeader>
                <CardTitle className="text-white">Top Streaming Platforms</CardTitle>
              </CardHeader>
              <CardContent>
                {platformData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={platformData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#4b5563" />
                      <XAxis dataKey="name" stroke="#9ca3af" angle={-45} textAnchor="end" height={80} />
                      <YAxis stroke="#9ca3af" />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }}
                        formatter={(value) => value.toLocaleString()}
                      />
                      <Bar dataKey="value" fill="#ec4899" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-gray-400 text-center py-12">No platform data available</p>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Revenue by Release */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="bg-gradient-to-br from-pink-900/20 to-black border-yellow-500/20 h-full">
              <CardHeader>
                <CardTitle className="text-white">Revenue by Release</CardTitle>
              </CardHeader>
              <CardContent>
                {revenueByRelease.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={revenueByRelease} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#4b5563" />
                      <XAxis type="number" stroke="#9ca3af" />
                      <YAxis dataKey="name" type="category" stroke="#9ca3af" width={100} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }}
                        formatter={(value) => `$${value.toFixed(2)}`}
                      />
                      <Bar dataKey="revenue" fill="#10b981" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-gray-400 text-center py-12">No revenue data available</p>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Listener Demographics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="bg-gradient-to-br from-pink-900/20 to-black border-yellow-500/20 h-full">
              <CardHeader>
                <CardTitle className="text-white">Listener Demographics</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={demographics}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {demographics.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }}
                      formatter={(value) => `${value}%`}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Export Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="flex justify-end gap-4"
        >
          <Button
            onClick={handleExport}
            className="bg-gradient-to-r from-yellow-500 to-pink-600 hover:from-yellow-600 hover:to-pink-700 text-white"
          >
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </motion.div>
      </div>
    </div>
  );
}