import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Share2, Heart, ShoppingCart, Plus, Minus } from 'lucide-react';
import { motion } from 'framer-motion';
import ProductCard from '@/components/products/ProductCard';
import { useCart } from '@/components/cart/CartContext';

const conditionLabels = {
  mint: { label: 'Mint', description: 'Perfect condition, like new' },
  near_mint: { label: 'Near Mint', description: 'Almost perfect, minimal signs of use' },
  very_good: { label: 'Very Good', description: 'Light wear, plays/works perfectly' },
  good: { label: 'Good', description: 'Some visible wear, fully functional' },
  fair: { label: 'Fair', description: 'Noticeable wear, still usable' }
};

export default function ProductDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('id');
  const { addToCart } = useCart();

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list('-created_date', 100)
  });

  const product = products.find(p => p.id === productId);
  const relatedProducts = products
    .filter(p => p.id !== productId && (p.category === product?.category || p.decade === product?.decade))
    .slice(0, 4);

  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const allImages = product ? [product.main_image, ...(product.gallery_images || [])] : [];

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-neutral-500 mb-4">Producto no encontrado</p>
          <Link to={createPageUrl('Catalog')}>
            <Button variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver al Catálogo
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-neutral-500 mb-8">
          <Link to={createPageUrl('Home')} className="hover:text-neutral-900">Inicio</Link>
          <span>/</span>
          <Link to={createPageUrl('Catalog')} className="hover:text-neutral-900">Catálogo</Link>
          <span>/</span>
          <span className="text-neutral-900">{product.title}</span>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Images */}
          <div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="aspect-square bg-neutral-100 overflow-hidden mb-4"
            >
              <img
                src={allImages[selectedImage]}
                alt={product.title}
                className="w-full h-full object-cover"
              />
            </motion.div>
            {allImages.length > 1 && (
              <div className="grid grid-cols-5 gap-2">
                {allImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`aspect-square bg-neutral-100 overflow-hidden border-2 transition-colors ${
                      selectedImage === idx ? 'border-amber-500' : 'border-transparent'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div>
            <div className="flex items-start justify-between mb-4">
              <div>
                {product.artist_brand && (
                  <p className="text-sm text-neutral-500 uppercase tracking-wider mb-1">
                    {product.artist_brand}
                  </p>
                )}
                <h1 className="text-3xl md:text-4xl font-bold text-neutral-900">
                  {product.title}
                </h1>
              </div>
              <Button variant="ghost" size="icon">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>

            <div className="flex flex-wrap gap-2 mb-6">
              {product.decade && (
                <Badge variant="outline">{product.decade}</Badge>
              )}
              {product.year && (
                <Badge variant="outline">{product.year}</Badge>
              )}
              {product.genre && (
                <Badge variant="outline">{product.genre}</Badge>
              )}
              {product.category && (
                <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                  {product.category}
                </Badge>
              )}
            </div>

            <p className="text-4xl font-bold text-neutral-900 mb-6">
              ${product.price?.toFixed(2)}
            </p>

            {product.condition && conditionLabels[product.condition] && (
              <div className="bg-neutral-50 p-4 rounded-lg mb-6">
                <p className="text-sm font-medium text-neutral-900">
                  Condición: {conditionLabels[product.condition].label}
                </p>
                <p className="text-sm text-neutral-500 mt-1">
                  {conditionLabels[product.condition].description}
                </p>
              </div>
            )}

            {product.description && (
              <div className="prose prose-neutral max-w-none mb-8">
                <p className="text-neutral-600 leading-relaxed whitespace-pre-line">
                  {product.description}
                </p>
              </div>
            )}

            <div className="flex items-center gap-2 mb-6">
              {product.stock > 0 ? (
                <span className="text-green-600 text-sm font-medium">
                  ✓ Disponible ({product.stock} en stock)
                </span>
              ) : (
                <span className="text-red-600 text-sm font-medium">
                  Agotado
                </span>
              )}
            </div>

            {product.stock > 0 && (
              <div className="flex items-center gap-4 mb-6">
                <span className="text-sm font-medium text-neutral-700">Cantidad:</span>
                <div className="flex items-center gap-2 border border-neutral-200 rounded">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="w-12 text-center font-medium">{quantity}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}

            <div className="flex gap-4">
              <Button 
                className="flex-1 bg-neutral-900 hover:bg-neutral-800 py-6 text-base"
                disabled={product.stock === 0}
                onClick={handleAddToCart}
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                {product.stock > 0 ? 'Añadir al Carrito' : 'Agotado'}
              </Button>
              <Button variant="outline" size="icon" className="py-6">
                <Heart className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <section className="mt-20">
            <h2 className="text-2xl font-bold text-neutral-900 mb-8">
              También te puede gustar
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {relatedProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}