import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useCart } from '@/components/cart/CartContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, total, itemCount } = useCart();

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center px-4">
        <div className="text-center">
          <ShoppingBag className="h-16 w-16 text-neutral-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-neutral-900 mb-2">Tu carrito está vacío</h2>
          <p className="text-neutral-600 mb-6">Descubre nuestros productos vintage</p>
          <Link to={createPageUrl('Catalog')}>
            <Button className="bg-neutral-900 hover:bg-neutral-800">
              Explorar Catálogo
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        <h1 className="text-3xl font-bold text-neutral-900 mb-8">Carrito de Compras</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item, idx) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white rounded-lg p-4 flex gap-4"
              >
                <Link to={createPageUrl('ProductDetail') + `?id=${item.id}`} className="flex-shrink-0">
                  <img
                    src={item.main_image}
                    alt={item.title}
                    className="w-24 h-24 object-cover rounded"
                  />
                </Link>

                <div className="flex-1">
                  <Link to={createPageUrl('ProductDetail') + `?id=${item.id}`}>
                    <h3 className="font-semibold text-neutral-900 hover:text-amber-600 transition-colors">
                      {item.title}
                    </h3>
                  </Link>
                  {item.artist_brand && (
                    <p className="text-sm text-neutral-500">{item.artist_brand}</p>
                  )}
                  <p className="text-lg font-bold text-neutral-900 mt-2">
                    ${item.price?.toFixed(2)}
                  </p>
                </div>

                <div className="flex flex-col items-end justify-between">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeFromCart(item.id)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>

                  <div className="flex items-center gap-2 border border-neutral-200 rounded">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                    <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg p-6 sticky top-6">
              <h2 className="text-xl font-bold text-neutral-900 mb-6">Resumen del Pedido</h2>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-neutral-600">
                  <span>Subtotal ({itemCount} {itemCount === 1 ? 'producto' : 'productos'})</span>
                  <span>${total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-neutral-600">
                  <span>Envío</span>
                  <span>Calculado en el checkout</span>
                </div>
                <div className="border-t pt-3 flex justify-between text-lg font-bold text-neutral-900">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>

              <Link to={createPageUrl('Checkout')}>
                <Button className="w-full bg-neutral-900 hover:bg-neutral-800 py-6">
                  Proceder al Pago
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>

              <Link to={createPageUrl('Catalog')}>
                <Button variant="outline" className="w-full mt-3">
                  Continuar Comprando
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}