import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ShoppingCart } from 'lucide-react';
import { motion } from 'framer-motion';
import { useCart } from '@/components/cart/CartContext';

const conditionLabels = {
  mint: 'Mint',
  near_mint: 'Near Mint',
  very_good: 'Very Good',
  good: 'Good',
  fair: 'Fair'
};

export default function ProductCard({ product }) {
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="group"
    >
      <Link to={createPageUrl('ProductDetail') + `?id=${product.id}`}>
        <div className="relative aspect-square overflow-hidden bg-neutral-100 mb-3">
          <img
            src={product.main_image}
            alt={product.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          {product.featured && (
            <Badge className="absolute top-3 left-3 bg-amber-500 text-white border-0">
              Featured
            </Badge>
          )}
          {product.stock === 0 ? (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <span className="text-white font-light tracking-widest text-sm">AGOTADO</span>
            </div>
          ) : (
            <Button
              onClick={handleAddToCart}
              className="absolute bottom-3 left-3 right-3 bg-neutral-900 hover:bg-neutral-800 opacity-0 group-hover:opacity-100 transition-opacity"
              size="sm"
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              Añadir al Carrito
            </Button>
          )}
        </div>
        <div className="space-y-1">
          <p className="text-xs text-neutral-500 uppercase tracking-wider">
            {product.artist_brand || product.category}
          </p>
          <h3 className="font-medium text-neutral-900 group-hover:text-amber-600 transition-colors">
            {product.title}
          </h3>
          <div className="flex items-center justify-between">
            <p className="text-lg font-semibold text-neutral-900">
              ${product.price?.toFixed(2)}
            </p>
            {product.condition && (
              <span className="text-xs text-neutral-500">
                {conditionLabels[product.condition]}
              </span>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}