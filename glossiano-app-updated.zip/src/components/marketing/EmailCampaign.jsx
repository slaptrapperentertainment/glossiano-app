import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Mail, Send, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function EmailCampaign({ selectedEmails = [], onClose }) {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);

  const handleSendEmails = async () => {
    if (!subject || !message) {
      toast.error('Please fill in subject and message');
      return;
    }

    if (selectedEmails.length === 0) {
      toast.error('No recipients selected');
      return;
    }

    setIsSending(true);

    try {
      const response = await base44.functions.invoke('sendBulkEmail', {
        emails: selectedEmails,
        subject: subject,
        message: message
      });

      if (response.data.success) {
        toast.success(`Successfully sent ${response.data.sent} emails!`);
        if (response.data.failed > 0) {
          toast.warning(`${response.data.failed} emails failed to send`);
        }
        setSubject('');
        setMessage('');
        if (onClose) onClose();
      }
    } catch (error) {
      toast.error('Failed to send emails: ' + error.message);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Mail className="h-6 w-6 text-yellow-400" />
          Email Campaign
        </CardTitle>
        <CardDescription className="text-gray-400">
          Sending to {selectedEmails.length} fan{selectedEmails.length !== 1 ? 's' : ''}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Subject Line
          </label>
          <Input
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="New track dropping this Friday! 🔥"
            className="bg-black/50 border-yellow-500/30 text-white"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Message
          </label>
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Hey Bay Area! Got some new heat coming your way..."
            className="bg-black/50 border-yellow-500/30 text-white"
            rows={8}
          />
        </div>

        <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-3">
          <p className="text-xs text-yellow-200">
            💡 Pro Tip: Include a link to your music, social media, or upcoming shows!
          </p>
        </div>

        <div className="flex gap-3">
          <Button
            onClick={handleSendEmails}
            disabled={isSending || !subject || !message}
            className="flex-1 bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600"
          >
            {isSending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending to {selectedEmails.length} fans...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Send Campaign
              </>
            )}
          </Button>
          {onClose && (
            <Button
              variant="outline"
              onClick={onClose}
              className="border-yellow-500/30 text-gray-400"
            >
              Cancel
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}