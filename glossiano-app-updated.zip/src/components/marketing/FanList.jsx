import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Mail, Users, MapPin, Search, Trash2, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function FanList({ onSendEmail }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFans, setSelectedFans] = useState([]);
  const queryClient = useQueryClient();

  const { data: fans = [], isLoading } = useQuery({
    queryKey: ['fans'],
    queryFn: () => base44.entities.Fan.list('-created_date', 500),
  });

  const deleteFanMutation = useMutation({
    mutationFn: (fanId) => base44.entities.Fan.delete(fanId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fans'] });
      toast.success('Fan removed from list');
    },
  });

  const filteredFans = fans.filter(fan => 
    fan.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    fan.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    fan.location?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const subscribedFans = filteredFans.filter(f => f.subscribed && f.email_verified);
  const verifiedFans = filteredFans.filter(f => f.email_verified);
  const unverifiedFans = filteredFans.filter(f => !f.email_verified);

  const toggleFanSelection = (fanId) => {
    setSelectedFans(prev => 
      prev.includes(fanId) 
        ? prev.filter(id => id !== fanId)
        : [...prev, fanId]
    );
  };

  const selectAll = () => {
    setSelectedFans(subscribedFans.map(f => f.id));
  };

  const clearSelection = () => {
    setSelectedFans([]);
  };

  const handleSendToSelected = () => {
    const selectedEmails = fans
      .filter(f => selectedFans.includes(f.id))
      .map(f => f.email);
    onSendEmail(selectedEmails);
  };

  if (isLoading) {
    return <div className="text-gray-400">Loading fan database...</div>;
  }

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-2xl font-bold text-white">{fans.length}</p>
                <p className="text-xs text-gray-400">Total Fans</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-2xl font-bold text-white">{verifiedFans.length}</p>
                <p className="text-xs text-gray-400">Verified</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-pink-400" />
              <div>
                <p className="text-2xl font-bold text-white">
                  {new Set(fans.map(f => f.location).filter(Boolean)).size}
                </p>
                <p className="text-xs text-gray-400">Locations</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-400" />
              <div>
                <p className="text-2xl font-bold text-white">{selectedFans.length}</p>
                <p className="text-xs text-gray-400">Selected</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Actions */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search fans by name, email, or location..."
            className="pl-10 bg-black/50 border-yellow-500/30 text-white"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={selectAll}
            className="border-yellow-500/30 text-yellow-400"
          >
            Select All
          </Button>
          <Button
            variant="outline"
            onClick={clearSelection}
            className="border-yellow-500/30 text-gray-400"
          >
            Clear
          </Button>
          <Button
            onClick={handleSendToSelected}
            disabled={selectedFans.length === 0}
            className="bg-gradient-to-r from-pink-600 to-yellow-500"
          >
            <Mail className="mr-2 h-4 w-4" />
            Email Selected ({selectedFans.length})
          </Button>
        </div>
      </div>

      {/* Fan List */}
      <div className="grid gap-3 max-h-[500px] overflow-y-auto pr-2">
        {filteredFans.map((fan) => (
          <Card 
            key={fan.id}
            className={`bg-gradient-to-br from-pink-900/20 to-black border-yellow-500/20 transition-all ${
              selectedFans.includes(fan.id) ? 'ring-2 ring-yellow-500' : ''
            }`}
          >
            <CardContent className="pt-4">
              <div className="flex items-start gap-4">
                <input
                  type="checkbox"
                  checked={selectedFans.includes(fan.id)}
                  onChange={() => toggleFanSelection(fan.id)}
                  disabled={!fan.email_verified || !fan.subscribed}
                  className="mt-1"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-bold text-white">{fan.name}</h3>
                    {!fan.email_verified && (
                      <Badge variant="outline" className="text-xs text-yellow-500 border-yellow-500/50">
                        Unverified
                      </Badge>
                    )}
                    {fan.email_verified && !fan.subscribed && (
                      <Badge variant="outline" className="text-xs text-gray-500">
                        Unsubscribed
                      </Badge>
                    )}
                    {fan.email_verified && fan.subscribed && (
                      <Badge className="text-xs bg-green-900/50 text-green-300">
                        ✓ Verified
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-400 mb-2">{fan.email}</p>
                  <div className="flex flex-wrap gap-2">
                    {fan.location && (
                      <Badge className="bg-pink-900/50 text-pink-200 text-xs">
                        <MapPin className="h-3 w-3 mr-1" />
                        {fan.location}
                      </Badge>
                    )}
                    {fan.favorite_artists && (
                      <Badge className="bg-yellow-900/50 text-yellow-200 text-xs">
                        {fan.favorite_artists}
                      </Badge>
                    )}
                    {fan.instagram_handle && (
                      <Badge className="bg-purple-900/50 text-purple-200 text-xs">
                        @{fan.instagram_handle}
                      </Badge>
                    )}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => deleteFanMutation.mutate(fan.id)}
                  className="text-red-400 hover:text-red-300"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredFans.length === 0 && (
        <div className="text-center py-12 text-gray-400">
          No fans found. Add fans to start building your audience!
        </div>
      )}
    </div>
  );
}