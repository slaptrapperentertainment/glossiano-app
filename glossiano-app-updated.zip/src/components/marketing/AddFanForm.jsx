import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { UserPlus, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function AddFanForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    location: '',
    favorite_artists: '',
    instagram_handle: '',
    phone: '',
    notes: '',
  });

  const queryClient = useQueryClient();

  const addFanMutation = useMutation({
    mutationFn: async (data) => {
      // Check for duplicates first
      const existing = await base44.entities.Fan.filter({ email: data.email });
      if (existing.length > 0) {
        throw new Error('This email already exists in your database');
      }
      return base44.entities.Fan.create({
        ...data,
        email_verified: true, // Manual adds are pre-verified
        subscribed: true,
        source: 'manual'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fans'] });
      toast.success('Fan added to your list!');
      setFormData({
        name: '',
        email: '',
        location: '',
        favorite_artists: '',
        instagram_handle: '',
        phone: '',
        notes: '',
      });
    },
    onError: (error) => {
      toast.error('Failed to add fan: ' + error.message);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    addFanMutation.mutate(formData);
  };

  return (
    <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <UserPlus className="h-5 w-5 text-yellow-400" />
          Add New Fan
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Name *
              </label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Fan's name"
                required
                className="bg-black/50 border-yellow-500/30 text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Email *
              </label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="email@example.com"
                required
                className="bg-black/50 border-yellow-500/30 text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Location (Bay Area)
              </label>
              <Input
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="Oakland, SF, San Jose..."
                className="bg-black/50 border-yellow-500/30 text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Favorite Artists
              </label>
              <Input
                value={formData.favorite_artists}
                onChange={(e) => setFormData({ ...formData, favorite_artists: e.target.value })}
                placeholder="E-40, Too Short, Mac Dre..."
                className="bg-black/50 border-yellow-500/30 text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Instagram Handle
              </label>
              <Input
                value={formData.instagram_handle}
                onChange={(e) => setFormData({ ...formData, instagram_handle: e.target.value })}
                placeholder="username"
                className="bg-black/50 border-yellow-500/30 text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Phone
              </label>
              <Input
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="(510) 555-0123"
                className="bg-black/50 border-yellow-500/30 text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Notes
            </label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Any additional info about this fan..."
              className="bg-black/50 border-yellow-500/30 text-white"
              rows={3}
            />
          </div>

          <Button
            type="submit"
            disabled={addFanMutation.isPending}
            className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600"
          >
            {addFanMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Adding Fan...
              </>
            ) : (
              <>
                <UserPlus className="mr-2 h-4 w-4" />
                Add Fan to List
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}