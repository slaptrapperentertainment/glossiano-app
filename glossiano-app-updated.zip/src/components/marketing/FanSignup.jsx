import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Mail, MapPin, Music2, Instagram, Loader2, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';

export default function FanSignup() {
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    location: '',
    favorite_artists: '',
    instagram_handle: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await base44.functions.invoke('verifyFanEmail', {
        email: formData.email,
        name: formData.name
      });

      if (response.data.isDuplicate) {
        toast.error('This email is already registered!');
        return;
      }

      setIsSuccess(true);
      toast.success('Check your email to verify! 📧');
      
      // Reset form after 3 seconds
      setTimeout(() => {
        setFormData({
          email: '',
          name: '',
          location: '',
          favorite_artists: '',
          instagram_handle: ''
        });
        setIsSuccess(false);
      }, 3000);

    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to sign up. Please try again.');
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-12"
      >
        <Mail className="h-20 w-20 text-yellow-400 mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-white mb-2">Check Your Email! 📧</h3>
        <p className="text-gray-400">We sent you a verification link. Click it to confirm and join the family!</p>
        <p className="text-xs text-gray-500 mt-2">(Check spam if you don't see it)</p>
      </motion.div>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
      <CardHeader>
        <CardTitle className="text-2xl font-black text-white flex items-center gap-2">
          <Music2 className="h-6 w-6 text-yellow-400" />
          JOIN THE BAY AREA RAP FAMILY
        </CardTitle>
        <CardDescription className="text-gray-300">
          Connect with West Coast Bay Area rap fans. Get early access to new releases, exclusive content, and event invites.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-300 mb-2 block">
              Name *
            </label>
            <Input
              type="text"
              placeholder="Your name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              className="bg-black/50 border-yellow-500/30 text-white placeholder:text-gray-500"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-300 mb-2 block">
              Email *
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                type="email"
                placeholder="your@email.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="pl-10 bg-black/50 border-yellow-500/30 text-white placeholder:text-gray-500"
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-300 mb-2 block">
              Location (City/Area)
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                type="text"
                placeholder="Oakland, SF Bay Area, etc."
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="pl-10 bg-black/50 border-yellow-500/30 text-white placeholder:text-gray-500"
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-300 mb-2 block">
              Favorite Bay Area Artists
            </label>
            <Input
              type="text"
              placeholder="E-40, Too $hort, Mac Dre, etc."
              value={formData.favorite_artists}
              onChange={(e) => setFormData({ ...formData, favorite_artists: e.target.value })}
              className="bg-black/50 border-yellow-500/30 text-white placeholder:text-gray-500"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-300 mb-2 block">
              Instagram Handle (optional)
            </label>
            <div className="relative">
              <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                type="text"
                placeholder="@yourusername"
                value={formData.instagram_handle}
                onChange={(e) => setFormData({ ...formData, instagram_handle: e.target.value })}
                className="pl-10 bg-black/50 border-yellow-500/30 text-white placeholder:text-gray-500"
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white font-bold py-6 text-lg"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Signing Up...
              </>
            ) : (
              <>
                <Music2 className="mr-2 h-5 w-5" />
                Join The Movement
              </>
            )}
          </Button>

          <p className="text-xs text-gray-500 text-center">
            By signing up, you'll receive exclusive music drops, event updates, and behind-the-scenes content.
          </p>
        </form>
      </CardContent>
    </Card>
  );
}