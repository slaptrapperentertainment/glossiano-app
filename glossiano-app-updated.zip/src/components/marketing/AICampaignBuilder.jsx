import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Sparkles, Share2, Instagram, Twitter, Youtube, Zap, Copy, Target, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

export default function AICampaignBuilder({ distributionId, distribution }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const queryClient = useQueryClient();

  const { data: campaigns = [] } = useQuery({
    queryKey: ['marketingCampaigns', distributionId],
    queryFn: () => base44.entities.MarketingCampaign.filter({
      distribution_id: distributionId
    }),
    enabled: !!distributionId
  });

  const currentCampaign = campaigns[0];

  const generateCampaign = async () => {
    setIsGenerating(true);
    try {
      const response = await base44.functions.invoke('generateMarketingCampaign', {
        distribution_id: distributionId
      });
      
      queryClient.invalidateQueries({ queryKey: ['marketingCampaigns', distributionId] });
      toast.success('Marketing campaign generated!');
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to generate campaign');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  const getPlatformIcon = (platform) => {
    const icons = {
      instagram: <Instagram className="w-5 h-5" />,
      tiktok: '🎵',
      twitter: <Twitter className="w-5 h-5" />,
      youtube: <Youtube className="w-5 h-5" />
    };
    return icons[platform] || <Share2 className="w-5 h-5" />;
  };

  if (!currentCampaign) {
    return (
      <Card className="border-purple-500/30 bg-gradient-to-br from-purple-900/20 to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            AI Marketing Campaign Builder
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 mb-4">
            Generate AI-powered marketing campaigns with social media content, promotional strategies, and audience targeting
          </p>
          <Button
            onClick={generateCampaign}
            disabled={isGenerating}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Campaign...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Marketing Campaign
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Campaign Overview */}
      <Card className="border-purple-500/30 bg-gradient-to-br from-purple-900/20 to-transparent">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-white">
                <Sparkles className="w-5 h-5 text-purple-400" />
                {currentCampaign.campaign_name}
              </CardTitle>
              <p className="text-gray-400 text-sm mt-1">Target Audience: {currentCampaign.target_audience}</p>
            </div>
            <Badge className={`${
              currentCampaign.status === 'active' 
                ? 'bg-green-500/20 text-green-400' 
                : 'bg-yellow-500/20 text-yellow-400'
            }`}>
              {currentCampaign.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-black/40 rounded-lg p-4 border border-purple-500/30 mb-4">
            <h4 className="text-sm font-semibold text-gray-300 mb-2">Campaign Concept:</h4>
            <p className="text-gray-300 text-sm leading-relaxed">{currentCampaign.campaign_idea}</p>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-black/30 rounded-lg p-3 border border-purple-500/20">
              <p className="text-gray-400 text-xs mb-1">Expected Reach</p>
              <p className="text-white font-bold text-lg">{(currentCampaign.expected_reach / 1000).toFixed(0)}K</p>
            </div>
            <div className="bg-black/30 rounded-lg p-3 border border-purple-500/20">
              <p className="text-gray-400 text-xs mb-1">Conversion Rate</p>
              <p className="text-white font-bold text-lg">{currentCampaign.estimated_conversion}%</p>
            </div>
            <div className="bg-black/30 rounded-lg p-3 border border-purple-500/20">
              <p className="text-gray-400 text-xs mb-1">ROI Potential</p>
              <p className="text-green-400 font-bold text-lg">3.2x</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Social Media Content */}
      <Card className="border-gray-700 bg-gray-900/40">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-pink-400" />
            Platform-Specific Content
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue={currentCampaign.social_content?.[0]?.platform} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-black/50 border border-gray-700">
              {currentCampaign.social_content?.map((content) => (
                <TabsTrigger key={content.platform} value={content.platform} className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-purple-600">
                  {getPlatformIcon(content.platform)}
                </TabsTrigger>
              ))}
            </TabsList>

            {currentCampaign.social_content?.map((content) => (
              <TabsContent key={content.platform} value={content.platform} className="mt-6 space-y-4">
                {/* Content */}
                <div>
                  <h4 className="text-sm font-semibold text-gray-300 mb-2">Post Content</h4>
                  <div className="bg-black/40 rounded-lg p-4 border border-gray-700">
                    <p className="text-gray-200 text-sm whitespace-pre-wrap">{content.content}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => copyToClipboard(content.content)}
                    className="mt-2 border-gray-600 hover:bg-gray-800"
                  >
                    <Copy className="w-3 h-3 mr-2" />
                    Copy Content
                  </Button>
                </div>

                {/* Visual Suggestions */}
                <div>
                  <h4 className="text-sm font-semibold text-gray-300 mb-2">Visual Suggestions</h4>
                  <div className="bg-black/40 rounded-lg p-4 border border-gray-700">
                    <p className="text-gray-300 text-sm">{content.suggested_visuals}</p>
                  </div>
                </div>

                {/* Best Posting Time */}
                <div className="flex items-center gap-2 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-3">
                  <Zap className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                  <p className="text-sm text-gray-300">
                    <span className="font-semibold">Best Posting Time:</span> {content.best_posting_time}
                  </p>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      {/* Promotion Strategy */}
      <Card className="border-green-500/30 bg-gradient-to-br from-green-900/20 to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-400" />
            Promotion Strategy
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-black/40 rounded-lg p-4 border border-green-500/30 mb-4">
            <p className="text-gray-300 text-sm whitespace-pre-wrap">{currentCampaign.promotion_strategy}</p>
          </div>

          {/* Budget Allocation */}
          <div>
            <h4 className="text-sm font-semibold text-gray-300 mb-3">Budget Allocation</h4>
            <div className="space-y-3">
              {currentCampaign.budget_allocation && (
                <>
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-400">Paid Ads</span>
                      <span className="text-white font-bold">{(currentCampaign.budget_allocation.paid_ads * 100).toFixed(0)}%</span>
                    </div>
                    <div className="h-2 bg-black/30 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-blue-600 to-blue-500" style={{ width: `${currentCampaign.budget_allocation.paid_ads * 100}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-400">Influencer Partnerships</span>
                      <span className="text-white font-bold">{(currentCampaign.budget_allocation.influencer * 100).toFixed(0)}%</span>
                    </div>
                    <div className="h-2 bg-black/30 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-pink-600 to-pink-500" style={{ width: `${currentCampaign.budget_allocation.influencer * 100}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-400">Organic Growth</span>
                      <span className="text-white font-bold">{(currentCampaign.budget_allocation.organic * 100).toFixed(0)}%</span>
                    </div>
                    <div className="h-2 bg-black/30 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-green-600 to-green-500" style={{ width: `${currentCampaign.budget_allocation.organic * 100}%` }} />
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}