import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, FileSpreadsheet, Loader2, CheckCircle2, AlertCircle, Download } from 'lucide-react';
import { toast } from 'sonner';

export default function ImportFans() {
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const queryClient = useQueryClient();

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setImportResult(null);
    }
  };

  const handleImport = async () => {
    if (!file) {
      toast.error('Please select a file first');
      return;
    }

    setIsUploading(true);

    try {
      // Upload file first
      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      // Import data into Fan entity
      const response = await fetch('/api/import-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          file_url: file_url,
          entity_name: 'Fan'
        })
      });

      const result = await response.json();

      if (result.success) {
        setImportResult(result);
        toast.success(`Successfully imported ${result.successful_records} fans!`);
        queryClient.invalidateQueries({ queryKey: ['fans'] });
        setFile(null);
      } else {
        toast.error('Import failed: ' + result.error);
        setImportResult(result);
      }
    } catch (error) {
      toast.error('Failed to import: ' + error.message);
    } finally {
      setIsUploading(false);
    }
  };

  const downloadTemplate = () => {
    const csvContent = 'name,email,location,favorite_artists,instagram_handle,phone,notes\nJohn Doe,john@example.com,Oakland,"E-40, Too $hort",johndoe,(510) 555-0123,Met at show\nJane Smith,jane@example.com,San Francisco,"Mac Dre",janesmith,,Instagram follower';
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'fan_import_template.csv';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    
    toast.success('Template downloaded!');
  };

  return (
    <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Upload className="h-5 w-5 text-yellow-400" />
          Import Real Contact Lists
        </CardTitle>
        <CardDescription className="text-gray-400">
          Upload CSV or Excel files from MailChimp, Gmail, Instagram exports, or any other platform
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Instructions */}
        <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-4 space-y-2">
          <p className="text-sm text-yellow-200 font-medium">Required Columns:</p>
          <ul className="text-xs text-yellow-200/80 space-y-1 ml-4 list-disc">
            <li><strong>name</strong> (required) - Fan's full name</li>
            <li><strong>email</strong> (required) - Email address</li>
            <li><strong>location</strong> - City/Area (Oakland, SF, etc.)</li>
            <li><strong>favorite_artists</strong> - Favorite Bay Area artists</li>
            <li><strong>instagram_handle</strong> - Instagram username</li>
            <li><strong>phone</strong> - Phone number</li>
            <li><strong>notes</strong> - Additional info</li>
          </ul>
        </div>

        {/* Download Template */}
        <Button
          variant="outline"
          onClick={downloadTemplate}
          className="w-full border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
        >
          <Download className="mr-2 h-4 w-4" />
          Download CSV Template
        </Button>

        {/* File Upload */}
        <div className="border-2 border-dashed border-yellow-500/30 rounded-lg p-8 text-center hover:border-yellow-500/50 transition-colors">
          <input
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleFileSelect}
            className="hidden"
            id="fan-import-file"
          />
          <label htmlFor="fan-import-file" className="cursor-pointer">
            <FileSpreadsheet className="h-12 w-12 text-yellow-400 mx-auto mb-3" />
            {file ? (
              <p className="text-white font-medium">{file.name}</p>
            ) : (
              <>
                <p className="text-white font-medium mb-1">Click to upload CSV or Excel file</p>
                <p className="text-gray-400 text-sm">Supports .csv, .xlsx, .xls files</p>
              </>
            )}
          </label>
        </div>

        {/* Import Button */}
        <Button
          onClick={handleImport}
          disabled={!file || isUploading}
          className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600"
        >
          {isUploading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Importing Contacts...
            </>
          ) : (
            <>
              <Upload className="mr-2 h-4 w-4" />
              Import Fans
            </>
          )}
        </Button>

        {/* Import Results */}
        {importResult && (
          <div className={`rounded-lg p-4 ${
            importResult.success 
              ? 'bg-green-900/20 border border-green-500/30' 
              : 'bg-red-900/20 border border-red-500/30'
          }`}>
            <div className="flex items-start gap-3">
              {importResult.success ? (
                <CheckCircle2 className="h-5 w-5 text-green-400 mt-0.5" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-400 mt-0.5" />
              )}
              <div className="flex-1">
                <p className={`font-medium ${importResult.success ? 'text-green-200' : 'text-red-200'}`}>
                  {importResult.success 
                    ? `Successfully imported ${importResult.successful_records} fans!`
                    : 'Import failed'
                  }
                </p>
                {importResult.failed_records > 0 && (
                  <p className="text-sm text-yellow-200 mt-1">
                    {importResult.failed_records} records failed (duplicates or missing required fields)
                  </p>
                )}
                {importResult.error && (
                  <p className="text-sm text-red-200 mt-1">{importResult.error}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Export Sources */}
        <div className="bg-black/30 border border-yellow-500/20 rounded-lg p-4">
          <p className="text-xs text-gray-400 mb-2">Export your contacts from:</p>
          <div className="grid grid-cols-2 gap-2 text-xs text-gray-500">
            <div>• MailChimp</div>
            <div>• Constant Contact</div>
            <div>• Gmail Contacts</div>
            <div>• Instagram exports</div>
            <div>• Eventbrite</div>
            <div>• Bandcamp</div>
            <div>• SoundCloud</div>
            <div>• Shopify</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}