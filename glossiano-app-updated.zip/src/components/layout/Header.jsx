import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Menu, Search, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useCart } from '@/components/cart/CartContext';

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const { itemCount } = useCart();

  const { data: settings = [] } = useQuery({
    queryKey: ['settings'],
    queryFn: () => base44.entities.Settings.list('', 1)
  });

  const storeName = settings[0]?.store_name || 'VINTAGE RECORDS';
  const logoUrl = settings[0]?.logo_url;

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-neutral-100">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80 bg-white">
              <nav className="flex flex-col gap-4 mt-8">
                <Link 
                  to={createPageUrl('Home')} 
                  className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Home
                </Link>
                <Link 
                  to={createPageUrl('Artist')} 
                  className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Artist
                </Link>
                <Link 
                  to={createPageUrl('MusicStudio')} 
                  className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Studio
                </Link>
                <Link 
                  to={createPageUrl('Catalog')} 
                  className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Music
                </Link>
                <Link 
                  to={createPageUrl('MusicShop')} 
                  className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Buy Music
                </Link>
                <Link 
                   to={createPageUrl('PrivateLibrary')} 
                   className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                   onClick={() => setIsOpen(false)}
                 >
                   Library
                 </Link>
                 <Link 
                   to={createPageUrl('FanWall')} 
                   className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                   onClick={() => setIsOpen(false)}
                 >
                   Fan Wall
                 </Link>
                <Link 
                  to={createPageUrl('Memberships')} 
                  className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Memberships
                </Link>
                 <Link 
                   to={createPageUrl('MerchStore')} 
                   className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                   onClick={() => setIsOpen(false)}
                 >
                   Merch
                 </Link>
                 <Link 
                   to={createPageUrl('Distribution')} 
                   className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors"
                   onClick={() => setIsOpen(false)}
                 >
                   Distribution
                 </Link>
                 <Link 
                   to={createPageUrl('AdminDashboard')} 
                   className="text-lg font-light tracking-wide hover:text-amber-600 transition-colors border-t pt-4 mt-4"
                   onClick={() => setIsOpen(false)}
                 >
                   Admin
                 </Link>
                 </nav>
            </SheetContent>
          </Sheet>

          {/* Logo */}
          <Link to={createPageUrl('Home')} className="flex items-center gap-3">
            {logoUrl && (
              <img src={logoUrl} alt={storeName} className="h-10 w-10 object-contain" />
            )}
            <span className="text-xl md:text-2xl font-bold tracking-tight text-neutral-900">
              {storeName}
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <Link 
              to={createPageUrl('Artist')} 
              className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
            >
              Artist
            </Link>
            <Link 
              to={createPageUrl('MusicStudio')} 
              className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
            >
              Studio
            </Link>
            <Link 
              to={createPageUrl('Catalog')} 
              className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
            >
              Music
            </Link>
            <Link 
               to={createPageUrl('MusicShop')} 
               className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
             >
               Buy Music
             </Link>
             <Link 
               to={createPageUrl('PrivateLibrary')} 
               className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
             >
               Library
             </Link>
             <Link 
               to={createPageUrl('FanWall')} 
               className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
             >
               Fan Wall
             </Link>
             <Link 
               to={createPageUrl('AdminFanWall')} 
               className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
             >
               Admin
             </Link>
             <Link 
               to={createPageUrl('AdminMerch')} 
               className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
             >
               Merch Admin
             </Link>
             <Link 
                to={createPageUrl('Memberships')} 
                className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
              >
                Memberships
              </Link>
             <Link 
                to={createPageUrl('MerchStore')} 
                className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
              >
                Merch
              </Link>
              <Link 
                to={createPageUrl('Distribution')} 
                className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
              >
                Distribution
              </Link>
              <Link 
                to={createPageUrl('AdminDashboard')} 
                className="text-sm font-light tracking-wide hover:text-amber-600 transition-colors"
              >
                Admin
              </Link>
              </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            <Link to={createPageUrl('Catalog') + '?search=true'}>
              <Button variant="ghost" size="icon">
                <Search className="h-5 w-5" />
              </Button>
            </Link>
            <Link to={createPageUrl('Cart')}>
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 bg-amber-500 text-white text-xs rounded-full flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}