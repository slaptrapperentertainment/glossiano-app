import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Disc3, Mail, MapPin, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-neutral-950 text-white">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <Disc3 className="h-8 w-8 text-yellow-400" />
              <div>
                <span className="text-xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">SLAP TRAPPER</span>
                <span className="block text-[10px] tracking-[0.3em] text-neutral-400 -mt-1">
                  ENTERTAINMENT
                </span>
              </div>
            </div>
            <p className="text-neutral-400 font-light leading-relaxed max-w-sm">
              Premium beats, exclusive tracks, and fire music straight from the underground.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs uppercase tracking-widest text-neutral-500 mb-4">Navigate</h4>
            <nav className="flex flex-col gap-3">
              <Link to={createPageUrl('Home')} className="text-neutral-300 hover:text-yellow-400 transition-colors text-sm">
                Home
              </Link>
              <Link to={createPageUrl('Artist')} className="text-neutral-300 hover:text-yellow-400 transition-colors text-sm">
                Artist Profile
              </Link>
              <Link to={createPageUrl('Catalog')} className="text-neutral-300 hover:text-yellow-400 transition-colors text-sm">
                All Music
              </Link>
              <Link to={createPageUrl('Cart')} className="text-neutral-300 hover:text-yellow-400 transition-colors text-sm">
                Cart
              </Link>
            </nav>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xs uppercase tracking-widest text-neutral-500 mb-4">Contact</h4>
            <div className="space-y-3">
              <a href="mailto:info@slaptrapper.com" className="flex items-center gap-2 text-neutral-300 hover:text-yellow-400 transition-colors text-sm">
                <Mail className="h-4 w-4" />
                info@slaptrapper.com
              </a>
              <a href="https://www.instagram.com/theslaptrapper" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-neutral-300 hover:text-yellow-400 transition-colors text-sm">
                <Instagram className="h-4 w-4" />
                @theslaptrapper
              </a>
              <div className="flex items-center gap-2 text-neutral-400 text-sm">
                <MapPin className="h-4 w-4" />
                Worldwide Distribution
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-neutral-800 mt-12 pt-8">
          <p className="text-neutral-500 text-sm text-center">
            © {new Date().getFullYear()} Slap Trapper Entertainment. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}