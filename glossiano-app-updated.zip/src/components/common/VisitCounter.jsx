import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Eye } from 'lucide-react';

export default function VisitCounter() {
  const [hasVisited, setHasVisited] = useState(false);
  const queryClient = useQueryClient();

  const { data: counters = [] } = useQuery({
    queryKey: ['visit-counter'],
    queryFn: () => base44.entities.VisitCounter.list('-created_date', 1)
  });

  const updateCounterMutation = useMutation({
    mutationFn: async (id) => {
      const counter = counters[0];
      return base44.entities.VisitCounter.update(id, { count: counter.count + 1 });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['visit-counter'] });
    }
  });

  const createCounterMutation = useMutation({
    mutationFn: async () => {
      return base44.entities.VisitCounter.create({ count: 1, date: new Date().toISOString() });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['visit-counter'] });
    }
  });

  useEffect(() => {
    const visited = sessionStorage.getItem('has-visited');
    if (!visited && counters.length > 0) {
      updateCounterMutation.mutate(counters[0].id);
      sessionStorage.setItem('has-visited', 'true');
      setHasVisited(true);
    } else if (!visited && counters.length === 0) {
      createCounterMutation.mutate();
      sessionStorage.setItem('has-visited', 'true');
      setHasVisited(true);
    }
  }, [counters]);

  const count = counters[0]?.count || 0;

  return (
    <div className="flex items-center gap-2 text-neutral-500 text-sm">
      <Eye className="h-4 w-4" />
      <span>{count.toLocaleString()} visitas</span>
    </div>
  );
}