import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useCart } from '@/components/cart/CartContext';

export default function StackView({ products = [] }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { addToCart } = useCart();

  if (!products || products.length === 0) {
    return (
      <div className="text-center py-20">
        <p className="text-neutral-500">No hay productos disponibles</p>
      </div>
    );
  }

  const currentProduct = products[currentIndex];
  
  if (!currentProduct) {
    return (
      <div className="text-center py-20">
        <p className="text-neutral-500">Cargando productos...</p>
      </div>
    );
  }

  const goNext = () => {
    setCurrentIndex((prev) => (prev + 1) % products.length);
  };

  const goPrev = () => {
    setCurrentIndex((prev) => (prev - 1 + products.length) % products.length);
  };

  const conditionLabels = {
    mint: 'Mint',
    near_mint: 'Near Mint',
    very_good: 'Very Good',
    good: 'Good',
    fair: 'Fair'
  };

  return (
    <div className="relative h-[600px] flex items-center justify-center">
      {/* Navigation Buttons */}
      <Button
        onClick={goPrev}
        size="icon"
        variant="ghost"
        className="absolute left-4 z-20 bg-white/90 hover:bg-white shadow-lg h-12 w-12"
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        onClick={goNext}
        size="icon"
        variant="ghost"
        className="absolute right-4 z-20 bg-white/90 hover:bg-white shadow-lg h-12 w-12"
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      {/* Stack of Products */}
      <div className="relative w-full max-w-md h-full flex items-center justify-center">
        <AnimatePresence mode="wait">
          {/* Current Product */}
          <motion.div
            key={currentProduct.id}
            initial={{ scale: 0.8, rotateY: -90, opacity: 0 }}
            animate={{ scale: 1, rotateY: 0, opacity: 1 }}
            exit={{ scale: 0.8, rotateY: 90, opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="absolute bg-white rounded-lg shadow-2xl p-6 w-full max-w-sm"
            style={{ transform: 'translateZ(0)' }}
          >
            <Link to={createPageUrl('ProductDetail') + `?id=${currentProduct.id}`}>
              <img
                src={currentProduct.main_image}
                alt={currentProduct.title}
                className="w-full aspect-square object-cover rounded-md mb-4"
              />
            </Link>
            
            <div className="space-y-2">
              <h3 className="text-xl font-bold text-neutral-900">{currentProduct.title}</h3>
              {currentProduct.artist_brand && (
                <p className="text-sm text-neutral-600">{currentProduct.artist_brand}</p>
              )}
              
              <div className="flex items-center justify-between py-2">
                <span className="text-2xl font-bold text-amber-600">
                  ${currentProduct.price?.toFixed(2)}
                </span>
                {currentProduct.condition && (
                  <span className="text-xs text-neutral-500">
                    {conditionLabels[currentProduct.condition]}
                  </span>
                )}
              </div>

              <div className="flex gap-2">
                <Link to={createPageUrl('ProductDetail') + `?id=${currentProduct.id}`} className="flex-1">
                  <Button variant="outline" className="w-full">
                    Ver Detalles
                  </Button>
                </Link>
                <Button
                  onClick={() => addToCart(currentProduct, 1)}
                  className="flex-1 bg-neutral-900 hover:bg-neutral-800"
                  disabled={currentProduct.stock === 0}
                >
                  {currentProduct.stock === 0 ? 'Agotado' : 'Añadir al Carrito'}
                </Button>
              </div>
            </div>

            {/* Stack indicator */}
            <div className="text-center mt-4 text-sm text-neutral-500">
              {currentIndex + 1} / {products.length}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Background cards for stack effect */}
        <div
          className="absolute bg-white rounded-lg shadow-xl w-full max-w-sm h-[500px] -z-10"
          style={{ transform: 'translateY(10px) scale(0.95)', opacity: 0.5 }}
        />
        <div
          className="absolute bg-white rounded-lg shadow-lg w-full max-w-sm h-[500px] -z-20"
          style={{ transform: 'translateY(20px) scale(0.9)', opacity: 0.3 }}
        />
      </div>
    </div>
  );
}