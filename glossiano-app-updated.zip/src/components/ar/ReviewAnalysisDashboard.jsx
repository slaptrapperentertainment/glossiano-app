import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, MessageSquare, ThumbsUp, ThumbsDown, BarChart3, TrendingUp, Lightbulb } from 'lucide-react';
import { toast } from 'sonner';

export default function ReviewAnalysisDashboard({ distributionId, distribution }) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const queryClient = useQueryClient();

  const { data: analyses = [] } = useQuery({
    queryKey: ['reviewAnalysis', distributionId],
    queryFn: () => base44.entities.ReviewAnalysis.filter({
      distribution_id: distributionId
    }),
    enabled: !!distributionId
  });

  const currentAnalysis = analyses[0];

  const analyzeReviews = async () => {
    setIsAnalyzing(true);
    try {
      const response = await base44.functions.invoke('analyzeReleaseReviews', {
        distribution_id: distributionId
      });
      
      queryClient.invalidateQueries({ queryKey: ['reviewAnalysis', distributionId] });
      toast.success('Review analysis complete!');
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to analyze reviews');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSentimentColor = (score) => {
    if (score >= 60) return 'text-green-400';
    if (score >= 20) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getReceptionBadge = (status) => {
    const styles = {
      breakthrough: 'bg-green-500/20 text-green-400 border-green-500/40',
      well_received: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
      mixed: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40',
      underperforming: 'bg-red-500/20 text-red-400 border-red-500/40'
    };
    return styles[status] || 'bg-gray-500/20 text-gray-400';
  };

  if (!currentAnalysis) {
    return (
      <Card className="border-orange-500/30 bg-gradient-to-br from-orange-900/20 to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-orange-400" />
            Review Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 mb-4">
            Analyze reviews from blogs, music sites, and user comments to understand public reception, sentiment trends, and areas for improvement.
          </p>
          <Button
            onClick={analyzeReviews}
            disabled={isAnalyzing}
            className="w-full bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing Reviews...
              </>
            ) : (
              <>
                <BarChart3 className="w-4 h-4 mr-2" />
                Analyze Public Reception
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Summary */}
      <Card className="border-orange-500/30 bg-gradient-to-br from-orange-900/20 to-transparent">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-white">
                <MessageSquare className="w-5 h-5 text-orange-400" />
                Public Reception Analysis
              </CardTitle>
              <p className="text-gray-400 text-sm mt-1">{currentAnalysis.total_reviews_analyzed} reviews analyzed</p>
            </div>
            <Badge className={`border ${getReceptionBadge(currentAnalysis.public_reception_status)}`}>
              {currentAnalysis.public_reception_status.toUpperCase().replace('_', ' ')}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-black/40 rounded-lg p-4 border border-orange-500/30 mb-4">
            <p className="text-gray-300 text-sm leading-relaxed">{currentAnalysis.summary}</p>
          </div>

          {/* Sentiment Score */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-black/30 rounded-lg p-4 border border-orange-500/20 mb-4"
          >
            <p className="text-gray-400 text-sm mb-2">Overall Sentiment Score</p>
            <div className="flex items-center gap-3">
              <div className={`text-4xl font-bold ${getSentimentColor(currentAnalysis.sentiment_score)}`}>
                {currentAnalysis.sentiment_score}
              </div>
              <div className="flex-1">
                <div className="h-3 bg-gradient-to-r from-red-600 via-yellow-500 to-green-600 rounded-full" />
                <p className="text-gray-400 text-xs mt-1">Very Negative ← → Very Positive</p>
              </div>
            </div>
          </motion.div>

          {/* Sentiment Distribution */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-gradient-to-br from-green-500/10 to-transparent border border-green-500/30 rounded-lg p-3">
              <ThumbsUp className="w-4 h-4 text-green-400 mb-1" />
              <p className="text-gray-400 text-xs mb-1">Positive</p>
              <p className="text-green-400 font-bold text-lg">{currentAnalysis.sentiment_distribution.positive_percentage}%</p>
            </div>
            <div className="bg-gradient-to-br from-yellow-500/10 to-transparent border border-yellow-500/30 rounded-lg p-3">
              <BarChart3 className="w-4 h-4 text-yellow-400 mb-1" />
              <p className="text-gray-400 text-xs mb-1">Neutral</p>
              <p className="text-yellow-400 font-bold text-lg">{currentAnalysis.sentiment_distribution.neutral_percentage}%</p>
            </div>
            <div className="bg-gradient-to-br from-red-500/10 to-transparent border border-red-500/30 rounded-lg p-3">
              <ThumbsDown className="w-4 h-4 text-red-400 mb-1" />
              <p className="text-gray-400 text-xs mb-1">Negative</p>
              <p className="text-red-400 font-bold text-lg">{currentAnalysis.sentiment_distribution.negative_percentage}%</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Analysis Tabs */}
      <Tabs defaultValue="praise" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-black/50 border border-orange-500/30">
          <TabsTrigger value="praise" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-600 data-[state=active]:to-amber-600">
            <ThumbsUp className="w-4 h-4 mr-2" />
            Praise Points
          </TabsTrigger>
          <TabsTrigger value="criticism" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-600 data-[state=active]:to-amber-600">
            <ThumbsDown className="w-4 h-4 mr-2" />
            Criticism
          </TabsTrigger>
          <TabsTrigger value="insights" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-600 data-[state=active]:to-amber-600">
            <Lightbulb className="w-4 h-4 mr-2" />
            Insights
          </TabsTrigger>
        </TabsList>

        {/* Praise Points */}
        <TabsContent value="praise" className="mt-6">
          <div className="space-y-3">
            {currentAnalysis.praise_points?.length > 0 ? (
              currentAnalysis.praise_points.map((point, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-black/30 rounded-lg p-4 border border-green-500/20 hover:border-green-500/40 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="text-white font-semibold text-sm">{point.point}</h4>
                    <Badge className={`${
                      point.impact === 'high' ? 'bg-green-500/30 text-green-300' :
                      point.impact === 'medium' ? 'bg-yellow-500/30 text-yellow-300' :
                      'bg-gray-500/30 text-gray-300'
                    }`}>
                      {point.impact.toUpperCase()} IMPACT
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 bg-gray-700 rounded-full flex-1 overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-green-500 to-emerald-500" style={{ width: `${(point.frequency / 5) * 100}%` }} />
                    </div>
                    <span className="text-gray-400 text-xs">{point.frequency} mentions</span>
                  </div>
                </motion.div>
              ))
            ) : (
              <p className="text-gray-400 text-sm">No praise points identified</p>
            )}
          </div>
        </TabsContent>

        {/* Criticism Points */}
        <TabsContent value="criticism" className="mt-6">
          <div className="space-y-3">
            {currentAnalysis.criticism_points?.length > 0 ? (
              currentAnalysis.criticism_points.map((point, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-black/30 rounded-lg p-4 border border-red-500/20 hover:border-red-500/40 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="text-white font-semibold text-sm">{point.point}</h4>
                    <Badge className={`${
                      point.impact === 'high' ? 'bg-red-500/30 text-red-300' :
                      point.impact === 'medium' ? 'bg-orange-500/30 text-orange-300' :
                      'bg-gray-500/30 text-gray-300'
                    }`}>
                      {point.impact.toUpperCase()} IMPACT
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 bg-gray-700 rounded-full flex-1 overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-red-500 to-orange-500" style={{ width: `${(point.frequency / 5) * 100}%` }} />
                    </div>
                    <span className="text-gray-400 text-xs">{point.frequency} mentions</span>
                  </div>
                </motion.div>
              ))
            ) : (
              <p className="text-gray-400 text-sm">No criticism identified</p>
            )}
          </div>
        </TabsContent>

        {/* Insights & Improvements */}
        <TabsContent value="insights" className="mt-6 space-y-4">
          {/* Key Themes */}
          <Card className="border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-white">Key Themes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {currentAnalysis.key_themes?.map((theme, idx) => (
                  <Badge key={idx} className="bg-orange-500/20 text-orange-300 border-orange-500/40">
                    {theme}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Areas for Improvement */}
          <Card className="border-orange-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-yellow-400" />
                Areas for Improvement
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {currentAnalysis.areas_for_improvement?.map((improvement, idx) => (
                  <div key={idx} className="flex gap-3 text-sm">
                    <span className="text-yellow-400 font-bold flex-shrink-0">{idx + 1}.</span>
                    <p className="text-gray-300">{improvement}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Review Sources */}
          <Card className="border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-white">Review Sources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {currentAnalysis.review_sources?.map((source, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-black/30 rounded-lg border border-orange-500/20">
                    <div>
                      <p className="text-white font-semibold text-sm">{source.source}</p>
                      <p className="text-gray-400 text-xs">{source.review_count} reviews</p>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold text-sm ${getSentimentColor(source.average_rating * 20 - 100)}`}>
                        {source.average_rating.toFixed(1)}/5
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}