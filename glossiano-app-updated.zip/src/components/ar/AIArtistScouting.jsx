import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Zap, TrendingUp, Target, AlertCircle, CheckCircle2, BarChart3, Award } from 'lucide-react';
import { toast } from 'sonner';

export default function AIArtistScouting({ distributionId, distribution }) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const queryClient = useQueryClient();

  const { data: scouts = [] } = useQuery({
    queryKey: ['arScouts', distributionId],
    queryFn: () => base44.entities.ARArtistScout.filter({
      distribution_id: distributionId
    }),
    enabled: !!distributionId
  });

  const currentScout = scouts[0];

  const analyzeArtist = async () => {
    setIsAnalyzing(true);
    try {
      const response = await base44.functions.invoke('aiArtistScouting', {
        distribution_id: distributionId
      });
      
      queryClient.invalidateQueries({ queryKey: ['arScouts', distributionId] });
      toast.success('A&R analysis complete!');
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to analyze artist');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getInvestmentColor = (recommendation) => {
    const colors = {
      strong_buy: 'bg-green-500/20 text-green-400 border-green-500/40',
      buy: 'bg-lime-500/20 text-lime-400 border-lime-500/40',
      hold: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40',
      sell: 'bg-red-500/20 text-red-400 border-red-500/40'
    };
    return colors[recommendation] || 'bg-gray-500/20 text-gray-400';
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 65) return 'text-lime-400';
    if (score >= 50) return 'text-yellow-400';
    return 'text-red-400';
  };

  if (!currentScout) {
    return (
      <Card className="border-blue-500/30 bg-gradient-to-br from-blue-900/20 to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-blue-400" />
            A&R Artist Scouting Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 mb-4">
            Get AI-powered analysis of commercial appeal, hit potential, and artist growth prospects. Includes song structure analysis, melody evaluation, and strategic recommendations.
          </p>
          <Button
            onClick={analyzeArtist}
            disabled={isAnalyzing}
            className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing Artist...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                Start A&R Analysis
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Executive Summary */}
      <Card className="border-blue-500/30 bg-gradient-to-br from-blue-900/20 to-transparent">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-white">
                <Award className="w-5 h-5 text-blue-400" />
                A&R Analysis Report
              </CardTitle>
              <p className="text-gray-400 text-sm mt-1">Analyzed: {new Date(currentScout.analysis_date).toLocaleDateString()}</p>
            </div>
            <Badge className={`border ${getInvestmentColor(currentScout.investment_recommendation)}`}>
              {currentScout.investment_recommendation.toUpperCase().replace('_', ' ')}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-black/40 rounded-lg p-4 border border-blue-500/30 mb-4">
            <p className="text-gray-300 text-sm leading-relaxed">{currentScout.detailed_report}</p>
          </div>

          {/* Score Summary */}
          <div className="grid grid-cols-3 gap-3">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-black/30 rounded-lg p-3 border border-blue-500/20"
            >
              <p className="text-gray-400 text-xs mb-1">Commercial Appeal</p>
              <p className={`font-bold text-2xl ${getScoreColor(currentScout.commercial_appeal.score)}`}>
                {currentScout.commercial_appeal.score}
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-black/30 rounded-lg p-3 border border-blue-500/20"
            >
              <p className="text-gray-400 text-xs mb-1">Hit Potential</p>
              <p className={`font-bold text-2xl ${getScoreColor(currentScout.hit_potential.hit_score)}`}>
                {currentScout.hit_potential.hit_score}
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-black/30 rounded-lg p-3 border border-blue-500/20"
            >
              <p className="text-gray-400 text-xs mb-1">Artist Growth</p>
              <p className={`font-bold text-2xl ${getScoreColor(currentScout.artist_potential.emerging_artist_score)}`}>
                {currentScout.artist_potential.emerging_artist_score}
              </p>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Analysis Tabs */}
      <Tabs defaultValue="commercial" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-black/50 border border-blue-500/30">
          <TabsTrigger value="commercial" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600">
            <Target className="w-4 h-4 mr-2" />
            Commercial Appeal
          </TabsTrigger>
          <TabsTrigger value="hit" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600">
            <TrendingUp className="w-4 h-4 mr-2" />
            Hit Potential
          </TabsTrigger>
          <TabsTrigger value="artist" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600">
            <BarChart3 className="w-4 h-4 mr-2" />
            Artist Growth
          </TabsTrigger>
        </TabsList>

        {/* Commercial Appeal Tab */}
        <TabsContent value="commercial" className="mt-6 space-y-4">
          <Card className="border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white">Song Structure</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-300 text-sm">{currentScout.commercial_appeal.song_structure.structure_type}</span>
                  <span className={`font-bold ${getScoreColor(currentScout.commercial_appeal.song_structure.structure_score)}`}>
                    {currentScout.commercial_appeal.song_structure.structure_score}/100
                  </span>
                </div>
                <div className="h-2 bg-black/30 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-600 to-cyan-500"
                    style={{ width: `${currentScout.commercial_appeal.song_structure.structure_score}%` }}
                  />
                </div>
              </div>
              <p className="text-gray-400 text-sm mt-3">{currentScout.commercial_appeal.song_structure.analysis}</p>
            </CardContent>
          </Card>

          <Card className="border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white">Melody Analysis</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-300 text-sm">Memorability</span>
                  <span className={`font-bold ${getScoreColor(currentScout.commercial_appeal.melody_analysis.memorability_score)}`}>
                    {currentScout.commercial_appeal.melody_analysis.memorability_score}/100
                  </span>
                </div>
                <div className="h-2 bg-black/30 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-pink-600 to-purple-500"
                    style={{ width: `${currentScout.commercial_appeal.melody_analysis.memorability_score}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-300 text-sm">Uniqueness</span>
                  <span className={`font-bold ${getScoreColor(currentScout.commercial_appeal.melody_analysis.uniqueness_score)}`}>
                    {currentScout.commercial_appeal.melody_analysis.uniqueness_score}/100
                  </span>
                </div>
                <div className="h-2 bg-black/30 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-pink-600 to-purple-500"
                    style={{ width: `${currentScout.commercial_appeal.melody_analysis.uniqueness_score}%` }}
                  />
                </div>
              </div>
              <p className="text-gray-400 text-sm mt-3">{currentScout.commercial_appeal.melody_analysis.analysis}</p>
            </CardContent>
          </Card>

          <Card className="border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white">Lyrical Content</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-300 text-sm">Relatability</span>
                  <span className={`font-bold ${getScoreColor(currentScout.commercial_appeal.lyrical_content.relatability_score)}`}>
                    {currentScout.commercial_appeal.lyrical_content.relatability_score}/100
                  </span>
                </div>
                <div className="h-2 bg-black/30 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-yellow-600 to-orange-500"
                    style={{ width: `${currentScout.commercial_appeal.lyrical_content.relatability_score}%` }}
                  />
                </div>
              </div>
              <div>
                <p className="text-gray-300 text-sm font-semibold mb-2">Commercial Themes:</p>
                <div className="flex flex-wrap gap-2">
                  {currentScout.commercial_appeal.lyrical_content.commercial_themes.map((theme, idx) => (
                    <Badge key={idx} className="bg-yellow-500/20 text-yellow-300 border-yellow-500/40">
                      {theme}
                    </Badge>
                  ))}
                </div>
              </div>
              <p className="text-gray-400 text-sm mt-3">{currentScout.commercial_appeal.lyrical_content.analysis}</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Hit Potential Tab */}
        <TabsContent value="hit" className="mt-6 space-y-4">
          <Card className="border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white">Chart Prediction</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-4">
                <p className="text-gray-300 text-sm">
                  <span className="font-semibold text-green-400">Expected Performance: </span>
                  {currentScout.hit_potential.peak_chart_prediction}
                </p>
              </div>
              <p className="text-gray-400 text-sm">{currentScout.hit_potential.market_timing}</p>
            </CardContent>
          </Card>

          <Card className="border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white">Comparable Tracks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {currentScout.hit_potential.comparable_tracks.map((track, idx) => (
                  <div key={idx} className="bg-black/30 rounded-lg p-3 border border-green-500/20">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="text-white font-semibold text-sm">{track.track_name}</p>
                        <p className="text-gray-400 text-xs">{track.artist}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-green-400 font-bold text-sm">{track.similarity_percentage}% Match</p>
                        <p className="text-gray-400 text-xs">{track.chart_performance}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white">Hit Potential Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 text-sm leading-relaxed">{currentScout.hit_potential.analysis}</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Artist Growth Tab */}
        <TabsContent value="artist" className="mt-6 space-y-4">
          <Card className="border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white">Career Stage & Growth</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
                <p className="text-gray-300 text-sm">
                  <span className="font-semibold text-purple-400">Career Stage: </span>
                  <span className="capitalize">{currentScout.artist_potential.career_stage.replace('_', ' ')}</span>
                </p>
              </div>

              <div>
                <p className="text-gray-300 text-sm font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  Growth Indicators
                </p>
                <div className="space-y-2">
                  {currentScout.artist_potential.growth_indicators.map((indicator, idx) => (
                    <div key={idx} className="flex gap-2 text-gray-300 text-sm">
                      <span className="text-green-400 font-bold">+</span>
                      <span>{indicator}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-gray-300 text-sm font-semibold mb-3 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400" />
                  Risk Factors
                </p>
                <div className="space-y-2">
                  {currentScout.artist_potential.risk_factors.map((risk, idx) => (
                    <div key={idx} className="flex gap-2 text-gray-300 text-sm">
                      <span className="text-red-400 font-bold">!</span>
                      <span>{risk}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white">Strategic Recommendations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {currentScout.artist_potential.recommendations.map((rec, idx) => (
                  <div key={idx} className="bg-black/30 rounded-lg p-3 border border-purple-500/20 flex gap-3">
                    <span className="text-purple-400 font-bold flex-shrink-0">{idx + 1}.</span>
                    <p className="text-gray-300 text-sm">{rec}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}