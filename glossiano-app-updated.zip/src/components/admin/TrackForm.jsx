import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Save } from 'lucide-react';
import { toast } from 'sonner';

export default function TrackForm({ track, onSuccess, onCancel }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState(track || {
    title: '',
    artist: '',
    album: '',
    genre: '',
    duration: '',
    description: '',
    audio_url: '',
    cover_image: '',
    price: 0,
    for_sale: true,
    featured: false,
    members_only: false
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Track.create(data),
    onSuccess: () => {
      toast.success('✓ Track added');
      queryClient.invalidateQueries({ queryKey: ['glossiano-tracks'] });
      onSuccess?.();
    }
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Track.update(track.id, data),
    onSuccess: () => {
      toast.success('✓ Track updated');
      queryClient.invalidateQueries({ queryKey: ['glossiano-tracks'] });
      onSuccess?.();
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title || !formData.artist || !formData.audio_url) {
      toast.error('Title, Artist, and Audio URL are required');
      return;
    }

    const data = {
      ...formData,
      price: parseFloat(formData.price) || 0
    };

    if (track) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  return (
    <Card className="bg-black/50 border-yellow-500/20">
      <CardHeader>
        <CardTitle className="text-white">
          {track ? 'Edit Track' : 'Add New Track'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-white text-sm font-semibold block mb-1">Title *</label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Track title"
                className="bg-black/50 border-yellow-500/20"
              />
            </div>

            <div>
              <label className="text-white text-sm font-semibold block mb-1">Artist *</label>
              <Input
                value={formData.artist}
                onChange={(e) => setFormData({ ...formData, artist: e.target.value })}
                placeholder="Artist name"
                className="bg-black/50 border-yellow-500/20"
              />
            </div>

            <div>
              <label className="text-white text-sm font-semibold block mb-1">Album</label>
              <Input
                value={formData.album}
                onChange={(e) => setFormData({ ...formData, album: e.target.value })}
                placeholder="Album name"
                className="bg-black/50 border-yellow-500/20"
              />
            </div>

            <div>
              <label className="text-white text-sm font-semibold block mb-1">Genre</label>
              <Input
                value={formData.genre}
                onChange={(e) => setFormData({ ...formData, genre: e.target.value })}
                placeholder="Hip-Hop, Trap, etc."
                className="bg-black/50 border-yellow-500/20"
              />
            </div>

            <div>
              <label className="text-white text-sm font-semibold block mb-1">Duration</label>
              <Input
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                placeholder="3:45"
                className="bg-black/50 border-yellow-500/20"
              />
            </div>

            <div>
              <label className="text-white text-sm font-semibold block mb-1">Price ($)</label>
              <Input
                type="number"
                step="0.01"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                placeholder="0.99"
                className="bg-black/50 border-yellow-500/20"
              />
            </div>
          </div>

          <div>
            <label className="text-white text-sm font-semibold block mb-1">Audio URL *</label>
            <Input
              value={formData.audio_url}
              onChange={(e) => setFormData({ ...formData, audio_url: e.target.value })}
              placeholder="https://..."
              className="bg-black/50 border-yellow-500/20"
            />
            <p className="text-xs text-gray-500 mt-1">Upload audio file first, then paste the URL here</p>
          </div>

          <div>
            <label className="text-white text-sm font-semibold block mb-1">Cover Image URL</label>
            <Input
              value={formData.cover_image}
              onChange={(e) => setFormData({ ...formData, cover_image: e.target.value })}
              placeholder="https://..."
              className="bg-black/50 border-yellow-500/20"
            />
          </div>

          <div>
            <label className="text-white text-sm font-semibold block mb-1">Description</label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Track description or notes"
              className="bg-black/50 border-yellow-500/20"
            />
          </div>

          <div className="space-y-3 p-4 bg-black/30 rounded border border-yellow-500/10">
            <div className="flex items-center gap-3">
              <Checkbox
                id="for_sale"
                checked={formData.for_sale}
                onCheckedChange={(checked) => setFormData({ ...formData, for_sale: checked })}
              />
              <label htmlFor="for_sale" className="text-white text-sm cursor-pointer">
                Available for Purchase
              </label>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="featured"
                checked={formData.featured}
                onCheckedChange={(checked) => setFormData({ ...formData, featured: checked })}
              />
              <label htmlFor="featured" className="text-white text-sm cursor-pointer">
                Feature on Homepage
              </label>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="members_only"
                checked={formData.members_only}
                onCheckedChange={(checked) => setFormData({ ...formData, members_only: checked })}
              />
              <label htmlFor="members_only" className="text-white text-sm cursor-pointer">
                Members Only
              </label>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            {onCancel && (
              <Button
                type="button"
                onClick={onCancel}
                variant="outline"
                className="flex-1 border-gray-600"
              >
                Cancel
              </Button>
            )}
            <Button
              type="submit"
              disabled={isLoading}
              className="flex-1 bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white font-bold"
            >
              <Save className="h-4 w-4 mr-2" />
              {isLoading ? 'Saving...' : track ? 'Update Track' : 'Add Track'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}