import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { AlertCircle, CheckCircle, XCircle, Trash2, Star, Flag, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function AdminFanWallDashboard() {
  const queryClient = useQueryClient();
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [rejectionNotes, setRejectionNotes] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: pendingMessages = [] } = useQuery({
    queryKey: ['pendingMessages'],
    queryFn: () => base44.entities.FanMessage.filter(
      { status: 'pending' },
      '-created_date'
    )
  });

  const { data: flaggedMessages = [] } = useQuery({
    queryKey: ['flaggedMessages'],
    queryFn: () => base44.entities.FanMessage.filter(
      { status: 'flagged' },
      '-flag_count,-created_date'
    )
  });

  const { data: approvedMessages = [] } = useQuery({
    queryKey: ['approvedMessages'],
    queryFn: () => base44.entities.FanMessage.filter(
      { status: 'approved' },
      '-is_featured,-created_date'
    )
  });

  const handleApprove = async (messageId) => {
    setIsProcessing(true);
    try {
      await base44.entities.FanMessage.update(messageId, {
        status: 'approved'
      });
      toast.success('Message approved!');
      queryClient.invalidateQueries({ queryKey: ['pendingMessages'] });
      queryClient.invalidateQueries({ queryKey: ['fanMessages'] });
    } catch (err) {
      toast.error('Failed to approve message');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReject = async (messageId) => {
    if (!rejectionNotes.trim()) {
      toast.error('Please add rejection notes');
      return;
    }

    setIsProcessing(true);
    try {
      await base44.entities.FanMessage.update(messageId, {
        status: 'rejected',
        admin_notes: rejectionNotes.trim()
      });
      toast.success('Message rejected');
      queryClient.invalidateQueries({ queryKey: ['pendingMessages'] });
      setDialogOpen(false);
      setRejectionNotes('');
      setSelectedMessage(null);
    } catch (err) {
      toast.error('Failed to reject message');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDelete = async (messageId) => {
    if (!confirm('Are you sure? This cannot be undone.')) return;

    setIsProcessing(true);
    try {
      await base44.entities.FanMessage.delete(messageId);
      toast.success('Message deleted');
      queryClient.invalidateQueries({ queryKey: ['approvedMessages'] });
      queryClient.invalidateQueries({ queryKey: ['flaggedMessages'] });
      queryClient.invalidateQueries({ queryKey: ['fanMessages'] });
    } catch (err) {
      toast.error('Failed to delete message');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleToggleFeatured = async (message) => {
    setIsProcessing(true);
    try {
      await base44.entities.FanMessage.update(message.id, {
        is_featured: !message.is_featured
      });
      toast.success(message.is_featured ? 'Unfeatured' : 'Featured!');
      queryClient.invalidateQueries({ queryKey: ['approvedMessages'] });
      queryClient.invalidateQueries({ queryKey: ['fanMessages'] });
    } catch (err) {
      toast.error('Failed to update featured status');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUnflag = async (messageId) => {
    setIsProcessing(true);
    try {
      await base44.entities.FanMessage.update(messageId, {
        status: 'approved',
        flag_count: 0,
        flag_reason: null
      });
      toast.success('Message unflagged and restored');
      queryClient.invalidateQueries({ queryKey: ['flaggedMessages'] });
      queryClient.invalidateQueries({ queryKey: ['fanMessages'] });
    } catch (err) {
      toast.error('Failed to unflag message');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-sm text-gray-400">Pending</p>
                <p className="text-2xl font-bold text-white">{pendingMessages.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Flag className="h-5 w-5 text-red-500" />
              <div>
                <p className="text-sm text-gray-400">Flagged</p>
                <p className="text-2xl font-bold text-white">{flaggedMessages.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-400">Approved</p>
                <p className="text-2xl font-bold text-white">{approvedMessages.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800/50 border border-slate-700">
          <TabsTrigger value="pending">Pending ({pendingMessages.length})</TabsTrigger>
          <TabsTrigger value="flagged">Flagged ({flaggedMessages.length})</TabsTrigger>
          <TabsTrigger value="approved">Approved ({approvedMessages.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4 mt-6">
          {pendingMessages.length === 0 ? (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="text-center py-8 text-gray-400">
                No pending messages
              </CardContent>
            </Card>
          ) : (
            pendingMessages.map((message) => (
              <Card key={message.id} className="bg-slate-800/50 border-slate-700">
                <CardContent className="pt-6">
                  <p className="text-gray-200 mb-4">{message.message}</p>
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <p className="font-semibold text-white">{message.fan_name}</p>
                      <p className="text-xs text-gray-500">{message.fan_email}</p>
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(message.created_date).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleApprove(message.id)}
                      disabled={isProcessing}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Approve
                    </Button>
                    <Button
                      onClick={() => {
                        setSelectedMessage(message);
                        setDialogOpen(true);
                      }}
                      disabled={isProcessing}
                      variant="destructive"
                    >
                      <XCircle className="h-4 w-4 mr-2" />
                      Reject
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="flagged" className="space-y-4 mt-6">
          {flaggedMessages.length === 0 ? (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="text-center py-8 text-gray-400">
                No flagged messages
              </CardContent>
            </Card>
          ) : (
            flaggedMessages.map((message) => (
              <Card key={message.id} className="bg-red-900/20 border-red-700/30">
                <CardContent className="pt-6">
                  <div className="mb-4 p-3 bg-red-900/30 rounded border border-red-700/50">
                    <p className="text-xs text-red-300 font-semibold mb-1">
                      Flagged {message.flag_count} times
                    </p>
                    <p className="text-xs text-red-200">Reason: {message.flag_reason}</p>
                  </div>
                  <p className="text-gray-200 mb-4">{message.message}</p>
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <p className="font-semibold text-white">{message.fan_name}</p>
                      <p className="text-xs text-gray-500">{message.fan_email}</p>
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(message.created_date).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleUnflag(message.id)}
                      disabled={isProcessing}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Unflag & Approve
                    </Button>
                    <Button
                      onClick={() => handleDelete(message.id)}
                      disabled={isProcessing}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="approved" className="space-y-4 mt-6">
          {approvedMessages.length === 0 ? (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="text-center py-8 text-gray-400">
                No approved messages
              </CardContent>
            </Card>
          ) : (
            approvedMessages.map((message) => (
              <Card
                key={message.id}
                className={`border-slate-700 ${
                  message.is_featured ? 'bg-amber-900/20 border-amber-700/30' : 'bg-slate-800/50'
                }`}
              >
                <CardContent className="pt-6">
                  {message.is_featured && (
                    <div className="mb-3 flex items-center gap-1 text-amber-400 text-xs">
                      <Star className="h-3 w-3 fill-current" />
                      Featured
                    </div>
                  )}
                  <p className="text-gray-200 mb-4">{message.message}</p>
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <p className="font-semibold text-white">{message.fan_name}</p>
                      <p className="text-xs text-gray-500">{message.fan_email}</p>
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(message.created_date).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleToggleFeatured(message)}
                      disabled={isProcessing}
                      variant="outline"
                      className="border-amber-600 text-amber-400 hover:bg-amber-900/30"
                    >
                      <Star className="h-4 w-4 mr-2" />
                      {message.is_featured ? 'Unfeature' : 'Feature'}
                    </Button>
                    <Button
                      onClick={() => handleDelete(message.id)}
                      disabled={isProcessing}
                      variant="destructive"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle>Reject Message</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-slate-700/50 p-3 rounded">
              <p className="text-gray-200 text-sm">{selectedMessage?.message}</p>
            </div>
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Rejection Notes</label>
              <Textarea
                placeholder="Explain why this message was rejected..."
                value={rejectionNotes}
                onChange={(e) => setRejectionNotes(e.target.value)}
                disabled={isProcessing}
                className="bg-slate-700 border-slate-600 text-white resize-none"
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              disabled={isProcessing}
            >
              Cancel
            </Button>
            <Button
              onClick={() => handleReject(selectedMessage?.id)}
              disabled={isProcessing || !rejectionNotes.trim()}
              className="bg-red-600 hover:bg-red-700"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                'Reject'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}