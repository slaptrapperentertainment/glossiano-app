import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, Check, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function BulkImportTrack({ onSuccess }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState([]);

  const importMutation = useMutation({
    mutationFn: async (rows) => {
      const created = [];
      for (const row of rows) {
        try {
          const track = await base44.entities.Track.create({
            title: row.title,
            artist: row.artist,
            album: row.album || '',
            genre: row.genre || '',
            duration: row.duration || '',
            description: row.description || '',
            audio_url: row.audio_url,
            cover_image: row.cover_image || '',
            price: parseFloat(row.price) || 0,
            for_sale: row.for_sale !== 'false',
            featured: row.featured === 'true',
            members_only: row.members_only === 'true'
          });
          created.push(track);
        } catch (error) {
          console.error(`Failed to create track: ${row.title}`, error);
        }
      }
      return created;
    },
    onSuccess: (created) => {
      toast.success(`✓ Imported ${created.length} tracks`);
      setFile(null);
      setPreview([]);
      onSuccess?.();
    },
    onError: () => toast.error('Import failed')
  });

  const handleFileChange = async (e) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;

    setFile(uploadedFile);

    const text = await uploadedFile.text();
    const lines = text.split('\n').filter(l => l.trim());

    // Parse CSV
    const rows = lines.slice(1).map((line) => {
      const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
      return {
        title: cols[0],
        artist: cols[1],
        album: cols[2],
        genre: cols[3],
        duration: cols[4],
        description: cols[5],
        audio_url: cols[6],
        cover_image: cols[7],
        price: cols[8],
        for_sale: cols[9] || 'true',
        featured: cols[10] || 'false',
        members_only: cols[11] || 'false'
      };
    }).filter(r => r.title && r.artist && r.audio_url);

    setPreview(rows);
  };

  return (
    <div className="space-y-6">
      {/* Instructions */}
      <Card className="bg-black/50 border-yellow-500/20">
        <CardHeader>
          <CardTitle className="text-white">Bulk Import Tracks</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-gray-300 mb-3">
              Upload a CSV file with your tracks. Format:
            </p>
            <code className="bg-black/50 p-3 rounded block text-sm text-gray-400 overflow-x-auto">
              Title, Artist, Album, Genre, Duration, Description, Audio URL*, Cover URL, Price, For Sale, Featured, Members Only
            </code>
            <p className="text-xs text-gray-500 mt-2">* Audio URL is required</p>
          </div>

          {/* File Upload */}
          <div className="border-2 border-dashed border-yellow-500/30 rounded-lg p-6 text-center cursor-pointer hover:border-yellow-500/60 transition-colors">
            <label className="cursor-pointer">
              <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <p className="text-gray-300 text-sm mb-1">Click to upload CSV file</p>
              <p className="text-gray-500 text-xs">or drag and drop</p>
              <input
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
          </div>

          {/* Download Template */}
          <Button
            variant="outline"
            className="w-full border-yellow-500/30 text-gray-300"
            onClick={() => {
              const template = `Title,Artist,Album,Genre,Duration,Description,Audio URL,Cover URL,Price,For Sale,Featured,Members Only
Midnight Vibes,Glossiano,Night Sessions,Hip-Hop,3:45,Dark and moody beat,https://example.com/audio.mp3,https://example.com/cover.jpg,0.99,true,true,false`;
              const element = document.createElement('a');
              element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(template));
              element.setAttribute('download', 'tracks_template.csv');
              element.style.display = 'none';
              document.body.appendChild(element);
              element.click();
              document.body.removeChild(element);
            }}
          >
            Download Template
          </Button>
        </CardContent>
      </Card>

      {/* Preview */}
      {preview.length > 0 && (
        <Card className="bg-black/50 border-yellow-500/20">
          <CardHeader>
            <CardTitle className="text-white">Preview ({preview.length} tracks)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 max-h-96 overflow-y-auto">
            {preview.map((row, idx) => (
              <div key={idx} className="p-3 bg-black/50 rounded border border-yellow-500/10">
                <p className="text-white font-semibold">{row.title}</p>
                <p className="text-yellow-400 text-sm">{row.artist}</p>
                {row.album && <p className="text-gray-400 text-xs">{row.album}</p>}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Import Button */}
      {preview.length > 0 && (
        <Button
          onClick={() => importMutation.mutate(preview)}
          disabled={importMutation.isPending}
          className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white font-bold py-6 text-lg"
        >
          <Check className="h-5 w-5 mr-2" />
          {importMutation.isPending ? 'Importing...' : `Import ${preview.length} Tracks`}
        </Button>
      )}
    </div>
  );
}