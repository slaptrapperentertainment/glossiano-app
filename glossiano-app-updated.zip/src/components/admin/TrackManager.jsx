import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Edit2, Music2, Play, Pause, Grip } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import TrackForm from './TrackForm';

export default function TrackManager() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [editingTrack, setEditingTrack] = useState(null);
  const [draggedTrack, setDraggedTrack] = useState(null);
  const [playingId, setPlayingId] = useState(null);
  const [audioRef] = useState({});
  const [searchQuery, setSearchQuery] = useState('');

  const { data: tracks = [] } = useQuery({
    queryKey: ['glossiano-tracks'],
    queryFn: () => base44.entities.Track.filter({ artist: 'Glossiano' }, '-created_date'),
    initialData: []
  });

  const deleteTrackMutation = useMutation({
    mutationFn: (trackId) => base44.entities.Track.delete(trackId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['glossiano-tracks'] });
      toast.success('Track deleted');
    },
    onError: () => toast.error('Failed to delete track')
  });

  const handlePlay = (trackId, audioUrl) => {
    if (playingId === trackId) {
      audioRef[trackId]?.pause();
      setPlayingId(null);
    } else {
      if (playingId) audioRef[playingId]?.pause();
      const audio = new Audio(audioUrl);
      audioRef[trackId] = audio;
      audio.play();
      setPlayingId(trackId);
    }
  };

  const handleDragStart = (e, track) => {
    setDraggedTrack(track);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e, targetTrack) => {
    e.preventDefault();
    if (!draggedTrack || draggedTrack.id === targetTrack.id) return;
    setDraggedTrack(null);
  };

  const filteredTracks = tracks.filter(t => 
    t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.album?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-white flex items-center gap-2">
            <Music2 className="h-8 w-8 text-yellow-400" />
            Track Library
          </h2>
          <p className="text-gray-400 mt-1">{tracks.length} tracks • Drag to reorder</p>
        </div>
        <Button
          onClick={() => {
            setEditingTrack(null);
            setShowForm(true);
          }}
          className="bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Track
        </Button>
      </div>

      <Input
        placeholder="Search tracks by title or album..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="bg-black/50 border-yellow-500/20 text-white"
      />

      <AnimatePresence>
        {filteredTracks.length === 0 ? (
          <Card className="bg-gradient-to-br from-gray-900/50 to-black border-gray-700/50 text-center py-12">
            <Music2 className="h-12 w-12 text-gray-600 mx-auto mb-4 opacity-50" />
            <p className="text-gray-400">No tracks yet. Add your first track!</p>
          </Card>
        ) : (
          <div className="space-y-2">
            {filteredTracks.map((track) => (
              <motion.div
                key={track.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                draggable
                onDragStart={(e) => handleDragStart(e, track)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, track)}
                className={`transition-all ${draggedTrack?.id === track.id ? 'opacity-50' : ''}`}
              >
                <Card className="bg-black/50 border-yellow-500/20 hover:border-yellow-500/40 transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <Grip className="h-5 w-5 text-gray-500" />

                      <div className="flex-shrink-0">
                        <div className="w-16 h-16 rounded bg-gradient-to-br from-pink-900 to-yellow-900 flex items-center justify-center overflow-hidden">
                          {track.cover_image ? (
                            <img src={track.cover_image} alt={track.title} className="w-full h-full object-cover" />
                          ) : (
                            <Music2 className="h-6 w-6 text-gray-600" />
                          )}
                        </div>
                      </div>

                      <div className="flex-1 min-w-0">
                        <h3 className="text-white font-bold truncate">{track.title}</h3>
                        <p className="text-sm text-gray-400">{track.album || 'No album'}</p>
                        <div className="flex gap-2 mt-2 flex-wrap">
                          {track.featured && <Badge className="bg-yellow-500/20 text-yellow-300 text-xs">Featured</Badge>}
                          {track.members_only && <Badge className="bg-purple-500/20 text-purple-300 text-xs">Members Only</Badge>}
                          {track.for_sale && track.price && <Badge className="bg-green-500/20 text-green-300 text-xs">${track.price}</Badge>}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          onClick={() => handlePlay(track.id, track.audio_url)}
                          size="icon"
                          variant="ghost"
                          className="text-yellow-400 hover:text-yellow-300 hover:bg-yellow-500/10"
                        >
                          {playingId === track.id ? (
                            <Pause className="h-4 w-4" />
                          ) : (
                            <Play className="h-4 w-4" />
                          )}
                        </Button>
                        <Button
                          onClick={() => {
                            setEditingTrack(track);
                            setShowForm(true);
                          }}
                          size="icon"
                          variant="ghost"
                          className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button
                          onClick={() => {
                            if (confirm('Delete this track?')) {
                              deleteTrackMutation.mutate(track.id);
                            }
                          }}
                          size="icon"
                          variant="ghost"
                          className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </AnimatePresence>

      {showForm && (
        <TrackForm
          track={editingTrack}
          onClose={() => {
            setShowForm(false);
            setEditingTrack(null);
          }}
          onSuccess={() => {
            setShowForm(false);
            setEditingTrack(null);
            queryClient.invalidateQueries({ queryKey: ['glossiano-tracks'] });
          }}
        />
      )}
    </div>
  );
}