import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Power } from 'lucide-react';
import { toast } from 'sonner';

export default function PlaylistCuratorManager() {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    playlist_name: '',
    curator_email: '',
    curator_name: '',
    spotify_url: '',
    followers: 0,
    genres: [],
    submission_url: '',
    auto_pitch: false
  });
  const [genreInput, setGenreInput] = useState('');

  const queryClient = useQueryClient();

  const { data: curators = [] } = useQuery({
    queryKey: ['spotifyPlaylistCurators'],
    queryFn: () => base44.entities.SpotifyPlaylistCurator.list('-created_date')
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.SpotifyPlaylistCurator.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['spotifyPlaylistCurators'] });
      setShowForm(false);
      setFormData({
        playlist_name: '',
        curator_email: '',
        curator_name: '',
        spotify_url: '',
        followers: 0,
        genres: [],
        submission_url: '',
        auto_pitch: false
      });
      toast.success('Curator added successfully');
    }
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, auto_pitch }) => 
      base44.entities.SpotifyPlaylistCurator.update(id, { auto_pitch: !auto_pitch }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['spotifyPlaylistCurators'] });
      toast.success('Auto-pitch setting updated');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SpotifyPlaylistCurator.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['spotifyPlaylistCurators'] });
      toast.success('Curator removed');
    }
  });

  const handleAddGenre = () => {
    if (genreInput && !formData.genres.includes(genreInput)) {
      setFormData({
        ...formData,
        genres: [...formData.genres, genreInput]
      });
      setGenreInput('');
    }
  };

  const handleRemoveGenre = (genre) => {
    setFormData({
      ...formData,
      genres: formData.genres.filter(g => g !== genre)
    });
  };

  const handleSubmit = () => {
    if (!formData.playlist_name || !formData.genres.length) {
      toast.error('Please fill all required fields');
      return;
    }
    createMutation.mutate(formData);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Spotify Playlist Curators</h2>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-gradient-to-r from-pink-600 to-yellow-500"
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Curator
        </Button>
      </div>

      {showForm && (
        <Card className="bg-gradient-to-br from-pink-900/30 to-black border-pink-500/30">
          <CardHeader>
            <CardTitle className="text-white">Add Spotify Playlist Curator</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Playlist Name"
              value={formData.playlist_name}
              onChange={(e) => setFormData({ ...formData, playlist_name: e.target.value })}
              className="bg-black/50 border-pink-500/30"
            />
            <Input
              placeholder="Curator Email"
              type="email"
              value={formData.curator_email}
              onChange={(e) => setFormData({ ...formData, curator_email: e.target.value })}
              className="bg-black/50 border-pink-500/30"
            />
            <Input
              placeholder="Curator Name"
              value={formData.curator_name}
              onChange={(e) => setFormData({ ...formData, curator_name: e.target.value })}
              className="bg-black/50 border-pink-500/30"
            />
            <Input
              placeholder="Spotify URL"
              value={formData.spotify_url}
              onChange={(e) => setFormData({ ...formData, spotify_url: e.target.value })}
              className="bg-black/50 border-pink-500/30"
            />
            <Input
              placeholder="Followers"
              type="number"
              value={formData.followers}
              onChange={(e) => setFormData({ ...formData, followers: parseInt(e.target.value) })}
              className="bg-black/50 border-pink-500/30"
            />
            <Input
              placeholder="Submission URL/Email"
              value={formData.submission_url}
              onChange={(e) => setFormData({ ...formData, submission_url: e.target.value })}
              className="bg-black/50 border-pink-500/30"
            />

            <div>
              <label className="text-sm text-gray-400 mb-2 block">Genres (comma separated)</label>
              <div className="flex gap-2 mb-2">
                <Input
                  placeholder="e.g., Hip-Hop, Trap"
                  value={genreInput}
                  onChange={(e) => setGenreInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddGenre()}
                  className="bg-black/50 border-pink-500/30"
                />
                <Button onClick={handleAddGenre} variant="outline" className="border-pink-500/30">
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.genres.map(genre => (
                  <Badge key={genre} className="bg-pink-600">
                    {genre}
                    <button
                      onClick={() => handleRemoveGenre(genre)}
                      className="ml-2 hover:text-white"
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700 flex-1">
                Add Curator
              </Button>
              <Button onClick={() => setShowForm(false)} variant="outline" className="flex-1">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {curators.map((curator) => (
          <Card key={curator.id} className="bg-gradient-to-br from-gray-900/50 to-black border-gray-700/50 hover:border-pink-500/30 transition-all">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-white">{curator.playlist_name}</h3>
                  <p className="text-sm text-gray-400">{curator.curator_name} ({curator.curator_email})</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => toggleMutation.mutate({ id: curator.id, auto_pitch: curator.auto_pitch })}
                    variant={curator.auto_pitch ? 'default' : 'outline'}
                    size="sm"
                    className={curator.auto_pitch ? 'bg-green-600' : ''}
                  >
                    <Power className="h-4 w-4 mr-1" />
                    {curator.auto_pitch ? 'Auto-Pitch ON' : 'Auto-Pitch OFF'}
                  </Button>
                  <Button
                    onClick={() => deleteMutation.mutate(curator.id)}
                    variant="destructive"
                    size="sm"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Followers</p>
                  <p className="text-white font-bold">{curator.followers?.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-500">Successful Pitches</p>
                  <p className="text-green-400 font-bold">{curator.successful_pitches || 0}</p>
                </div>
                <div>
                  <p className="text-gray-500">Response Rate</p>
                  <p className="text-yellow-400 font-bold">{curator.response_rate || 0}%</p>
                </div>
                <div>
                  <p className="text-gray-500">Status</p>
                  <Badge className={curator.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}>
                    {curator.status}
                  </Badge>
                </div>
              </div>

              {curator.genres && curator.genres.length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-700/50">
                  <p className="text-xs text-gray-500 mb-2">Genres</p>
                  <div className="flex flex-wrap gap-2">
                    {curator.genres.map(genre => (
                      <Badge key={genre} className="bg-purple-500/20 text-purple-300">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {curators.length === 0 && (
        <Card className="bg-gradient-to-br from-gray-900/30 to-black border-gray-700/30">
          <CardContent className="p-12 text-center">
            <p className="text-gray-400 mb-4">No playlist curators added yet</p>
            <Button onClick={() => setShowForm(true)} className="bg-gradient-to-r from-pink-600 to-yellow-500">
              Add Your First Curator
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}