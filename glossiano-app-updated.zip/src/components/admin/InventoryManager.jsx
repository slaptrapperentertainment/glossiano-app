import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Plus, Minus, Edit2, Loader2, Package } from 'lucide-react';
import { toast } from 'sonner';

export default function InventoryManager() {
  const queryClient = useQueryClient();
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [stockAmount, setStockAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const { data: products = [] } = useQuery({
    queryKey: ['allProducts'],
    queryFn: () => base44.entities.Product.list('', 100)
  });

  const filteredProducts = products.filter(p =>
    p.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.artist_brand?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUpdateStock = async () => {
    if (!selectedProduct || !stockAmount) {
      toast.error('Please enter a stock amount');
      return;
    }

    setIsProcessing(true);
    try {
      await base44.entities.Product.update(selectedProduct.id, {
        stock: parseInt(stockAmount)
      });

      toast.success('Stock updated successfully');
      queryClient.invalidateQueries({ queryKey: ['allProducts'] });
      setIsDialogOpen(false);
      setSelectedProduct(null);
      setStockAmount('');
    } catch (err) {
      toast.error('Failed to update stock');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAdjustStock = async (productId, adjustment) => {
    const product = products.find(p => p.id === productId);
    const newStock = Math.max(0, (product?.stock || 0) + adjustment);

    setIsProcessing(true);
    try {
      await base44.entities.Product.update(productId, {
        stock: newStock
      });
      toast.success('Stock adjusted');
      queryClient.invalidateQueries({ queryKey: ['allProducts'] });
    } catch (err) {
      toast.error('Failed to adjust stock');
    } finally {
      setIsProcessing(false);
    }
  };

  const getLowStockStatus = (stock) => {
    if (stock === 0) return 'bg-red-100 text-red-800';
    if (stock < 5) return 'bg-yellow-100 text-yellow-800';
    return 'bg-green-100 text-green-800';
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white mb-4">Inventory Management</h2>
        <Input
          placeholder="Search products..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-slate-700 border-slate-600 text-white"
        />
      </div>

      <div className="grid gap-4">
        {filteredProducts.length === 0 ? (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="text-center py-8 text-gray-400">
              <Package className="h-12 w-12 mx-auto mb-2 opacity-50" />
              No products found
            </CardContent>
          </Card>
        ) : (
          filteredProducts.map((product) => (
            <Card key={product.id} className="bg-slate-800/50 border-slate-700">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                  <div className="flex gap-3">
                    {product.main_image && (
                      <img
                        src={product.main_image}
                        alt={product.title}
                        className="w-12 h-12 object-cover rounded"
                      />
                    )}
                    <div>
                      <p className="font-semibold text-white">{product.title}</p>
                      <p className="text-sm text-gray-400">${product.price?.toFixed(2)}</p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400 mb-1">Category</p>
                    <p className="font-medium text-white">{product.category}</p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400 mb-1">Stock</p>
                    <span className={`px-3 py-1 rounded-full text-sm font-bold ${getLowStockStatus(product.stock)}`}>
                      {product.stock} units
                    </span>
                  </div>

                  <div className="flex gap-2 justify-end">
                    <Button
                      onClick={() => handleAdjustStock(product.id, -1)}
                      disabled={isProcessing || product.stock === 0}
                      variant="outline"
                      size="sm"
                      className="border-red-600 text-red-400 hover:bg-red-900/20"
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                    <Button
                      onClick={() => {
                        setSelectedProduct(product);
                        setStockAmount(product.stock?.toString() || '0');
                        setIsDialogOpen(true);
                      }}
                      variant="outline"
                      size="sm"
                      className="border-amber-600 text-amber-400 hover:bg-amber-900/20"
                    >
                      <Edit2 className="h-3 w-3" />
                    </Button>
                    <Button
                      onClick={() => handleAdjustStock(product.id, 1)}
                      disabled={isProcessing}
                      variant="outline"
                      size="sm"
                      className="border-green-600 text-green-400 hover:bg-green-900/20"
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle>Update Stock</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-300">{selectedProduct?.title}</p>
            <Input
              type="number"
              placeholder="Stock quantity"
              value={stockAmount}
              onChange={(e) => setStockAmount(e.target.value)}
              min="0"
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleUpdateStock}
              disabled={isProcessing}
              className="bg-green-600 hover:bg-green-700"
            >
              {isProcessing ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Update'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}