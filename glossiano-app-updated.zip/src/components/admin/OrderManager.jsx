import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Package, Eye, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function OrderManager() {
  const queryClient = useQueryClient();
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const { data: orders = [] } = useQuery({
    queryKey: ['orders'],
    queryFn: () => base44.entities.Order.list('-created_date', 50)
  });

  const filteredOrders = orders.filter(o =>
    o.customer_email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    o.customer_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUpdateStatus = async () => {
    if (!newStatus) {
      toast.error('Please select a status');
      return;
    }

    setIsProcessing(true);
    try {
      const updateData = { status: newStatus };
      if (newStatus === 'shipped' && trackingNumber) {
        updateData.tracking_number = trackingNumber;
      }

      await base44.entities.Order.update(selectedOrder.id, updateData);
      toast.success('Order updated');
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      setIsStatusOpen(false);
      setNewStatus('');
      setTrackingNumber('');
    } catch (err) {
      toast.error('Failed to update order');
    } finally {
      setIsProcessing(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800',
      paid: 'bg-blue-100 text-blue-800',
      processing: 'bg-purple-100 text-purple-800',
      shipped: 'bg-green-100 text-green-800',
      delivered: 'bg-green-200 text-green-900',
      cancelled: 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white mb-4">Order Management</h2>
        <Input
          placeholder="Search by email or name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-slate-700 border-slate-600 text-white"
        />
      </div>

      <div className="space-y-3">
        {filteredOrders.length === 0 ? (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="text-center py-8 text-gray-400">
              <Package className="h-12 w-12 mx-auto mb-2 opacity-50" />
              No orders found
            </CardContent>
          </Card>
        ) : (
          filteredOrders.map((order) => (
            <Card key={order.id} className="bg-slate-800/50 border-slate-700">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                  <div>
                    <p className="text-sm text-gray-400 mb-1">Customer</p>
                    <p className="font-semibold text-white">{order.customer_name}</p>
                    <p className="text-xs text-gray-500">{order.customer_email}</p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400 mb-1">Items</p>
                    <p className="font-medium text-white">{order.items?.length || 0} item(s)</p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400 mb-1">Total</p>
                    <p className="font-bold text-amber-400">${order.total_amount?.toFixed(2)}</p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400 mb-1">Status</p>
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </div>

                  <div className="flex gap-2 justify-end">
                    <Button
                      onClick={() => {
                        setSelectedOrder(order);
                        setIsDetailsOpen(true);
                      }}
                      variant="outline"
                      size="sm"
                      className="border-blue-600 text-blue-400 hover:bg-blue-900/20"
                    >
                      <Eye className="h-3 w-3 mr-1" />
                      View
                    </Button>
                    <Button
                      onClick={() => {
                        setSelectedOrder(order);
                        setNewStatus(order.status);
                        setIsStatusOpen(true);
                      }}
                      variant="outline"
                      size="sm"
                      className="border-amber-600 text-amber-400 hover:bg-amber-900/20"
                    >
                      Update
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle>Order Details</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4 max-h-96 overflow-y-auto">
              <div>
                <p className="text-sm text-gray-400 mb-1">Customer</p>
                <p className="font-semibold text-white">{selectedOrder.customer_name}</p>
                <p className="text-sm text-gray-400">{selectedOrder.customer_email}</p>
                <p className="text-sm text-gray-400">{selectedOrder.customer_phone}</p>
              </div>

              <div className="bg-slate-700/50 p-3 rounded">
                <p className="text-sm font-semibold text-gray-300 mb-2">Shipping Address</p>
                <p className="text-sm text-gray-300">
                  {selectedOrder.shipping_address?.address}<br />
                  {selectedOrder.shipping_address?.city}, {selectedOrder.shipping_address?.postal_code}<br />
                  {selectedOrder.shipping_address?.country}
                </p>
              </div>

              <div>
                <p className="text-sm font-semibold text-gray-300 mb-2">Items</p>
                <div className="space-y-2">
                  {selectedOrder.items?.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-sm text-gray-300 bg-slate-700/30 p-2 rounded">
                      <span>{item.title} x {item.quantity}</span>
                      <span>${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-600 pt-3">
                <p className="flex justify-between text-white font-bold">
                  <span>Total:</span>
                  <span>${selectedOrder.total_amount?.toFixed(2)}</span>
                </p>
              </div>

              {selectedOrder.tracking_number && (
                <div>
                  <p className="text-sm text-gray-400 mb-1">Tracking</p>
                  <p className="font-mono text-white">{selectedOrder.tracking_number}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Status Update Dialog */}
      <Dialog open={isStatusOpen} onOpenChange={setIsStatusOpen}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle>Update Order Status</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Select value={newStatus} onValueChange={setNewStatus}>
              <SelectTrigger className="bg-slate-700 border-slate-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="processing">Processing</SelectItem>
                <SelectItem value="shipped">Shipped</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>

            {newStatus === 'shipped' && (
              <Input
                placeholder="Tracking number (optional)"
                value={trackingNumber}
                onChange={(e) => setTrackingNumber(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
              />
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsStatusOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleUpdateStatus}
              disabled={isProcessing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isProcessing ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Update'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}