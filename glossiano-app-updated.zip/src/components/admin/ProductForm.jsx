import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Sparkles, Loader2, Upload, X } from 'lucide-react';
import { toast } from 'sonner';

export default function ProductForm({ product, onSuccess, onCancel }) {
  const [formData, setFormData] = useState(product || {
    title: '',
    artist_brand: '',
    description: '',
    price: '',
    category: '',
    decade: '',
    condition: '',
    main_image: '',
    gallery_images: [],
    stock: 1,
    featured: false,
    genre: '',
    year: ''
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [uploadingMain, setUploadingMain] = useState(false);
  const [uploadingGallery, setUploadingGallery] = useState(false);

  const handleMainImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingMain(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, main_image: file_url });
      toast.success('Imagen principal subida');
    } catch (error) {
      toast.error('Error al subir la imagen');
    } finally {
      setUploadingMain(false);
    }
  };

  const handleGalleryUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setUploadingGallery(true);
    try {
      const uploadPromises = files.map(file => 
        base44.integrations.Core.UploadFile({ file })
      );
      const results = await Promise.all(uploadPromises);
      const newUrls = results.map(r => r.file_url);
      setFormData({ 
        ...formData, 
        gallery_images: [...(formData.gallery_images || []), ...newUrls] 
      });
      toast.success(`${files.length} imagen(es) añadida(s)`);
    } catch (error) {
      toast.error('Error al subir imágenes');
    } finally {
      setUploadingGallery(false);
    }
  };

  const removeGalleryImage = (index) => {
    const newGallery = [...(formData.gallery_images || [])];
    newGallery.splice(index, 1);
    setFormData({ ...formData, gallery_images: newGallery });
  };

  const generateDescription = async () => {
    if (!formData.title) {
      toast.error('Please enter a product title first');
      return;
    }

    setIsGenerating(true);
    try {
      const prompt = `Generate an engaging, vintage-focused product description for a collector's item with these details:

Title: ${formData.title}
${formData.artist_brand ? `Artist/Brand: ${formData.artist_brand}` : ''}
Category: ${formData.category || 'vintage collectible'}
Decade: ${formData.decade || 'classic era'}
${formData.year ? `Year: ${formData.year}` : ''}
${formData.genre ? `Genre: ${formData.genre}` : ''}
Condition: ${formData.condition || 'good'}

Write a compelling 2-3 sentence description that captures:
- The vintage essence and nostalgic appeal
- Historical significance or cultural impact
- Why collectors would want this item
- Keep it authentic and passionate

Write in a warm, knowledgeable tone that speaks to vintage enthusiasts.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        add_context_from_internet: false
      });

      setFormData({ ...formData, description: response });
      toast.success('Description generated!');
    } catch (error) {
      toast.error('Failed to generate description');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);

    try {
      const data = {
        ...formData,
        price: parseFloat(formData.price) || 0,
        stock: parseInt(formData.stock) || 0,
        year: formData.year ? parseInt(formData.year) : null
      };

      if (product?.id) {
        await base44.entities.Product.update(product.id, data);
        toast.success('Product updated!');
      } else {
        await base44.entities.Product.create(data);
        toast.success('Product created!');
      }

      onSuccess();
    } catch (error) {
      toast.error('Failed to save product');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="title">Title *</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="artist_brand">Artist / Brand</Label>
          <Input
            id="artist_brand"
            value={formData.artist_brand}
            onChange={(e) => setFormData({ ...formData, artist_brand: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="category">Category *</Label>
          <Input
            id="category"
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            placeholder="vinyl, cd, cassette, vhs, etc."
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="decade">Decade</Label>
          <Select value={formData.decade} onValueChange={(value) => setFormData({ ...formData, decade: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select decade" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="80s">80s</SelectItem>
              <SelectItem value="90s">90s</SelectItem>
              <SelectItem value="2000s">2000s</SelectItem>
              <SelectItem value="2010s">2010s</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="condition">Condition</Label>
          <Select value={formData.condition} onValueChange={(value) => setFormData({ ...formData, condition: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select condition" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mint">Mint</SelectItem>
              <SelectItem value="near_mint">Near Mint</SelectItem>
              <SelectItem value="very_good">Very Good</SelectItem>
              <SelectItem value="good">Good</SelectItem>
              <SelectItem value="fair">Fair</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="price">Price ($) *</Label>
          <Input
            id="price"
            type="number"
            step="0.01"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="stock">Stock</Label>
          <Input
            id="stock"
            type="number"
            value={formData.stock}
            onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="year">Year</Label>
          <Input
            id="year"
            type="number"
            value={formData.year}
            onChange={(e) => setFormData({ ...formData, year: e.target.value })}
            placeholder="1985"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="genre">Genre</Label>
          <Input
            id="genre"
            value={formData.genre}
            onChange={(e) => setFormData({ ...formData, genre: e.target.value })}
            placeholder="Rock, Pop, Sci-Fi, etc."
          />
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label>Imagen Principal *</Label>
          {formData.main_image ? (
            <div className="relative">
              <img 
                src={formData.main_image} 
                alt="Main" 
                className="w-full h-48 object-cover rounded border"
              />
              <Button
                type="button"
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => setFormData({ ...formData, main_image: '' })}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div className="border-2 border-dashed border-neutral-300 rounded-lg p-8 text-center">
              <input
                type="file"
                accept="image/*"
                onChange={handleMainImageUpload}
                className="hidden"
                id="main-image-upload"
                disabled={uploadingMain}
              />
              <label htmlFor="main-image-upload" className="cursor-pointer">
                <Upload className="h-8 w-8 text-neutral-400 mx-auto mb-2" />
                <p className="text-sm text-neutral-600">
                  {uploadingMain ? 'Subiendo...' : 'Click para subir imagen'}
                </p>
              </label>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label>Imágenes de Galería (opcional)</Label>
        <div className="grid grid-cols-4 gap-4">
          {formData.gallery_images?.map((img, idx) => (
            <div key={idx} className="relative aspect-square">
              <img 
                src={img} 
                alt={`Gallery ${idx + 1}`} 
                className="w-full h-full object-cover rounded border"
              />
              <Button
                type="button"
                variant="destructive"
                size="icon"
                className="absolute -top-2 -right-2 h-6 w-6"
                onClick={() => removeGalleryImage(idx)}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
          <div className="border-2 border-dashed border-neutral-300 rounded aspect-square flex items-center justify-center">
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleGalleryUpload}
              className="hidden"
              id="gallery-upload"
              disabled={uploadingGallery}
            />
            <label htmlFor="gallery-upload" className="cursor-pointer text-center p-2">
              <Upload className="h-6 w-6 text-neutral-400 mx-auto mb-1" />
              <p className="text-xs text-neutral-600">
                {uploadingGallery ? 'Subiendo...' : 'Añadir'}
              </p>
            </label>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="description">Descripción</Label>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={generateDescription}
            disabled={isGenerating || !formData.title}
            className="text-amber-600 border-amber-200 hover:bg-amber-50"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generar con IA
              </>
            )}
          </Button>
        </div>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          rows={4}
          placeholder="Descripción del producto..."
        />
      </div>

      <div className="flex items-center gap-2">
        <Checkbox
          id="featured"
          checked={formData.featured}
          onCheckedChange={(checked) => setFormData({ ...formData, featured: checked })}
        />
        <Label htmlFor="featured" className="cursor-pointer">Producto destacado</Label>
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSaving}>
          Cancelar
        </Button>
        <Button type="submit" disabled={isSaving || !formData.main_image} className="bg-neutral-900 hover:bg-neutral-800">
          {isSaving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Guardando...
            </>
          ) : (
            product?.id ? 'Actualizar Producto' : 'Crear Producto'
          )}
        </Button>
      </div>
    </form>
  );
}