import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Flag, Loader2, Heart, Sparkles } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { toast } from 'sonner';

export default function FanMessageCard({ message, onMessageFlagged }) {
  const [isReporting, setIsReporting] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const handleReportMessage = async () => {
    if (!reportReason) {
      toast.error('Please select a reason');
      return;
    }

    setIsReporting(true);
    try {
      const newFlagCount = (message.flag_count || 0) + 1;
      const newStatus = newFlagCount >= 3 ? 'flagged' : 'active';

      await base44.entities.FanMessage.update(message.id, {
        flag_count: newFlagCount,
        flag_reason: reportReason,
        status: newStatus
      });

      toast.success('Message reported. Thank you!');
      setIsOpen(false);
      setReportReason('');
      if (onMessageFlagged) onMessageFlagged();
    } catch (err) {
      toast.error('Failed to report message');
    } finally {
      setIsReporting(false);
    }
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardContent className="pt-6">
        {message.is_featured && (
          <div className="flex items-center gap-1 mb-2 text-amber-400 text-xs">
            <Sparkles className="h-3 w-3" />
            Featured
          </div>
        )}
        <p className="text-gray-200 mb-3">{message.message}</p>
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="font-semibold text-sm text-white">{message.fan_name}</p>
            <p className="text-xs text-gray-500">
              {new Date(message.created_date).toLocaleDateString()}
            </p>
          </div>

          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-400 hover:text-red-500"
              >
                <Flag className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-800 border-slate-700">
              <DialogHeader>
                <DialogTitle>Report Message</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <p className="text-sm text-gray-300">
                  Help us keep the Fan Wall positive. Why are you reporting this?
                </p>
                <Select value={reportReason} onValueChange={setReportReason}>
                  <SelectTrigger className="bg-slate-700 border-slate-600">
                    <SelectValue placeholder="Select reason..." />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="offensive">Offensive language</SelectItem>
                    <SelectItem value="spam">Spam or abuse</SelectItem>
                    <SelectItem value="inappropriate">Inappropriate content</SelectItem>
                    <SelectItem value="harassment">Harassment</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setIsOpen(false)}
                  disabled={isReporting}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleReportMessage}
                  disabled={!reportReason || isReporting}
                  className="bg-red-600 hover:bg-red-700"
                >
                  {isReporting ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Reporting...
                    </>
                  ) : (
                    'Report'
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
    </Card>
  );
}