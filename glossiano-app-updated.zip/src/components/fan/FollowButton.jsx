import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Heart, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function FollowButton() {
  const [user, setUser] = useState(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);

        if (userData) {
          const followers = await base44.entities.Follower.filter({
            fan_email: userData.email
          });
          setIsFollowing(followers.length > 0 && followers[0].is_following);
        }
      } catch (err) {
        setUser(null);
      }
    };
    fetchUser();
  }, []);

  const handleToggleFollow = async () => {
    if (!user) {
      base44.auth.redirectToLogin();
      return;
    }

    setIsLoading(true);
    try {
      const followers = await base44.entities.Follower.filter({
        fan_email: user.email
      });

      if (isFollowing && followers.length > 0) {
        await base44.entities.Follower.update(followers[0].id, {
          is_following: false
        });
        toast.success('Unfollowed Glossiano');
      } else if (followers.length > 0) {
        await base44.entities.Follower.update(followers[0].id, {
          is_following: true
        });
        toast.success('Following Glossiano! You\'ll get new release notifications');
      } else {
        await base44.entities.Follower.create({
          fan_email: user.email,
          fan_name: user.full_name,
          is_following: true,
          notification_preference: 'both'
        });
        toast.success('Following Glossiano! You\'ll get new release notifications');
      }

      setIsFollowing(!isFollowing);
    } catch (err) {
      toast.error('Failed to update follow status');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Button
      onClick={handleToggleFollow}
      disabled={isLoading}
      className={`gap-2 ${
        isFollowing
          ? 'bg-red-500 hover:bg-red-600'
          : 'bg-amber-500 hover:bg-amber-600'
      }`}
    >
      {isLoading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Heart className={`h-4 w-4 ${isFollowing ? 'fill-current' : ''}`} />
      )}
      {isFollowing ? 'Following' : 'Follow'}
    </Button>
  );
}