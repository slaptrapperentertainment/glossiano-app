import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Send } from 'lucide-react';
import { toast } from 'sonner';

export default function FanMessageForm({ onMessagePosted }) {
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (err) {
        setUser(null);
      }
    };
    fetchUser();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!user) {
      base44.auth.redirectToLogin();
      return;
    }

    if (!message.trim()) {
      toast.error('Please write a message');
      return;
    }

    if (message.length > 500) {
      toast.error('Message must be 500 characters or less');
      return;
    }

    setIsLoading(true);
    try {
      await base44.entities.FanMessage.create({
        fan_email: user.email,
        fan_name: user.full_name,
        message: message.trim(),
        status: 'pending'
      });

      toast.success('Message submitted! It will appear after admin approval.');
      setMessage('');
      if (onMessagePosted) onMessagePosted();
    } catch (err) {
      toast.error('Failed to post message');
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6 text-center">
          <p className="text-gray-400 mb-4">Sign in to leave a message</p>
          <Button
            onClick={() => base44.auth.redirectToLogin()}
            className="bg-amber-500 hover:bg-amber-600"
          >
            Sign In
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader>
        <CardTitle>Leave a Message</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Textarea
            placeholder="Share your love for Glossiano... (max 500 characters)"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            disabled={isLoading}
            className="bg-slate-700 border-slate-600 text-white resize-none"
            rows={4}
          />
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">
              {message.length}/500
            </span>
            <Button
              type="submit"
              disabled={isLoading || !message.trim()}
              className="bg-amber-500 hover:bg-amber-600 gap-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Posting...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  Post Message
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}