import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';

export default function PredictiveEarnings({ data, isLoading }) {
  const predictedData = [
    { month: 'Current', earnings: data?.predictiveEarnings?.currentMonth || 0 },
    { month: 'Next Month', earnings: data?.predictiveEarnings?.nextMonth || 0 },
    { month: '3 Months', earnings: Math.round((data?.predictiveEarnings?.nextMonth || 0) * 1.15) }
  ];

  const growth = data?.predictiveEarnings?.growth || 0;
  const isPositive = growth >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
    >
      <Card className="bg-gradient-to-br from-green-900/20 to-black border-green-500/30 h-full">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white">Predictive Earnings</CardTitle>
            <div className={`flex items-center gap-1 px-3 py-1 rounded-full ${isPositive ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
              {isPositive ? <TrendingUp className="h-4 w-4 text-green-400" /> : <TrendingDown className="h-4 w-4 text-red-400" />}
              <span className={`text-sm font-bold ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                {Math.abs(growth)}%
              </span>
            </div>
          </div>
          <p className="text-gray-400 text-sm mt-2">30-day forecast based on current trends</p>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-gray-400">Analyzing trends...</div>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={predictedData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#4b5563" />
                <XAxis dataKey="month" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }}
                  formatter={(value) => `$${value.toFixed(2)}`}
                />
                <Line type="monotone" dataKey="earnings" stroke="#10b981" strokeWidth={2} dot={{ fill: '#34d399' }} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}