import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, MapPin, Music } from 'lucide-react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

export default function AudienceInsights({ data, isLoading }) {
  const insights = data?.audienceInsights || {};

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6 }}
    >
      <Card className="bg-gradient-to-br from-purple-900/20 to-black border-purple-500/30 h-full">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="h-5 w-5 text-purple-400" />
            Audience Insights
          </CardTitle>
          <p className="text-gray-400 text-sm mt-2">Fan demographics & engagement patterns</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="text-gray-400 text-sm">Analyzing audience data...</div>
          ) : (
            <>
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-gray-500 uppercase mb-2">Top Audience Age</p>
                  <Badge className="bg-purple-600">{insights.topAgeGroup || 'N/A'}</Badge>
                </div>

                <div>
                  <p className="text-xs text-gray-500 uppercase mb-2">Fastest Growing Segment</p>
                  <Badge className="bg-blue-600">{insights.growthAgeGroup || 'N/A'}</Badge>
                </div>

                <div>
                  <p className="text-xs text-gray-500 uppercase mb-2">Listener Retention</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-black/50 rounded-full h-2 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-purple-400"
                        style={{ width: `${insights.retention || 0}%` }}
                      />
                    </div>
                    <span className="text-sm text-purple-400">{insights.retention || 0}%</span>
                  </div>
                </div>

                {insights.preferredGenres && insights.preferredGenres.length > 0 && (
                  <div>
                    <p className="text-xs text-gray-500 uppercase mb-2 flex items-center gap-1">
                      <Music className="h-3 w-3" /> Preferred Genres
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {insights.preferredGenres.slice(0, 3).map((genre, idx) => (
                        <Badge key={idx} className="bg-purple-700/50" variant="outline">
                          {genre}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {insights.topRegions && insights.topRegions.length > 0 && (
                  <div>
                    <p className="text-xs text-gray-500 uppercase mb-2 flex items-center gap-1">
                      <MapPin className="h-3 w-3" /> Top Regions
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {insights.topRegions.slice(0, 3).map((region, idx) => (
                        <Badge key={idx} className="bg-purple-700/50" variant="outline">
                          {region}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}