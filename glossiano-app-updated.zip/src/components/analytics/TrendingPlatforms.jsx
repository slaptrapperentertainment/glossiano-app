import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Zap, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

export default function TrendingPlatforms({ data, isLoading }) {
  const platforms = data?.trendingPlatforms || [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.7 }}
    >
      <Card className="bg-gradient-to-br from-orange-900/20 to-black border-orange-500/30 h-full">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="h-5 w-5 text-orange-400" />
            Trending Platforms
          </CardTitle>
          <p className="text-gray-400 text-sm mt-2">Growth opportunities & platform momentum</p>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-gray-400 text-sm">Analyzing platform trends...</div>
          ) : platforms.length > 0 ? (
            <div className="space-y-3">
              {platforms.slice(0, 4).map((platform, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-black/30 rounded-lg border border-orange-500/20 hover:border-orange-500/40 transition-all"
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="font-semibold text-white">{platform.name}</span>
                    <Badge className="bg-orange-600 flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      +{platform.growth}%
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-400">{platform.potential}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 text-sm text-center py-8">No platform data available</p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}