import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Lightbulb, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SmartRecommendations({ data, isLoading }) {
  const recommendations = data?.recommendations || [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.8 }}
      className="lg:col-span-2"
    >
      <Card className="bg-gradient-to-br from-cyan-900/20 to-black border-cyan-500/30 h-full">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-cyan-400" />
            AI Recommendations
          </CardTitle>
          <p className="text-gray-400 text-sm mt-2">Personalized growth strategies based on your data</p>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-gray-400 text-sm">Generating recommendations...</div>
          ) : recommendations.length > 0 ? (
            <div className="space-y-3">
              {recommendations.map((rec, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 * idx }}
                  className="flex gap-3 p-3 bg-black/30 rounded-lg border border-cyan-500/20 hover:border-cyan-500/40 transition-all"
                >
                  <CheckCircle2 className="h-5 w-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-300">{rec}</p>
                </motion.div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 text-sm text-center py-8">No recommendations available</p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}