import React, { useState, useRef, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Play, Pause, SkipForward, Volume2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function DJPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(70);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [playlist, setPlaylist] = useState([]);
  const [showControls, setShowControls] = useState(false);
  const audioRef = useRef(null);
  const canvasRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const animationRef = useRef(null);

  const { data: settings = [] } = useQuery({
    queryKey: ['settings'],
    queryFn: () => base44.entities.Settings.list('', 1)
  });

  const audioUrls = settings[0]?.dj_audio_urls || [];

  // Initialize playlist with shuffled order
  useEffect(() => {
    if (audioUrls.length > 0) {
      const shuffled = [...audioUrls].sort(() => Math.random() - 0.5);
      setPlaylist(shuffled);
      setCurrentTrackIndex(0);
    }
  }, [audioUrls.length]);

  // Setup audio visualizer
  useEffect(() => {
    if (!audioRef.current || !canvasRef.current) return;

    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 64;
      
      const source = audioContextRef.current.createMediaElementSource(audioRef.current);
      source.connect(analyserRef.current);
      analyserRef.current.connect(audioContextRef.current.destination);
    }

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const bufferLength = analyserRef.current.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      if (!isPlaying) return;
      
      animationRef.current = requestAnimationFrame(draw);
      analyserRef.current.getByteFrequencyData(dataArray);

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const barWidth = canvas.width / bufferLength;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * canvas.height * 0.8;
        const hue = (i / bufferLength) * 60 + 30;
        ctx.fillStyle = `hsl(${hue}, 100%, 50%)`;
        ctx.fillRect(x, canvas.height - barHeight, barWidth - 1, barHeight);
        x += barWidth;
      }
    };

    if (isPlaying) {
      draw();
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying]);

  // Control playback
  useEffect(() => {
    if (!audioRef.current || playlist.length === 0) return;

    if (isPlaying) {
      audioContextRef.current?.resume();
      audioRef.current.play().catch(err => {
        console.error('Error playing audio:', err);
        setIsPlaying(false);
      });
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying, playlist.length]);

  // Update volume
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume / 100;
    }
  }, [volume]);

  const handleNext = () => {
    if (playlist.length > 1) {
      setCurrentTrackIndex((prev) => (prev + 1) % playlist.length);
    }
  };

  const handleTrackEnd = () => {
    handleNext();
  };

  if (playlist.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-6 right-6 z-40"
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
    >
      <div className="bg-neutral-900/95 backdrop-blur-md rounded-2xl shadow-2xl border border-amber-500/20 overflow-hidden">
        {/* Visualizer */}
        <canvas 
          ref={canvasRef}
          width={280}
          height={60}
          className="w-full"
        />

        {/* Controls */}
        <div className="p-4 space-y-3">
          <div className="flex items-center gap-3">
            <Button
              onClick={() => setIsPlaying(!isPlaying)}
              size="icon"
              className="h-12 w-12 rounded-full bg-amber-600 hover:bg-amber-700"
            >
              {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
            </Button>

            {playlist.length > 1 && (
              <Button
                onClick={handleNext}
                size="icon"
                variant="ghost"
                className="h-10 w-10 text-white hover:bg-white/10"
              >
                <SkipForward className="h-5 w-5" />
              </Button>
            )}

            <div className="flex-1 flex items-center gap-2">
              <Volume2 className="h-4 w-4 text-amber-500" />
              <Slider
                value={[volume]}
                onValueChange={(val) => setVolume(val[0])}
                max={100}
                step={1}
                className="flex-1"
              />
              <span className="text-xs text-white/60 w-8">{volume}%</span>
            </div>
          </div>

          {playlist.length > 1 && (
            <div className="text-center text-xs text-white/60">
              Pista {currentTrackIndex + 1} de {playlist.length}
            </div>
          )}
        </div>
      </div>

      <audio 
        ref={audioRef} 
        src={playlist[currentTrackIndex]}
        onEnded={handleTrackEnd}
      />
    </motion.div>
  );
}