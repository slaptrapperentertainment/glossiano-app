import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function VintageGrid({ products }) {
  const GRID_SIZE = 25; // 5x5
  const CHANGE_INTERVAL = 2000; // 2 seconds per cell change
  
  // Get unique images from products
  const productImages = useMemo(() => {
    if (!products || products.length === 0) return [];
    return products
      .filter(p => p.main_image)
      .map(p => ({ image: p.main_image, title: p.title, id: p.id }));
  }, [products]);

  // Initialize grid with random images
  const [grid, setGrid] = useState(() => {
    const initial = [];
    for (let i = 0; i < GRID_SIZE; i++) {
      initial.push({
        index: i,
        imageIndex: productImages.length > 0 ? Math.floor(Math.random() * productImages.length) : 0
      });
    }
    return initial;
  });

  // Rotate images one cell at a time
  useEffect(() => {
    if (productImages.length === 0) return;

    const interval = setInterval(() => {
      const randomCell = Math.floor(Math.random() * GRID_SIZE);
      const newImageIndex = Math.floor(Math.random() * productImages.length);
      
      setGrid(prev => prev.map((cell, idx) => 
        idx === randomCell 
          ? { ...cell, imageIndex: newImageIndex }
          : cell
      ));
    }, CHANGE_INTERVAL);

    return () => clearInterval(interval);
  }, [productImages.length]);

  // Update grid when products change
  useEffect(() => {
    if (productImages.length > 0) {
      setGrid(prev => prev.map((cell, idx) => ({
        ...cell,
        imageIndex: Math.floor(Math.random() * productImages.length)
      })));
    }
  }, [productImages.length]);

  if (productImages.length === 0) {
    return (
      <div className="w-full aspect-square bg-neutral-900 flex items-center justify-center">
        <p className="text-neutral-500 font-light tracking-wide">No products yet</p>
      </div>
    );
  }

  return (
    <>
      <div className="w-full relative">
        <div className="grid grid-cols-5 gap-1 md:gap-2">
          {grid.map((cell, idx) => {
            const product = productImages[cell.imageIndex % productImages.length];
            return (
              <Link
                key={idx}
                to={createPageUrl('ProductDetail') + `?id=${product?.id}`}
                className="aspect-square relative overflow-hidden bg-white group cursor-pointer"
              >
                <AnimatePresence mode="wait">
                  <motion.img
                    key={`${idx}-${cell.imageIndex}`}
                    src={product?.image}
                    alt={product?.title || 'Vintage product'}
                    className="w-full h-full object-cover"
                    initial={{ opacity: 0, scale: 1.1 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.5, ease: "easeInOut" }}
                  />
                </AnimatePresence>
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300 flex items-center justify-center">
                  <span className="text-white text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                    Ver
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>


    </>
  );
}