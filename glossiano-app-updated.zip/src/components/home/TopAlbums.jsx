import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { ArrowRight, Music } from 'lucide-react';

export default function TopAlbums() {
  const albums = [
    {
      id: 1,
      title: '307 GOLD',
      artist: 'Glossiano',
      cover: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6996ccbe40dedb6ea38067cd/bb96c4ed4_800x800-9564824--E041FC77-36E3-4E34-93D9D56CC39D2CB0--0--1721828--493FDA602D0B43E588286CF054699C6121.jpg'
    },
    {
      id: 2,
      title: 'EARTHQUAKE',
      artist: 'Glossiano',
      cover: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6996ccbe40dedb6ea38067cd/97e9529eb_InShot_20251214_191029204.jpg'
    },
    {
      id: 3,
      title: 'COME TAKE A RIDE',
      artist: 'Glossiano',
      cover: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6996ccbe40dedb6ea38067cd/7e29e89cc_20260104_203112_00001.jpg'
    }
  ];

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-transparent via-yellow-950/10 to-transparent">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h2 className="text-3xl md:text-5xl font-black text-white mb-4 flex items-center gap-3">
            <Music className="h-8 w-8 text-yellow-400" />
            TOP ALBUMS
          </h2>
          <p className="text-gray-400 text-lg">Explore Glossiano's latest and greatest albums</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {albums.map((album, index) => (
            <motion.div
              key={album.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="relative overflow-hidden rounded-xl shadow-2xl">
                <img
                  src={album.cover}
                  alt={album.title}
                  className="w-full aspect-square object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                  <h3 className="text-2xl font-bold text-white mb-1">{album.title}</h3>
                  <p className="text-yellow-400 font-semibold mb-4">{album.artist}</p>
                  <Link to={createPageUrl('MusicShop')}>
                    <Button className="bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white w-full font-bold">
                      Explore Album
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-xl font-bold text-white">{album.title}</h3>
                <p className="text-gray-400">{album.artist}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="text-center"
        >
          <Link to={createPageUrl('MusicShop')}>
            <Button className="bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white font-bold px-8 py-3 text-lg">
              View All Albums
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}