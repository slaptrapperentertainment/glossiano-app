import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Play, Pause, ShoppingCart, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/components/cart/CartContext';
import { toast } from 'sonner';

export default function BeatsShowcase() {
  const [playingId, setPlayingId] = useState(null);
  const [audioElements] = useState({});
  const { addToCart } = useCart();

  const { data: tracks = [] } = useQuery({
    queryKey: ['beats-showcase'],
    queryFn: () => base44.entities.Track.filter({ for_sale: true }, '-created_date', 20),
    initialData: []
  });

  const handlePlayPause = (trackId, audioUrl) => {
    if (playingId === trackId) {
      audioElements[trackId]?.pause();
      setPlayingId(null);
    } else {
      // Pause currently playing track
      if (playingId && audioElements[playingId]) {
        audioElements[playingId].pause();
      }
      
      // Play new track
      if (!audioElements[trackId]) {
        audioElements[trackId] = new Audio(audioUrl);
      }
      audioElements[trackId].play();
      setPlayingId(trackId);

      // Reset when finished
      audioElements[trackId].onended = () => setPlayingId(null);
    }
  };

  const handleBuy = (track) => {
    addToCart({
      id: track.id,
      title: track.title,
      price: track.price,
      artist: track.artist,
      image: track.cover_image
    });
    toast.success(`${track.title} added to cart!`);
  };

  if (tracks.length === 0) {
    return null;
  }

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-transparent via-pink-950/10 to-transparent">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center"
        >
          <h2 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500 mb-4">
            PREMIUM BEATS
          </h2>
          <p className="text-gray-300 text-lg">
            Stream, download, and license exclusive tracks instantly
          </p>
        </motion.div>

        <div className="space-y-3">
          {tracks.map((track, index) => (
            <motion.div
              key={track.id}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              className="group bg-gradient-to-r from-black/80 via-pink-900/20 to-black/80 border border-yellow-500/20 hover:border-yellow-500/60 rounded-xl p-4 transition-all hover:shadow-lg hover:shadow-pink-500/20"
            >
              <div className="flex items-center gap-4">
                {/* Play Button */}
                <button
                  onClick={() => handlePlayPause(track.id, track.audio_url)}
                  className="w-14 h-14 flex-shrink-0 bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 rounded-full flex items-center justify-center transition-all group-hover:scale-110"
                >
                  {playingId === track.id ? (
                    <Pause className="h-6 w-6 text-white" />
                  ) : (
                    <Play className="h-6 w-6 text-white ml-1" />
                  )}
                </button>

                {/* Cover Image */}
                <div className="w-16 h-16 flex-shrink-0 rounded-lg overflow-hidden">
                  <img
                    src={track.cover_image || 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=100'}
                    alt={track.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Track Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-white font-bold text-lg truncate">
                    {track.title}
                  </h3>
                  <p className="text-yellow-400 text-sm truncate">
                    {track.artist}
                  </p>
                  {track.genre && (
                    <p className="text-gray-400 text-xs mt-1">
                      {track.genre}
                    </p>
                  )}
                </div>

                {/* BPM & Key (if available) */}
                {track.description && (
                  <div className="hidden md:block text-gray-400 text-sm">
                    {track.description.substring(0, 50)}...
                  </div>
                )}

                {/* Price & Buy Button */}
                <div className="flex items-center gap-3 flex-shrink-0">
                  <div className="text-right hidden sm:block">
                    <div className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">
                      ${track.price}
                    </div>
                    {track.play_count > 0 && (
                      <div className="text-xs text-gray-500">
                        {track.play_count} plays
                      </div>
                    )}
                  </div>
                  
                  <Button
                    onClick={() => handleBuy(track)}
                    className="bg-gradient-to-r from-yellow-500 to-pink-600 hover:from-yellow-600 hover:to-pink-700 text-black font-bold px-6 py-5 text-base"
                  >
                    <ShoppingCart className="h-5 w-5 mr-2" />
                    <span className="hidden sm:inline">Buy Now</span>
                    <span className="sm:hidden">${track.price}</span>
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {tracks.length === 0 && (
          <div className="text-center py-20 text-gray-400">
            <p className="text-xl">No beats available yet. Check back soon!</p>
          </div>
        )}
      </div>
    </section>
  );
}