import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ShoppingCart, Play, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/components/cart/CartContext';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const GLOSSIANO_SPOTIFY = 'https://open.spotify.com/artist/6k9SnEyc22WsxHZTlu2w0X';
const GLOSSIANO_APPLE_MUSIC = 'https://music.apple.com/us/artist/glossiano/1234567890';

export default function FeaturedMusicSection() {
  const { data: tracks = [] } = useQuery({
    queryKey: ['glossiano-tracks-featured'],
    queryFn: () => base44.entities.Track.filter({ artist: 'Glossiano' }, '-created_date', 6),
    initialData: []
  });

  const { addToCart } = useCart();
  const [playingId, setPlayingId] = useState(null);
  const [audioRef] = React.useState({});

  const newReleases = tracks.slice(0, 3);
  const featuredTracks = tracks.filter(t => t.featured).slice(0, 3);

  const handlePlay = (trackId, audioUrl, trackTitle) => {
    if (playingId === trackId) {
      audioRef[trackId]?.pause();
      setPlayingId(null);
    } else {
      if (playingId) audioRef[playingId]?.pause();
      const audio = new Audio(audioUrl);
      audioRef[trackId] = audio;
      audio.play();
      setPlayingId(trackId);

      // Track stream analytics
      base44.analytics.track({
        eventName: 'track_played',
        properties: {
          track_id: trackId,
          track_title: trackTitle,
          artist: 'Glossiano',
          platform: 'featured_section'
        }
      });

      // Increment play count
      base44.functions.invoke('incrementPlayCount', { trackId });
    }
  };

  const handleAddToCart = (track) => {
    if (track.for_sale && track.price) {
      addToCart({
        id: track.id,
        title: track.title,
        price: track.price,
        artist: track.artist,
        image: track.cover_image
      });
      
      // Track purchase analytics
      base44.analytics.track({
        eventName: 'track_added_to_cart',
        properties: {
          track_id: track.id,
          track_title: track.title,
          price: track.price,
          artist: 'Glossiano',
          platform: 'featured_section'
        }
      });

      toast.success(`"${track.title}" added to cart!`);
    } else {
      toast.error('This track is not available for purchase');
    }
  };

  return (
    <div className="space-y-16 py-20 px-4">
      {/* New Releases */}
      <section>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-8"
        >
          <h2 className="text-4xl md:text-5xl font-black text-white mb-2">
            NEW RELEASES
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500 ml-3">🔥</span>
          </h2>
          <p className="text-gray-400">Fresh beats from Glossiano</p>
        </motion.div>

        {newReleases.length > 0 ? (
          <div className="grid md:grid-cols-3 gap-6">
            {newReleases.map((track, idx) => (
              <motion.div
                key={track.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/30 overflow-hidden group hover:border-yellow-500/60 transition-all h-full">
                  <CardContent className="p-0">
                    <div className="relative aspect-square overflow-hidden">
                      <img
                        src={track.cover_image || 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400'}
                        alt={track.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <button
                        onClick={() => handlePlay(track.id, track.audio_url, track.title)}
                        className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <div className="bg-gradient-to-r from-pink-600 to-yellow-500 rounded-full p-4">
                          <Play className="h-8 w-8 text-white ml-1" />
                        </div>
                      </button>
                      {track.featured && (
                        <Badge className="absolute top-3 right-3 bg-gradient-to-r from-pink-600 to-yellow-500">
                          ⭐ Featured
                        </Badge>
                      )}
                    </div>

                    <div className="p-5 space-y-4">
                      <div>
                        <h3 className="text-lg font-bold text-white line-clamp-2">{track.title}</h3>
                        <p className="text-yellow-400 text-sm">{track.artist}</p>
                        {track.album && <p className="text-gray-400 text-xs mt-1">{track.album}</p>}
                      </div>

                      {track.description && (
                        <p className="text-gray-300 text-sm line-clamp-2">{track.description}</p>
                      )}

                      <div className="flex gap-2 pt-2">
                         <Button
                           onClick={() => handlePlay(track.id, track.audio_url, track.title)}
                           size="sm"
                           className="flex-1 bg-black/50 hover:bg-black/70 border border-yellow-500/30 text-yellow-400"
                         >
                           <Play className="h-4 w-4 mr-1" />
                           Play
                         </Button>
                        {track.for_sale && (
                          <Button
                            onClick={() => handleAddToCart(track)}
                            size="sm"
                            className="flex-1 bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white"
                          >
                            <ShoppingCart className="h-4 w-4 mr-1" />
                            ${track.price}
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-gray-400">
            <p>No tracks available yet</p>
          </div>
        )}
      </section>

      {/* CTA to Music Shop */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-gradient-to-r from-pink-900/40 via-purple-900/40 to-yellow-900/40 border border-yellow-500/30 rounded-xl p-8 md:p-12 text-center"
      >
        <h3 className="text-3xl md:text-4xl font-black text-white mb-4">
          Browse Full Music Shop
        </h3>
        <p className="text-gray-300 text-lg mb-8 max-w-2xl mx-auto">
          Discover all Glossiano's exclusive tracks, beat packs, and samples. Buy directly and support independent music.
        </p>
        <div className="flex gap-3 justify-center flex-wrap mb-6">
          <a href={GLOSSIANO_SPOTIFY} target="_blank" rel="noopener noreferrer">
            <Button className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-full text-sm font-bold">
              🎧 Spotify
            </Button>
          </a>
          <a href={GLOSSIANO_APPLE_MUSIC} target="_blank" rel="noopener noreferrer">
            <Button className="bg-gray-900 hover:bg-gray-800 text-white border border-gray-700 px-6 py-2 rounded-full text-sm font-bold">
              🎵 Apple Music
            </Button>
          </a>
        </div>
        <Link to={createPageUrl('MusicShop')}>
          <Button className="bg-gradient-to-r from-yellow-400 to-pink-500 hover:from-yellow-500 hover:to-pink-600 text-black px-8 py-3 text-lg font-bold rounded-full">
            Shop All Music
            <ArrowRight className="h-5 w-5 ml-2" />
          </Button>
        </Link>
      </motion.div>
    </div>
  );
}