import React, { useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Play, Square, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function LiveStreamPlayer({ streamName, accountId }) {
  const videoRef = useRef(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const streamRef = useRef(null);

  const startStream = async () => {
    setIsLoading(true);
    
    try {
      // Get publish token
      const response = await base44.functions.invoke('createMillicastToken', {
        label: streamName,
        streams: [{
          streamName: streamName,
          isRegex: false
        }]
      });

      const token = response.data.token;

      // Get user media
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });

      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      setIsStreaming(true);
      toast.success('Live stream started!');

    } catch (error) {
      console.error('Stream error:', error);
      toast.error('Failed to start stream: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const stopStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    
    setIsStreaming(false);
    toast.success('Stream stopped');
  };

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  return (
    <div className="space-y-4">
      <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className="w-full h-full object-cover"
        />
        {!isStreaming && (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-pink-900/50 to-black">
            <Play className="h-16 w-16 text-yellow-400 opacity-50" />
          </div>
        )}
      </div>

      <div className="flex gap-2">
        {!isStreaming ? (
          <Button
            onClick={startStream}
            disabled={isLoading}
            className="flex-1 bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Starting...
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Go Live
              </>
            )}
          </Button>
        ) : (
          <Button
            onClick={stopStream}
            variant="destructive"
            className="flex-1"
          >
            <Square className="mr-2 h-4 w-4" />
            Stop Stream
          </Button>
        )}
      </div>
    </div>
  );
}