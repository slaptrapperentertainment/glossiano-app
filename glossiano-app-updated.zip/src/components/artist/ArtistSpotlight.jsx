import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ArtistCard from './ArtistCard';

export default function ArtistSpotlight() {
  const { data: featuredArtists = [] } = useQuery({
    queryKey: ['featured-artists'],
    queryFn: () => base44.entities.Artist.filter({ featured: true }, '-created_date', 6),
    initialData: []
  });

  if (featuredArtists.length === 0) return null;

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-transparent via-yellow-950/10 to-transparent">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-12 flex items-center justify-between"
        >
          <div>
            <h2 className="text-3xl md:text-5xl font-black text-white mb-4 flex items-center gap-3">
              <Sparkles className="h-8 w-8 text-yellow-400" />
              ARTIST SPOTLIGHT
            </h2>
            <p className="text-gray-400 text-lg">Discover rising stars and featured artists in our community</p>
          </div>
          <Link to={createPageUrl('ArtistBrowser')}>
            <Button className="bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white hidden md:flex gap-2">
              Browse All <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {featuredArtists.map((artist, index) => (
            <ArtistCard key={artist.id} artist={artist} index={index} />
          ))}
        </div>

        <Link to={createPageUrl('ArtistBrowser')} className="md:hidden">
          <Button className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white">
            Browse All Artists <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </Link>
      </div>
    </section>
  );
}