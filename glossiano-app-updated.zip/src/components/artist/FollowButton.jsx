import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Heart, Bell } from 'lucide-react';
import { toast } from 'sonner';

export default function FollowButton({ artistName }) {
  const [isFollowing, setIsFollowing] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkFollowStatus = async () => {
      try {
        const currentUser = await base44.auth.me();
        if (!currentUser) {
          setLoading(false);
          return;
        }

        setUser(currentUser);

        // Check if already following
        const followers = await base44.entities.Follower.filter({
          fan_email: currentUser.email,
          artist_name: artistName
        }, '', 1);

        if (followers.length > 0 && followers[0].is_following) {
          setIsFollowing(true);
        }
      } catch (error) {
        console.error('Error checking follow status:', error);
      } finally {
        setLoading(false);
      }
    };

    checkFollowStatus();
  }, [artistName]);

  const handleFollow = async (e) => {
    e.preventDefault();
    e.stopPropagation();

    if (!user) {
      await base44.auth.redirectToLogin();
      return;
    }

    try {
      setLoading(true);

      // Check if already exists
      const existing = await base44.entities.Follower.filter({
        fan_email: user.email,
        artist_name: artistName
      }, '', 1);

      if (existing.length > 0) {
        // Update existing record
        await base44.entities.Follower.update(existing[0].id, {
          is_following: !isFollowing,
          notification_preference: 'both'
        });
      } else {
        // Create new follower record
        await base44.entities.Follower.create({
          fan_email: user.email,
          fan_name: user.full_name,
          artist_name: artistName,
          is_following: true,
          notification_preference: 'both'
        });
      }

      setIsFollowing(!isFollowing);
      toast.success(isFollowing ? `Unfollowed ${artistName}` : `Following ${artistName}! You'll get notified about new releases.`);
    } catch (error) {
      console.error('Error toggling follow:', error);
      toast.error('Failed to update follow status');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      onClick={handleFollow}
      disabled={loading}
      className={`w-full ${
        isFollowing
          ? 'bg-pink-600 hover:bg-pink-700'
          : 'bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600'
      } text-white font-semibold`}
    >
      {isFollowing ? (
        <>
          <Heart className="h-4 w-4 mr-2 fill-current" />
          Following
        </>
      ) : (
        <>
          <Heart className="h-4 w-4 mr-2" />
          Follow
        </>
      )}
    </Button>
  );
}