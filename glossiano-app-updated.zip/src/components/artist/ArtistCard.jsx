import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Music2 } from 'lucide-react';

export default function ArtistCard({ artist, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
    >
      <Link to={`${createPageUrl('ArtistDetail')}?id=${artist.id}`}>
        <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30 overflow-hidden group hover:border-yellow-500/60 transition-all cursor-pointer h-full">
          <CardContent className="p-0">
            {/* Banner */}
            <div className="relative aspect-video overflow-hidden">
              <img
                src={artist.banner || artist.image}
                alt={artist.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
            </div>

            {/* Content */}
            <div className="p-5 -mt-12 relative z-10">
              <div className="relative mb-4">
                <img
                  src={artist.image}
                  alt={artist.name}
                  className="w-20 h-20 rounded-full object-cover border-4 border-black shadow-lg"
                />
              </div>

              <h3 className="text-xl font-bold text-white mb-1 truncate">{artist.name}</h3>
              {artist.genre && (
                <Badge className="mb-3 bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                  {artist.genre}
                </Badge>
              )}

              {artist.bio && (
                <p className="text-gray-300 text-sm mb-4 line-clamp-2">{artist.bio}</p>
              )}

              <div className="flex gap-4 text-sm text-gray-400">
                {artist.follower_count > 0 && (
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    <span>{artist.follower_count} followers</span>
                  </div>
                )}
                {artist.release_count > 0 && (
                  <div className="flex items-center gap-1">
                    <Music2 className="h-4 w-4" />
                    <span>{artist.release_count} tracks</span>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
}