import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Music, Zap, BarChart3, Users, Radio, Sparkles, Lock, Headphones } from 'lucide-react';

export default function ServicesShowcase() {
  const services = [
    {
      icon: Music,
      title: 'Music Distribution',
      description: 'Upload once, distribute to 90+ platforms including Spotify, Apple Music, YouTube, Amazon, and more',
      features: ['Upload MP3/WAV', 'Instant distribution', 'ISRC/UPC generation', 'Unlimited updates']
    },
    {
      icon: Sparkles,
      title: 'Professional Mastering',
      description: 'Professional audio mastering service integrated directly into your workflow via MIXMEA',
      features: ['Multiple tier options', 'Fast turnaround', 'Industry standard quality', 'Direct integration']
    },
    {
      icon: BarChart3,
      title: 'Real-Time Analytics',
      description: 'Track every stream, download, and dollar earned across all platforms in real-time',
      features: ['Live stream count', 'Revenue tracking', 'Demographic insights', 'Platform breakdown']
    },
    {
      icon: Radio,
      title: 'Playlist Pitching',
      description: 'Get your music in front of curators and reach millions of listeners',
      features: ['Curator network', 'Smart pitching', 'Campaign tracking', 'Performance metrics']
    },
    {
      icon: Users,
      title: 'Royalty Splitting',
      description: 'Automatically split royalties with collaborators and producers',
      features: ['Smart contracts', 'Auto-payout', 'Transparent tracking', 'Multiple recipients']
    },
    {
      icon: Headphones,
      title: 'Artist Dashboard',
      description: 'Complete control over your releases with an intuitive artist dashboard',
      features: ['Release management', 'Earnings dashboard', 'Collaborator tools', 'Release scheduling']
    },
    {
      icon: Lock,
      title: 'Rights Management',
      description: 'Manage ownership, rights, and metadata for all your releases',
      features: ['Copyright protection', 'Metadata management', 'Rights tracking', 'Ownership control']
    },
    {
      icon: Zap,
      title: 'Instant Publishing',
      description: 'Your music goes live within 24 hours, not weeks',
      features: ['24-hour delivery', 'Pre-order setup', 'Release scheduling', 'Instant updates']
    }
  ];

  return (
    <div className="py-16 px-4 bg-gradient-to-b from-transparent via-gray-900/20 to-transparent">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Everything You Need to Succeed
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            All the tools of major platforms like DistroKid, combined with better pricing and more flexibility
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, idx) => {
            const Icon = service.icon;
            const isPrimary = idx === 0 || idx === 1; // Distribution and Mastering highlighted

            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.05 }}
              >
                <Card className={`h-full border-2 ${isPrimary 
                  ? 'border-green-500/60 bg-gradient-to-br from-green-900/30 to-gray-900/30' 
                  : 'border-gray-700 bg-gray-900/20'} relative overflow-hidden group hover:border-green-500/80 transition-all`}>
                  
                  {isPrimary && (
                    <div className="absolute -right-8 -top-8 w-32 h-32 bg-gradient-to-br from-green-500/20 to-transparent rounded-full blur-2xl group-hover:from-green-500/30 transition-all"></div>
                  )}

                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${isPrimary 
                      ? 'from-green-500 to-emerald-600' 
                      : 'from-pink-600 to-yellow-600'} flex items-center justify-center mb-4`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-white text-lg">{service.title}</CardTitle>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <p className="text-gray-400 text-sm leading-relaxed">
                      {service.description}
                    </p>
                    <ul className="space-y-2">
                      {service.features.map((feature, fidx) => (
                        <li key={fidx} className="flex items-center gap-2 text-sm text-gray-300">
                          <div className={`w-1.5 h-1.5 rounded-full ${isPrimary ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 bg-gradient-to-r from-gray-900/40 to-black border border-gray-700 rounded-lg p-8"
        >
          <h3 className="text-2xl font-bold text-white mb-8">How We Compare</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-white font-semibold mb-4">DistroKid</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>✓ Distribution</li>
                <li>✓ Analytics</li>
                <li>✗ Integrated mastering</li>
                <li className="text-red-400">High fees ($12/year)</li>
                <li className="text-red-400">Limited customization</li>
              </ul>
            </div>

            <div className="border-l border-r border-gray-700 px-8">
              <h4 className="text-green-400 font-bold mb-4">Our Platform</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="text-green-400">✓ Distribution</li>
                <li className="text-green-400">✓ Analytics</li>
                <li className="text-green-400">✓ Integrated mastering</li>
                <li className="text-green-400 font-semibold">Better pricing ($7.99/year)</li>
                <li className="text-green-400">✓ Full customization</li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Other Platforms</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>✓ Distribution</li>
                <li>△ Basic analytics</li>
                <li>✗ No mastering</li>
                <li className="text-red-400">Variable fees</li>
                <li className="text-red-400">Complex royalty splits</li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}