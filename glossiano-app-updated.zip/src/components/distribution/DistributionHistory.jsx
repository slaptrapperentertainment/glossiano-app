import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { motion } from 'framer-motion';
import { Calendar, Music, Zap, CheckCircle, Clock, AlertCircle, Search } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function DistributionHistory() {
  const [searchTerm, setSearchTerm] = useState('');

  const { data: distributions = [], isLoading } = useQuery({
    queryKey: ['distribution-history'],
    queryFn: () => base44.entities.Distribution.list('-created_date', 100)
  });

  const filtered = distributions.filter(d =>
    d.release_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.artist_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusIcon = (status) => {
    switch (status) {
      case 'live':
        return <CheckCircle className="h-5 w-5 text-green-400" />;
      case 'processing':
        return <Zap className="h-5 w-5 text-yellow-400 animate-pulse" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-blue-400" />;
      case 'failed':
        return <AlertCircle className="h-5 w-5 text-red-400" />;
      default:
        return <Clock className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'live':
        return 'bg-green-500/20 border-green-500/50 text-green-300';
      case 'processing':
        return 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300';
      case 'pending':
        return 'bg-blue-500/20 border-blue-500/50 text-blue-300';
      case 'failed':
        return 'bg-red-500/20 border-red-500/50 text-red-300';
      default:
        return 'bg-gray-500/20 border-gray-500/50 text-gray-300';
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map(i => (
          <div key={i} className="h-32 bg-gray-900/30 rounded-lg animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search releases..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-black/50 border-yellow-500/30 text-white"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card className="bg-gradient-to-br from-pink-900/20 to-black border-yellow-500/20">
          <CardContent className="pt-12 pb-12 text-center">
            <Music className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No distributions found</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filtered.map((dist, idx) => (
            <motion.div
              key={dist.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
            >
              <Card className="bg-gradient-to-br from-pink-900/20 to-black border-yellow-500/20 hover:border-yellow-500/40 transition-all">
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    {/* Top Row */}
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-bold text-white">{dist.release_title}</h3>
                          <Badge className={getStatusColor(dist.status)}>
                            {dist.status.charAt(0).toUpperCase() + dist.status.slice(1)}
                          </Badge>
                        </div>
                        <p className="text-gray-400 text-sm">{dist.artist_name} • {dist.release_type}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(dist.status)}
                      </div>
                    </div>

                    {/* Stats Row */}
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500 mb-1">Streams</p>
                        <p className="text-yellow-400 font-semibold">{(dist.total_streams || 0).toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">Earnings</p>
                        <p className="text-green-400 font-semibold">${(dist.estimated_earnings || 0).toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">Platforms</p>
                        <p className="text-pink-400 font-semibold">{(dist.platforms_live || []).length}</p>
                      </div>
                    </div>

                    {/* Platforms & Dates Row */}
                    <div className="flex items-center justify-between pt-3 border-t border-yellow-500/10">
                      <div className="text-xs">
                        {dist.platforms_live && dist.platforms_live.length > 0 ? (
                          <div>
                            <p className="text-gray-500 mb-2">Live on:</p>
                            <div className="flex flex-wrap gap-2">
                              {dist.platforms_live.slice(0, 4).map(platform => (
                                <span key={platform} className="bg-yellow-500/20 text-yellow-300 px-2 py-1 rounded text-xs">
                                  {platform.replace(/_/g, ' ')}
                                </span>
                              ))}
                              {dist.platforms_live.length > 4 && (
                                <span className="text-gray-400 px-2 py-1">+{dist.platforms_live.length - 4} more</span>
                              )}
                            </div>
                          </div>
                        ) : (
                          <p className="text-gray-500">Not yet live on any platforms</p>
                        )}
                      </div>
                      <div className="text-right text-xs text-gray-500">
                        <div className="flex items-center gap-1 mb-1">
                          <Calendar className="h-3 w-3" />
                          Submitted {formatDistanceToNow(new Date(dist.created_date), { addSuffix: true })}
                        </div>
                        {dist.last_reconciliation_date && (
                          <div className="text-yellow-400 text-xs">
                            Last updated: {formatDistanceToNow(new Date(dist.last_reconciliation_date), { addSuffix: true })}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}