import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Upload, Loader2, CheckCircle2, AlertCircle, Music } from 'lucide-react';
import { toast } from 'sonner';

export default function MixmeaMastering({ audioFile, onMasteringSubmit }) {
  const [isUploading, setIsUploading] = useState(false);
  const [masteringData, setMasteringData] = useState({
    artist_name: '',
    song_title: '',
    genre: '',
    reference_url: '',
    special_instructions: '',
    service_tier: 'standard'
  });
  const [submittedMastering, setSubmittedMastering] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setMasteringData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmitMastering = async () => {
    if (!audioFile) {
      toast.error('Please upload an audio file first');
      return;
    }

    if (!masteringData.artist_name || !masteringData.song_title) {
      toast.error('Please fill in artist name and song title');
      return;
    }

    setIsUploading(true);
    try {
      const response = await base44.functions.invoke('submitMixmeaMastering', {
        ...masteringData,
        audio_url: audioFile.file_url
      });

      if (response.data.success) {
        setSubmittedMastering(response.data.mastering_id);
        toast.success('Mastering order submitted to MIXMEA!');
        if (onMasteringSubmit) {
          onMasteringSubmit(response.data);
        }
      } else {
        toast.error(response.data.error || 'Failed to submit mastering order');
      }
    } catch (error) {
      toast.error('Error submitting to MIXMEA: ' + error.message);
    } finally {
      setIsUploading(false);
    }
  };

  if (submittedMastering) {
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="bg-green-900/20 border-green-500/40">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <CheckCircle2 className="w-8 h-8 text-green-500 flex-shrink-0" />
              <div className="flex-1">
                <h3 className="font-semibold text-white mb-1">Mastering Order Submitted</h3>
                <p className="text-sm text-gray-300">Order ID: {submittedMastering}</p>
                <p className="text-xs text-gray-400 mt-1">Check MIXMEA dashboard for status updates</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="bg-gradient-to-br from-purple-900/20 to-black border-purple-500/30">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Music className="w-5 h-5 text-purple-400" />
            <div>
              <CardTitle>MIXMEA Mastering</CardTitle>
              <CardDescription>Professional audio mastering service</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {audioFile && (
            <div className="p-3 bg-green-900/20 border border-green-500/30 rounded-lg">
              <div className="flex items-center gap-2 text-sm text-green-400">
                <CheckCircle2 className="w-4 h-4" />
                Audio file ready: {audioFile.name}
              </div>
            </div>
          )}

          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Artist Name *</label>
              <Input
                name="artist_name"
                value={masteringData.artist_name}
                onChange={handleInputChange}
                placeholder="Your artist name"
                className="bg-black/50 border-gray-600"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Song Title *</label>
              <Input
                name="song_title"
                value={masteringData.song_title}
                onChange={handleInputChange}
                placeholder="Song title"
                className="bg-black/50 border-gray-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Genre</label>
                <Input
                  name="genre"
                  value={masteringData.genre}
                  onChange={handleInputChange}
                  placeholder="e.g., Hip-Hop, Electronic"
                  className="bg-black/50 border-gray-600"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Service Tier</label>
                <select
                  name="service_tier"
                  value={masteringData.service_tier}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 bg-black/50 border border-gray-600 rounded-md text-white text-sm"
                >
                  <option value="standard">Standard</option>
                  <option value="pro">Pro</option>
                  <option value="elite">Elite</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Reference Track URL</label>
              <Input
                name="reference_url"
                value={masteringData.reference_url}
                onChange={handleInputChange}
                placeholder="https://spotify.com/... (optional)"
                className="bg-black/50 border-gray-600"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Special Instructions</label>
              <Textarea
                name="special_instructions"
                value={masteringData.special_instructions}
                onChange={handleInputChange}
                placeholder="Any specific requirements or notes..."
                className="bg-black/50 border-gray-600 h-20"
              />
            </div>
          </div>

          <Button
            onClick={handleSubmitMastering}
            disabled={isUploading || !audioFile}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            {isUploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Submitting to MIXMEA...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                Submit for Mastering
              </>
            )}
          </Button>

          <p className="text-xs text-gray-400 text-center">
            Your audio will be processed by MIXMEA's mastering engineers
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
}