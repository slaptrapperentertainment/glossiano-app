import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Zap, Brain, TrendingUp, Radio, Users, Clock, Sparkles, Target, 
  Headphones, BarChart3, Mail, Shield 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function CompetitiveAdvantages() {
  const advantages = [
    {
      title: 'Express Distribution',
      subtitle: '1-2 Days to Global Reach',
      description: 'Get your music on 40+ platforms in 24-48 hours, not 3-5 days',
      icon: <Zap className="h-8 w-8" />,
      badge: 'FASTEST',
      details: ['No waiting', 'Spotify pitching auto-enabled', 'Live dashboard tracking']
    },
    {
      title: 'AI Curator Matching',
      subtitle: 'Automatic Playlist Pitching',
      description: 'AI intelligently pitches to 500+ curators matching your genre in real-time',
      icon: <Brain className="h-8 w-8" />,
      badge: 'AI-POWERED',
      details: ['Genre-matched curators', 'Custom pitch templates', 'Acceptance tracking']
    },
    {
      title: '40+ Global Platforms',
      subtitle: 'No Restrictions',
      description: 'Spotify, Apple Music, Amazon, YouTube, Tidal, Deezer, Bandcamp, SoundCloud + indie platforms + TikTok/Instagram',
      icon: <Sparkles className="h-8 w-8" />,
      badge: 'MOST PLATFORMS',
      details: ['All major streamers', 'Indie platforms', 'Social media integration']
    },
    {
      title: 'AI Marketing Campaigns',
      subtitle: 'Professional Strategy Included',
      description: 'Auto-generate platform-specific content, hashtags, and promotion strategies per release',
      icon: <Target className="h-8 w-8" />,
      badge: 'FREE WITH DISTRO',
      details: ['Instagram/TikTok copy', 'Budget allocation advice', 'Optimal posting times']
    },
    {
      title: 'A&R Artist Scouting',
      subtitle: 'Get Talent Recommendations',
      description: 'AI analyzes your track for commercial appeal, hit potential, and growth trajectory',
      icon: <Sparkles className="h-8 w-8" />,
      badge: 'UNIQUE',
      details: ['Hit potential scoring', 'Comparable tracks', 'Growth indicators']
    },
    {
      title: 'Real-Time Analytics',
      subtitle: 'Streaming + Earnings Dashboard',
      description: 'Watch streams, earnings, and playlist adds update in real-time across all platforms',
      icon: <BarChart3 className="h-8 w-8" />,
      badge: 'TRANSPARENT',
      details: ['Per-platform tracking', 'Revenue forecasting', 'Trend analysis']
    },
    {
      title: 'Review Sentiment Analysis',
      subtitle: 'Monitor Public Reception',
      description: 'AI aggregates reviews from Pitchfork, Genius, YouTube, streaming platforms to gauge success',
      icon: <Users className="h-8 w-8" />,
      badge: 'ADVANCED',
      details: ['Multi-source analysis', 'Sentiment scoring', 'Actionable feedback']
    },
    {
      title: 'Advanced Metadata',
      subtitle: 'Optimized for Discovery',
      description: 'AI generates mood tags, keywords, potential playlists, and SEO metadata automatically',
      icon: <Radio className="h-8 w-8" />,
      badge: 'DISCOVERY-FIRST',
      details: ['Auto mood tagging', 'Playlist suggestions', 'SEO optimization']
    },
    {
      title: '100% Artist Ownership',
      subtitle: 'Keep All Your Rights',
      description: 'You retain 100% of royalties and master ownership—no middleman cuts',
      icon: <Shield className="h-8 w-8" />,
      badge: 'TRANSPARENT',
      details: ['100% royalty payout', 'No hidden fees', 'Full master control']
    },
    {
      title: 'Unlimited Releases',
      subtitle: 'No Caps, No Limits',
      description: 'Release singles, EPs, albums—as many as you want with no per-release fees',
      icon: <Headphones className="h-8 w-8" />,
      badge: 'UNLIMITED',
      details: ['No release limits', 'Flat fee model', 'Bulk uploads supported']
    },
    {
      title: 'Fan Engagement Platform',
      subtitle: 'Direct Artist-Fan Connection',
      description: 'Built-in fan wall, messaging, membership tiers, and merch store integration',
      icon: <Mail className="h-8 w-8" />,
      badge: 'COMMUNITY',
      details: ['Direct fan messaging', 'VIP tiers', 'Merchandise sales']
    },
    {
      title: 'Music Quality First',
      subtitle: 'Mastering + Distribution',
      description: 'Optional professional mastering via Mixmea, or bring your own—no upsells',
      icon: <Clock className="h-8 w-8" />,
      badge: 'QUALITY',
      details: ['Professional mastering', 'Quality first', 'Flexible workflow']
    }
  ];

  const comparisonVsDistroKid = [
    { feature: 'Express Distribution (1-2 days)', slap: true, distrokid: 'Standard 3-5 days' },
    { feature: 'AI Curator Auto-Pitching', slap: true, distrokid: 'Manual only' },
    { feature: 'AI Marketing Campaigns', slap: true, distrokid: 'Paid add-on' },
    { feature: 'A&R Artist Scouting', slap: true, distrokid: false },
    { feature: 'Review Sentiment Analysis', slap: true, distrokid: false },
    { feature: 'Fan Engagement Platform', slap: true, distrokid: false },
    { feature: 'Platforms Included', slap: '40+', distrokid: '150+ (but many unused)' },
    { feature: '100% Royalty Payout', slap: true, distrokid: true },
    { feature: 'Unlimited Releases', slap: true, distrokid: 'Paid tier' },
    { feature: 'Membership Tiers', slap: true, distrokid: 'Basic only' }
  ];

  const Icon = ({ icon }) => icon;

  return (
    <div className="space-y-12 py-12">
      {/* Headline */}
      <div className="text-center space-y-4 mb-12">
        <h2 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500">
          Why Slap Trapper Beats DistroKid
        </h2>
        <p className="text-gray-300 text-lg max-w-2xl mx-auto">
          We're not just another distribution service. We're your all-in-one AI-powered music label, marketing team, and fanbase builder.
        </p>
      </div>

      {/* Advantages Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {advantages.map((adv, idx) => (
          <Card 
            key={idx}
            className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30 hover:border-yellow-500/60 transition-all group"
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between mb-2">
                <div className="text-yellow-400">{adv.icon}</div>
                <Badge className="bg-gradient-to-r from-pink-600 to-yellow-500 text-xs">
                  {adv.badge}
                </Badge>
              </div>
              <CardTitle className="text-white text-sm">{adv.title}</CardTitle>
              <p className="text-yellow-400 text-xs font-semibold">{adv.subtitle}</p>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-gray-300 text-sm leading-relaxed">{adv.description}</p>
              <div className="space-y-1 pt-2 border-t border-yellow-500/20">
                {adv.details.map((detail, i) => (
                  <p key={i} className="text-gray-400 text-xs flex items-center gap-2">
                    <span className="w-1 h-1 bg-yellow-400 rounded-full"></span>
                    {detail}
                  </p>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Direct Comparison */}
      <Card className="bg-gradient-to-br from-pink-900/30 to-black border-yellow-500/30">
        <CardHeader>
          <CardTitle className="text-2xl text-white">Direct Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-yellow-500/30">
                  <th className="text-left py-3 px-4 text-gray-300 font-semibold">Feature</th>
                  <th className="text-center py-3 px-4 text-yellow-400 font-bold">Slap Trapper</th>
                  <th className="text-center py-3 px-4 text-gray-400 font-semibold">DistroKid</th>
                </tr>
              </thead>
              <tbody>
                {comparisonVsDistroKid.map((row, idx) => (
                  <tr key={idx} className="border-b border-yellow-500/20 hover:bg-yellow-500/5">
                    <td className="py-3 px-4 text-gray-300">{row.feature}</td>
                    <td className="py-3 px-4 text-center">
                      {typeof row.slap === 'boolean' ? (
                        row.slap ? (
                          <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-500/20 text-green-400">✓</span>
                        ) : (
                          <span className="text-gray-500">✗</span>
                        )
                      ) : (
                        <span className="text-yellow-400 font-semibold">{row.slap}</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {typeof row.distrokid === 'boolean' ? (
                        row.distrokid ? (
                          <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-gray-500/20 text-gray-400">✓</span>
                        ) : (
                          <span className="text-gray-500">✗</span>
                        )
                      ) : (
                        <span className="text-gray-400 text-xs">{row.distrokid}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Key Differentiators */}
      <Card className="bg-gradient-to-br from-yellow-900/40 to-pink-900/40 border-yellow-500/50">
        <CardHeader>
          <CardTitle className="text-2xl text-white">What Makes Us Different</CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <h4 className="text-yellow-400 font-bold">🎯 AI-First Approach</h4>
            <p className="text-gray-300 text-sm">
              Every release gets intelligent analysis for genre-matched playlist pitching, marketing strategy, and A&R potential—automatically.
            </p>
          </div>
          <div className="space-y-3">
            <h4 className="text-yellow-400 font-bold">⚡ Speed as Standard</h4>
            <p className="text-gray-300 text-sm">
              Express distribution is our default, not an add-on. Your music goes global in 1-2 days, not waiting weeks.
            </p>
          </div>
          <div className="space-y-3">
            <h4 className="text-yellow-400 font-bold">👥 Artist Community First</h4>
            <p className="text-gray-300 text-sm">
              Direct fan engagement, membership tiers, and merch integration built-in—not bolt-on features.
            </p>
          </div>
          <div className="space-y-3">
            <h4 className="text-yellow-400 font-bold">💰 Transparent Pricing</h4>
            <p className="text-gray-300 text-sm">
              Flat fee, 100% royalty payout, unlimited releases. No surprise tiers or hidden cuts.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Bottom CTA */}
      <div className="text-center bg-gradient-to-r from-pink-900/30 to-yellow-900/30 border border-yellow-500/30 rounded-lg p-8">
        <h3 className="text-2xl font-bold text-white mb-4">
          Ready to Get Heard?
        </h3>
        <p className="text-gray-300 mb-6">
          Join artists who are tired of traditional distros. Express distribution + AI-powered discovery = More listeners, faster.
        </p>
      </div>
    </div>
  );
}