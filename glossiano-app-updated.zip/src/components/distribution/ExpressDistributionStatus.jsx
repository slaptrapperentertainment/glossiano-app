import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Zap, CheckCircle2, Clock, Music } from 'lucide-react';

export default function ExpressDistributionStatus({ distribution }) {
  const statusSteps = [
    { id: 'submitted', label: 'Submitted', icon: CheckCircle2 },
    { id: 'processing', label: 'Processing', icon: Clock },
    { id: 'ready_for_spotify', label: 'Spotify Ready', icon: Music },
    { id: 'spotify_pitching', label: 'Playlist Pitching', icon: Zap },
    { id: 'live', label: 'Live on Spotify', icon: CheckCircle2 }
  ];

  const currentStepIndex = statusSteps.findIndex(s => s.id === distribution.processing_status);

  const statusColors = {
    submitted: 'bg-blue-500/20 text-blue-400',
    processing: 'bg-yellow-500/20 text-yellow-400',
    ready_for_spotify: 'bg-purple-500/20 text-purple-400',
    spotify_pitching: 'bg-pink-500/20 text-pink-400',
    live: 'bg-green-500/20 text-green-400'
  };

  return (
    <Card className="bg-gradient-to-br from-black via-purple-900/20 to-black border-purple-500/30">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="h-5 w-5 text-purple-400" />
            Express Distribution
          </CardTitle>
          <Badge className="bg-gradient-to-r from-purple-600 to-pink-600">
            1-2 Days
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Timeline */}
          <div className="space-y-3">
            {statusSteps.map((step, idx) => {
              const Icon = step.icon;
              const isActive = idx <= currentStepIndex;
              const isCurrent = step.id === distribution.processing_status;

              return (
                <div key={step.id} className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${isActive ? statusColors[step.id] : 'bg-gray-700/50 text-gray-500'}`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <span className={`font-medium ${isActive ? 'text-white' : 'text-gray-500'}`}>
                    {step.label}
                  </span>
                  {isCurrent && <span className="text-xs text-gray-400 ml-auto">Current</span>}
                </div>
              );
            })}
          </div>

          {/* Key Benefits */}
          <div className="bg-black/50 rounded-lg p-4 border border-purple-500/20">
            <h4 className="text-sm font-bold text-white mb-3">Why Express is Faster:</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-400" />
                Direct Spotify integration
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-400" />
                Automatic playlist curator pitching
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-400" />
                Hot New Artist badge
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-400" />
                Featured on home page
              </li>
            </ul>
          </div>

          {/* Estimated Live Date */}
          {distribution.estimated_live_date && (
            <div className="bg-gradient-to-r from-green-500/10 to-purple-500/10 rounded-lg p-4 border border-green-500/30">
              <p className="text-sm text-gray-400 mb-1">Estimated Live Date</p>
              <p className="text-lg font-bold text-green-400">{new Date(distribution.estimated_live_date).toLocaleDateString()}</p>
            </div>
          )}

          {/* Playlist Pitching Stats */}
          {distribution.playlist_pitch_count > 0 && (
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-black/50 rounded-lg p-4 border border-pink-500/20">
                <p className="text-sm text-gray-400 mb-1">Playlists Pitched</p>
                <p className="text-2xl font-bold text-pink-400">{distribution.playlist_pitch_count}</p>
              </div>
              <div className="bg-black/50 rounded-lg p-4 border border-green-500/20">
                <p className="text-sm text-gray-400 mb-1">Added to Playlists</p>
                <p className="text-2xl font-bold text-green-400">{distribution.playlist_adds || 0}</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}