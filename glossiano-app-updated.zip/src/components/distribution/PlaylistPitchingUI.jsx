import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Radio, CheckCircle2, AlertCircle, Send, Zap } from 'lucide-react';
import { toast } from 'sonner';

export default function PlaylistPitchingUI({ distributionId, distribution }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const queryClient = useQueryClient();

  const { data: campaigns = [] } = useQuery({
    queryKey: ['playlistCampaigns', distributionId],
    queryFn: () => base44.entities.PlaylistPitch.filter({
      distribution_id: distributionId
    }),
    enabled: !!distributionId
  });

  const generatePitch = async () => {
    if (!distribution?.genre) {
      toast.error('Genre information required');
      return;
    }

    setIsGenerating(true);
    try {
      const response = await base44.functions.invoke('aiPlaylistPitching', {
        distribution_id: distributionId,
        genres: [distribution.genre]
      });

      queryClient.invalidateQueries({ queryKey: ['playlistCampaigns', distributionId] });
      toast.success(`Found ${response.data.playlists_found} matching playlists!`);
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to generate pitch');
    } finally {
      setIsGenerating(false);
    }
  };

  const activateCampaign = async (campaignId) => {
    try {
      await base44.entities.PlaylistPitch.update(campaignId, {
        status: 'pitching'
      });
      queryClient.invalidateQueries({ queryKey: ['playlistCampaigns', distributionId] });
      toast.success('Campaign activated! Pitching to playlists...');
    } catch (error) {
      toast.error('Failed to activate campaign');
    }
  };

  return (
    <div className="space-y-6">
      {/* Generate New Campaign */}
      <Card className="border-green-500/30 bg-gradient-to-br from-green-900/20 to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-green-400" />
            AI Playlist Pitching
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 mb-4">
            Automatically pitch your music to {distribution?.genre || 'relevant'} playlists curated by approved distributors
          </p>
          <Button
            onClick={generatePitch}
            disabled={isGenerating}
            className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing Playlists...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                Generate Pitch Campaign
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Active Campaigns */}
      {campaigns.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-white">Active Campaigns</h3>
          {campaigns.map((campaign) => (
            <motion.div
              key={campaign.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="border-gray-700 bg-gray-900/40">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <CardTitle className="text-white">{campaign.release_title}</CardTitle>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          campaign.status === 'pitching' 
                            ? 'bg-green-500/20 text-green-400' 
                            : 'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {campaign.status}
                        </span>
                      </div>
                      <p className="text-gray-400 text-sm">{campaign.artist_name}</p>
                    </div>
                    {campaign.status === 'draft' && (
                      <Button
                        onClick={() => activateCampaign(campaign.id)}
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Send className="w-4 h-4 mr-2" />
                        Activate
                      </Button>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Pitch Message */}
                  <div className="bg-black/40 rounded-lg p-4 border border-gray-700">
                    <h4 className="text-sm font-semibold text-gray-300 mb-2">AI-Generated Pitch:</h4>
                    <p className="text-gray-400 text-sm italic">"{campaign.pitch_message}"</p>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-4 gap-3">
                    <div className="bg-gray-900/60 rounded-lg p-3 border border-gray-700">
                      <p className="text-gray-400 text-xs mb-1">Playlists</p>
                      <p className="text-white font-bold">{campaign.total_playlists}</p>
                    </div>
                    <div className="bg-gray-900/60 rounded-lg p-3 border border-gray-700">
                      <p className="text-gray-400 text-xs mb-1">Pitched</p>
                      <p className="text-white font-bold">{campaign.playlists_pitched}</p>
                    </div>
                    <div className="bg-gray-900/60 rounded-lg p-3 border border-gray-700">
                      <p className="text-gray-400 text-xs mb-1">Accepted</p>
                      <p className="text-green-400 font-bold">{campaign.playlists_accepted}</p>
                    </div>
                    <div className="bg-gray-900/60 rounded-lg p-3 border border-gray-700">
                      <p className="text-gray-400 text-xs mb-1">Potential Reach</p>
                      <p className="text-white font-bold">{(campaign.potential_reach / 1000).toFixed(0)}K</p>
                    </div>
                  </div>

                  {/* Playlist List Preview */}
                  <div>
                    <h4 className="text-sm font-semibold text-gray-300 mb-3">Target Playlists ({campaign.target_playlists?.length || 0})</h4>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {campaign.target_playlists?.slice(0, 10).map((playlist, idx) => (
                        <div key={idx} className="flex items-center justify-between text-sm bg-black/30 p-2 rounded border border-gray-700">
                          <div className="flex-1">
                            <p className="text-white font-medium">{playlist.playlist_name}</p>
                            <p className="text-gray-500 text-xs">{playlist.followers?.toLocaleString()} followers • {playlist.match_score.toFixed(0)}% match</p>
                          </div>
                          {playlist.status === 'accepted' ? (
                            <CheckCircle2 className="w-4 h-4 text-green-500" />
                          ) : playlist.status === 'rejected' ? (
                            <AlertCircle className="w-4 h-4 text-red-500" />
                          ) : (
                            <Radio className="w-4 h-4 text-gray-500" />
                          )}
                        </div>
                      ))}
                      {campaign.target_playlists?.length > 10 && (
                        <p className="text-gray-500 text-xs text-center py-2">
                          +{campaign.target_playlists.length - 10} more playlists
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {campaigns.length === 0 && (
        <Card className="border-gray-700 bg-gray-900/20 text-center py-8">
          <Radio className="w-12 h-12 mx-auto text-gray-600 mb-4" />
          <p className="text-gray-400">No pitch campaigns yet. Generate one to get started!</p>
        </Card>
      )}
    </div>
  );
}