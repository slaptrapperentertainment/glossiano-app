import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Sparkles, Tags, Music, Target, Zap, Share2, Copy } from 'lucide-react';
import { toast } from 'sonner';

export default function MetadataGenerator({ distributionId, distribution }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const queryClient = useQueryClient();

  const { data: metadatas = [] } = useQuery({
    queryKey: ['releaseMetadata', distributionId],
    queryFn: () => base44.entities.ReleaseMetadata.filter({
      distribution_id: distributionId
    }),
    enabled: !!distributionId
  });

  const metadata = metadatas[0];

  const generateMetadata = async () => {
    setIsGenerating(true);
    try {
      const response = await base44.functions.invoke('generateReleaseMetadata', {
        distribution_id: distributionId
      });
      
      queryClient.invalidateQueries({ queryKey: ['releaseMetadata', distributionId] });
      toast.success('Metadata generated successfully!');
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to generate metadata');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  if (!metadata) {
    return (
      <Card className="border-purple-500/30 bg-gradient-to-br from-purple-900/20 to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            AI Metadata Generator
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 mb-4">
            Automatically generate genre tags, keywords, mood descriptors, and playlist suggestions based on song analysis and market trends.
          </p>
          <Button
            onClick={generateMetadata}
            disabled={isGenerating}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing Release...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Metadata
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Summary */}
      <Card className="border-purple-500/30 bg-gradient-to-br from-purple-900/20 to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Sparkles className="w-5 h-5 text-purple-400" />
            AI-Generated Metadata
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-black/40 rounded-lg p-3 border border-purple-500/30">
              <Tags className="w-4 h-4 text-purple-400 mb-2" />
              <p className="text-gray-400 text-xs mb-1">Genre Tags</p>
              <p className="text-purple-400 font-bold text-lg">{metadata.genre_tags?.length || 0}</p>
            </div>
            <div className="bg-black/40 rounded-lg p-3 border border-purple-500/30">
              <Music className="w-4 h-4 text-purple-400 mb-2" />
              <p className="text-gray-400 text-xs mb-1">Keywords</p>
              <p className="text-purple-400 font-bold text-lg">{metadata.keywords?.length || 0}</p>
            </div>
            <div className="bg-black/40 rounded-lg p-3 border border-purple-500/30">
              <Zap className="w-4 h-4 text-purple-400 mb-2" />
              <p className="text-gray-400 text-xs mb-1">Moods</p>
              <p className="text-purple-400 font-bold text-lg">{metadata.mood_descriptors?.length || 0}</p>
            </div>
            <div className="bg-black/40 rounded-lg p-3 border border-purple-500/30">
              <Target className="w-4 h-4 text-purple-400 mb-2" />
              <p className="text-gray-400 text-xs mb-1">Playlists</p>
              <p className="text-purple-400 font-bold text-lg">{metadata.potential_playlists?.length || 0}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Metadata Tabs */}
      <Tabs defaultValue="genres" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-black/50 border border-purple-500/30">
          <TabsTrigger value="genres" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600">
            <Tags className="w-4 h-4 mr-1" />
            Genres
          </TabsTrigger>
          <TabsTrigger value="keywords" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600">
            <Music className="w-4 h-4 mr-1" />
            Keywords
          </TabsTrigger>
          <TabsTrigger value="moods" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600">
            <Zap className="w-4 h-4 mr-1" />
            Moods
          </TabsTrigger>
          <TabsTrigger value="analysis" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600">
            <Target className="w-4 h-4 mr-1" />
            Analysis
          </TabsTrigger>
        </TabsList>

        {/* Genre Tags */}
        <TabsContent value="genres" className="mt-6">
          <div className="space-y-4">
            {metadata.genre_tags?.map((genre, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-black/30 rounded-lg p-4 border border-purple-500/20"
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-white font-semibold">{genre.tag}</h4>
                  {genre.primary && (
                    <Badge className="bg-purple-500/30 text-purple-300 border-purple-500/40">PRIMARY</Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-2 bg-gray-700 rounded-full flex-1 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500" style={{ width: `${genre.confidence}%` }} />
                  </div>
                  <span className="text-gray-400 text-sm font-semibold">{genre.confidence}%</span>
                </div>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {/* Keywords */}
        <TabsContent value="keywords" className="mt-6">
          <div className="space-y-3">
            {metadata.keywords?.map((kw, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-black/30 rounded-lg p-3 border border-purple-500/20 hover:border-purple-500/40 transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-semibold">{kw.keyword}</span>
                  <Badge className={`${
                    kw.category === 'production' ? 'bg-blue-500/20 text-blue-300' :
                    kw.category === 'lyrical' ? 'bg-green-500/20 text-green-300' :
                    kw.category === 'vibe' ? 'bg-purple-500/20 text-purple-300' :
                    kw.category === 'cultural' ? 'bg-orange-500/20 text-orange-300' :
                    'bg-pink-500/20 text-pink-300'
                  } border-0`}>
                    {kw.category}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-1.5 bg-gray-700 rounded-full flex-1 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500" style={{ width: `${kw.relevance}%` }} />
                  </div>
                  <span className="text-gray-400 text-xs">{kw.relevance}%</span>
                </div>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {/* Mood Descriptors */}
        <TabsContent value="moods" className="mt-6">
          <div className="flex flex-wrap gap-3">
            {metadata.mood_descriptors?.map((mood, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.05 }}
              >
                <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white border-0 px-4 py-2 text-sm">
                  {mood}
                </Badge>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {/* Market Analysis */}
        <TabsContent value="analysis" className="mt-6 space-y-4">
          {/* Playlists */}
          <Card className="border-purple-500/30 bg-black/40">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Target className="w-5 h-5 text-purple-400" />
                Playlist Opportunities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {metadata.potential_playlists?.map((playlist, idx) => (
                <div key={idx} className="bg-black/30 rounded-lg p-3 border border-purple-500/20">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-white font-semibold">{playlist.playlist_type}</h4>
                    <Badge className="bg-purple-500/30 text-purple-300">{playlist.fit_score}%</Badge>
                  </div>
                  <p className="text-gray-400 text-sm">{playlist.reason}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Market Analysis */}
          {metadata.market_analysis && (
            <Card className="border-purple-500/30 bg-black/40">
              <CardHeader>
                <CardTitle className="text-white">Market Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-gray-400 text-sm font-semibold mb-2">Trend Alignment</p>
                  <p className="text-gray-300 text-sm">{metadata.market_analysis.trend_alignment}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm font-semibold mb-2">Comparable Artists</p>
                  <div className="flex flex-wrap gap-2">
                    {metadata.market_analysis.comparable_artists?.map((artist, idx) => (
                      <Badge key={idx} className="bg-purple-500/20 text-purple-300 border-purple-500/40">
                        {artist}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-gray-400 text-sm font-semibold mb-2">Target Audience</p>
                  <p className="text-gray-300 text-sm">{metadata.market_analysis.target_audience}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm font-semibold mb-2">Release Timing</p>
                  <p className="text-gray-300 text-sm">{metadata.market_analysis.release_timing_notes}</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* SEO Metadata */}
          {metadata.seo_metadata && (
            <Card className="border-purple-500/30 bg-black/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Share2 className="w-5 h-5 text-purple-400" />
                  SEO & Social Media
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-gray-400 text-xs uppercase font-semibold mb-2">Meta Title</p>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={metadata.seo_metadata.meta_title}
                      readOnly
                      className="flex-1 bg-black/50 text-gray-300 text-sm px-3 py-2 rounded border border-purple-500/20"
                    />
                    <button onClick={() => copyToClipboard(metadata.seo_metadata.meta_title)} className="text-purple-400 hover:text-purple-300">
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div>
                  <p className="text-gray-400 text-xs uppercase font-semibold mb-2">Meta Description</p>
                  <div className="flex items-center gap-2">
                    <textarea
                      value={metadata.seo_metadata.meta_description}
                      readOnly
                      className="flex-1 bg-black/50 text-gray-300 text-sm px-3 py-2 rounded border border-purple-500/20 resize-none"
                      rows="2"
                    />
                    <button onClick={() => copyToClipboard(metadata.seo_metadata.meta_description)} className="text-purple-400 hover:text-purple-300 self-start mt-2">
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div>
                  <p className="text-gray-400 text-xs uppercase font-semibold mb-2">Hashtags</p>
                  <div className="bg-black/50 rounded border border-purple-500/20 p-3">
                    <p className="text-gray-300 text-sm flex flex-wrap gap-2">
                      {metadata.seo_metadata.hashtags?.join(' ')}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}