import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingUp, DollarSign, Music2, Eye, ExternalLink, RefreshCw, ChevronDown, ChevronUp, Globe, Zap } from 'lucide-react';
import { toast } from 'sonner';
import PlaylistPitchingUI from './PlaylistPitchingUI';
import AICampaignBuilder from '@/components/marketing/AICampaignBuilder';
import AIArtistScouting from '@/components/ar/AIArtistScouting';
import ReviewAnalysisDashboard from '@/components/ar/ReviewAnalysisDashboard';
import MetadataGenerator from './MetadataGenerator';

export default function DistributionDashboard() {
  const [expandedRelease, setExpandedRelease] = useState(null);
  const { data: distributions = [], refetch } = useQuery({
    queryKey: ['distributions'],
    queryFn: async () => {
      const user = await base44.auth.me();
      if (!user) return [];
      return base44.entities.Distribution.filter({}, '-created_date') || [];
    },
    initialData: []
  });

  const handleSyncStats = async () => {
    try {
      toast.loading('Syncing latest stats...');
      await base44.functions.invoke('syncDistributionStats');
      await refetch();
      toast.success('Stats updated successfully!');
    } catch (error) {
      toast.error('Failed to sync stats');
    }
  };

  const totalStreams = distributions.reduce((sum, d) => sum + (d.total_streams || 0), 0);
  const totalEarnings = distributions.reduce((sum, d) => sum + (d.estimated_earnings || 0), 0);

  const getStatusColor = (status) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800',
      processing: 'bg-blue-100 text-blue-800',
      live: 'bg-green-100 text-green-800',
      failed: 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-300 flex items-center gap-2">
              <Music2 className="h-4 w-4" />
              Total Releases
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{distributions.length}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-300 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Total Streams
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{totalStreams.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-300 flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Estimated Earnings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-400">${totalEarnings.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white">Your Releases</CardTitle>
            <Button
              onClick={handleSyncStats}
              variant="outline"
              size="sm"
              className="border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/10"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Sync Stats
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {distributions.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Music2 className="h-16 w-16 mx-auto mb-4 opacity-30" />
              <p>No releases yet. Submit your first distribution!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {distributions.map((dist) => (
                <div key={dist.id} className="bg-black/50 border border-yellow-500/30 rounded-lg">
                  <div className="p-4 flex items-start gap-4 cursor-pointer hover:bg-black/30 transition-colors" onClick={() => setExpandedRelease(expandedRelease === dist.id ? null : dist.id)}>
                    <img
                      src={dist.cover_art_url}
                      alt={dist.release_title}
                      className="w-20 h-20 rounded object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="text-lg font-bold text-white">{dist.release_title}</h3>
                          <p className="text-yellow-400 text-sm">{dist.artist_name}</p>
                        </div>
                        <Badge className={getStatusColor(dist.status)}>
                          {dist.status}
                        </Badge>
                      </div>
                      
                      <div className="flex gap-4 text-sm text-gray-400 mb-3">
                        <span>{dist.release_type}</span>
                        <span>•</span>
                        <span>{dist.genre}</span>
                        <span>•</span>
                        <span>{new Date(dist.release_date).toLocaleDateString()}</span>
                      </div>

                      {dist.status === 'live' && (
                       <div className="mt-2 space-y-2">
                         {dist.total_platforms_distributed > 0 && (
                           <div className="flex items-center gap-2 text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded">
                             <Globe className="h-3 w-3" />
                             <span>Live on {dist.total_platforms_distributed} platforms</span>
                           </div>
                         )}
                         {dist.platform_urls && Object.entries(dist.platform_urls).slice(0, 5).map(([platform, url]) => (
                           <a 
                             key={platform} 
                             href={url} 
                             target="_blank" 
                             rel="noopener noreferrer" 
                             className="text-xs text-yellow-400 hover:text-yellow-300 flex items-center gap-1 hover:underline"
                           >
                             {platform.replace('_', ' ').toUpperCase()} <ExternalLink className="h-3 w-3" />
                           </a>
                         ))}
                         {dist.total_platforms_distributed > 5 && (
                           <p className="text-xs text-gray-500">+{dist.total_platforms_distributed - 5} more platforms</p>
                         )}
                       </div>
                      )}

                      <div className="flex gap-6 mt-3 pt-3 border-t border-yellow-500/20 flex-wrap">
                        <div className="flex items-center gap-2 text-sm">
                          <Eye className="h-4 w-4 text-gray-400" />
                          <span className="text-white">{(dist.total_streams || 0).toLocaleString()}</span>
                          <span className="text-gray-500">streams</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <DollarSign className="h-4 w-4 text-green-400" />
                          <span className="text-white">${(dist.estimated_earnings || 0).toFixed(2)}</span>
                        </div>
                        {dist.playlist_pitch_count > 0 && (
                          <div className="flex items-center gap-2 text-sm">
                            <Zap className="h-4 w-4 text-pink-400" />
                            <span className="text-white">{dist.playlist_pitch_count}</span>
                            <span className="text-gray-500">curator pitches</span>
                          </div>
                        )}
                      </div>
                      <div className="text-right">
                        {expandedRelease === dist.id ? (
                          <ChevronUp className="h-5 w-5 text-yellow-400" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {/* Expanded Tools Section */}
                  {expandedRelease === dist.id && (
                    <div className="border-t border-yellow-500/20 p-4 bg-black/30 space-y-6">
                      <MetadataGenerator distributionId={dist.id} distribution={dist} />
                      <div className="border-t border-yellow-500/20 pt-6">
                        <PlaylistPitchingUI distributionId={dist.id} distribution={dist} />
                      </div>
                      <div className="border-t border-yellow-500/20 pt-6">
                        <AICampaignBuilder distributionId={dist.id} distribution={dist} />
                      </div>
                      <div className="border-t border-yellow-500/20 pt-6">
                        <AIArtistScouting distributionId={dist.id} distribution={dist} />
                      </div>
                      <div className="border-t border-yellow-500/20 pt-6">
                        <ReviewAnalysisDashboard distributionId={dist.id} distribution={dist} />
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}