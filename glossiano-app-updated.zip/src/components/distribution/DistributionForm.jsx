import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, Music, Calendar, Check, Info } from 'lucide-react';
import { toast } from 'sonner';
import MixmeaMastering from './MixmeaMastering';
import HelpTooltip from '@/components/common/HelpTooltip';

export default function DistributionForm({ track }) {
  const [formData, setFormData] = useState({
    artist_name: track?.artist || '',
    release_title: track?.title || '',
    release_type: 'single',
    genre: track?.genre || '',
    release_date: '',
    audio_file_url: track?.audio_url || '',
    cover_art_url: track?.cover_image || '',
    lyrics: '',
    isrc: '',
    upc: ''
  });
  const [audioFile, setAudioFile] = useState(null);
  const [coverFile, setCoverFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [selectedPlatforms, setSelectedPlatforms] = useState([
    'spotify', 'apple_music', 'amazon_music', 'youtube_music', 'tidal', 'deezer',
    'bandcamp', 'soundcloud', 'shazam', 'pandora', 'iheartradio', 'instagram', 'facebook', 'tiktok'
  ]);

  const platforms = [
    { id: 'spotify', name: 'Spotify', icon: '🎵', category: 'Streaming' },
    { id: 'apple_music', name: 'Apple Music', icon: '🍎', category: 'Streaming' },
    { id: 'amazon_music', name: 'Amazon Music', icon: '📦', category: 'Streaming' },
    { id: 'youtube_music', name: 'YouTube Music', icon: '▶️', category: 'Streaming' },
    { id: 'tidal', name: 'Tidal', icon: '🌊', category: 'Streaming' },
    { id: 'deezer', name: 'Deezer', icon: '🎧', category: 'Streaming' },
    { id: 'pandora', name: 'Pandora', icon: '📻', category: 'Streaming' },
    { id: 'iheartradio', name: 'iHeartRadio', icon: '📻', category: 'Radio' },
    { id: 'soundcloud', name: 'SoundCloud', icon: '☁️', category: 'Indie' },
    { id: 'bandcamp', name: 'Bandcamp', icon: '🎸', category: 'Indie' },
    { id: 'shazam', name: 'Shazam', icon: '✨', category: 'Discovery' },
    { id: 'instagram', name: 'Instagram', icon: '📷', category: 'Social' },
    { id: 'facebook', name: 'Facebook', icon: '👥', category: 'Social' },
    { id: 'tiktok', name: 'TikTok', icon: '🎬', category: 'Social' }
  ];

  const handleAudioUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setAudioFile(file);
    setIsUploading(true);
    try {
      const { data } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, audio_file_url: data.file_url });
      toast.success('Audio uploaded successfully!');
    } catch (error) {
      toast.error('Failed to upload audio');
    }
    setIsUploading(false);
  };

  const handleCoverUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setCoverFile(file);
    setIsUploading(true);
    try {
      const { data } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, cover_art_url: data.file_url });
      toast.success('Cover art uploaded successfully!');
    } catch (error) {
      toast.error('Failed to upload cover art');
    }
    setIsUploading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.audio_file_url || !formData.cover_art_url) {
      toast.error('Please upload both audio and cover art');
      return;
    }

    setIsSubmitting(true);
    try {
      const { data } = await base44.functions.invoke('submitDistribution', {
        ...formData,
        platforms: selectedPlatforms
      });
      toast.success('Release submitted to 40+ platforms! Check your dashboard for live links.');
      
      // Reset form
      setFormData({
        artist_name: '',
        release_title: '',
        release_type: 'single',
        genre: '',
        release_date: '',
        audio_file_url: '',
        cover_art_url: '',
        lyrics: '',
        isrc: '',
        upc: ''
      });
      setAudioFile(null);
      setCoverFile(null);
    } catch (error) {
      toast.error('Failed to submit release. Please try again.');
    }
    setIsSubmitting(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
        <CardHeader>
          <CardTitle className="text-2xl text-white flex items-center gap-2">
            <Music className="h-6 w-6 text-yellow-400" />
            Release Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Label className="text-gray-300">Artist Name *</Label>
                  <HelpTooltip text="The artist name that will appear on all platforms" />
                </div>
                {formData.artist_name && <span className="text-xs text-yellow-400">{formData.artist_name.length} chars</span>}
              </div>
              <Input
                required
                value={formData.artist_name}
                onChange={(e) => setFormData({ ...formData, artist_name: e.target.value })}
                className={`bg-black/50 text-white transition-all ${formData.artist_name ? 'border-yellow-400 shadow-lg shadow-yellow-500/20' : 'border-yellow-500/30'}`}
                placeholder="Your artist name"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Label className="text-gray-300">Release Title *</Label>
                  <HelpTooltip text="The name of your song, single, EP, or album" />
                </div>
                {formData.release_title && <span className="text-xs text-yellow-400">{formData.release_title.length} chars</span>}
              </div>
              <Input
                required
                value={formData.release_title}
                onChange={(e) => setFormData({ ...formData, release_title: e.target.value })}
                className={`bg-black/50 text-white transition-all ${formData.release_title ? 'border-yellow-400 shadow-lg shadow-yellow-500/20' : 'border-yellow-500/30'}`}
                placeholder="Single or album name"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label className="text-gray-300">Release Type *</Label>
                <HelpTooltip text="Single: 1 track | EP: 2-6 tracks | Album: 7+ tracks" />
              </div>
              <Select value={formData.release_type} onValueChange={(value) => setFormData({ ...formData, release_type: value })}>
                <SelectTrigger className="bg-black/50 border-yellow-500/30 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="single">Single</SelectItem>
                  <SelectItem value="ep">EP (2-6 tracks)</SelectItem>
                  <SelectItem value="album">Album (7+ tracks)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Label className="text-gray-300">Genre *</Label>
                  <HelpTooltip text="Choose your primary genre for better platform placement" />
                </div>
                {formData.genre && <span className="text-xs text-yellow-400">{formData.genre.length} chars</span>}
              </div>
              <Input
                required
                value={formData.genre}
                onChange={(e) => setFormData({ ...formData, genre: e.target.value })}
                className={`bg-black/50 text-white transition-all ${formData.genre ? 'border-yellow-400 shadow-lg shadow-yellow-500/20' : 'border-yellow-500/30'}`}
                placeholder="Hip-Hop, Rap, etc."
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label className="text-gray-300">Release Date *</Label>
                <HelpTooltip text="When your music goes live globally" />
              </div>
              <Input
                type="date"
                required
                value={formData.release_date}
                onChange={(e) => setFormData({ ...formData, release_date: e.target.value })}
                className="bg-black/50 border-yellow-500/30 text-white [color-scheme:dark]"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label className="text-gray-300">Lyrics (Optional)</Label>
              {formData.lyrics && <span className="text-xs text-yellow-400">{formData.lyrics.split(' ').length} words</span>}
            </div>
            <Textarea
              value={formData.lyrics}
              onChange={(e) => setFormData({ ...formData, lyrics: e.target.value })}
              className={`bg-black/50 text-white h-32 transition-all ${formData.lyrics ? 'border-yellow-400 shadow-lg shadow-yellow-500/20' : 'border-yellow-500/30'}`}
              placeholder="Paste your lyrics here..."
            />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
        <CardHeader>
          <CardTitle className="text-2xl text-white flex items-center gap-2">
            <Upload className="h-6 w-6 text-yellow-400" />
            Upload Files
          </CardTitle>
          <p className="text-gray-400 text-sm mt-2">High-quality audio and cover art ensure your music sounds best on all platforms</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Audio File * (WAV, MP3, FLAC)</Label>
              <div className="border-2 border-dashed border-yellow-500/30 rounded-lg p-6 text-center hover:border-yellow-500/60 transition-colors">
                <input
                  type="file"
                  accept="audio/*"
                  onChange={handleAudioUpload}
                  className="hidden"
                  id="audio-upload"
                />
                <label htmlFor="audio-upload" className="cursor-pointer">
                  <Music className="h-12 w-12 mx-auto mb-2 text-yellow-400" />
                  <p className="text-white text-sm">
                    {audioFile ? audioFile.name : 'Click to upload audio'}
                  </p>
                  {formData.audio_file_url && (
                    <Check className="h-6 w-6 mx-auto mt-2 text-green-400" />
                  )}
                </label>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-300">Cover Art * (3000x3000px JPG/PNG)</Label>
              <div className="border-2 border-dashed border-yellow-500/30 rounded-lg p-6 text-center hover:border-yellow-500/60 transition-colors">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleCoverUpload}
                  className="hidden"
                  id="cover-upload"
                />
                <label htmlFor="cover-upload" className="cursor-pointer">
                  {coverFile ? (
                    <img src={URL.createObjectURL(coverFile)} alt="Cover" className="h-24 w-24 mx-auto mb-2 object-cover rounded" />
                  ) : (
                    <Upload className="h-12 w-12 mx-auto mb-2 text-yellow-400" />
                  )}
                  <p className="text-white text-sm">
                    {coverFile ? coverFile.name : 'Click to upload cover'}
                  </p>
                  {formData.cover_art_url && (
                    <Check className="h-6 w-6 mx-auto mt-2 text-green-400" />
                  )}
                </label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {formData.audio_file_url && (
        <MixmeaMastering 
          audioFile={{ name: audioFile?.name, file_url: formData.audio_file_url }}
          onMasteringSubmit={(data) => {
            toast.success(`Mastering submitted! Order: ${data.mastering_id}`);
          }}
        />
      )}

      <Card className="bg-gradient-to-br from-pink-900/40 to-black border-yellow-500/40">
        <CardHeader>
          <CardTitle className="text-2xl text-white flex items-center gap-2">
            Distribution Platforms
            <HelpTooltip text="Select where your music goes live. All major platforms are pre-selected. Remove any you don't want." />
          </CardTitle>
          <p className="text-gray-400 text-sm">40+ platforms available. Reach 2B+ listeners globally 🌍</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {['Streaming', 'Radio', 'Indie', 'Discovery', 'Social'].map(category => (
            <div key={category}>
              <p className="text-yellow-400 font-bold text-sm mb-2">{category}</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {platforms.filter(p => p.category === category).map((platform) => (
                  <button
                    key={platform.id}
                    onClick={() => setSelectedPlatforms(
                      selectedPlatforms.includes(platform.id)
                        ? selectedPlatforms.filter(p => p !== platform.id)
                        : [...selectedPlatforms, platform.id]
                    )}
                    className={`p-3 rounded-lg border transition-all ${
                      selectedPlatforms.includes(platform.id)
                        ? 'bg-gradient-to-r from-pink-600 to-yellow-500 border-pink-400'
                        : 'bg-black/50 border-yellow-500/30 hover:border-yellow-500/60'
                    }`}
                  >
                    <div className="text-2xl mb-1">{platform.icon}</div>
                    <p className={`text-xs ${selectedPlatforms.includes(platform.id) ? 'text-white' : 'text-gray-300'}`}>
                      {platform.name}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          ))}
          <p className="text-gray-500 text-xs mt-4">
            Selected: {selectedPlatforms.length} platforms
          </p>
        </CardContent>
      </Card>

      <Button
        type="submit"
        disabled={isUploading || isSubmitting}
        className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 py-6 text-lg"
      >
        {isSubmitting ? 'Submitting...' : 'Submit for Distribution'}
      </Button>
    </form>
  );
}