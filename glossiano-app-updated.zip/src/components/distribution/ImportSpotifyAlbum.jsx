import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Music, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ImportSpotifyAlbum() {
  const [albumUrl, setAlbumUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const extractAlbumId = (url) => {
    const match = url.match(/album\/([a-zA-Z0-9]+)/);
    return match ? match[1] : null;
  };

  const handleImport = async () => {
    const albumId = extractAlbumId(albumUrl);
    
    if (!albumId) {
      toast.error('Invalid Spotify album URL. Please paste a valid album link.');
      return;
    }

    setIsLoading(true);
    try {
      const response = await base44.functions.invoke('importSpotifyAlbum', { albumId });
      
      toast.success(`Imported ${response.data.tracks_imported} tracks from "${response.data.album_name}"`);
      setAlbumUrl('');
    } catch (err) {
      toast.error(err.message || 'Failed to import album');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Music className="h-5 w-5 text-amber-500" />
          Import Spotify Album
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-gray-400">
          Paste a Spotify album link to import all tracks into your library.
        </p>
        <div className="flex gap-2">
          <Input
            placeholder="https://open.spotify.com/album/..."
            value={albumUrl}
            onChange={(e) => setAlbumUrl(e.target.value)}
            disabled={isLoading}
            className="bg-slate-700 border-slate-600"
          />
          <Button
            onClick={handleImport}
            disabled={isLoading || !albumUrl}
            className="bg-amber-500 hover:bg-amber-600 whitespace-nowrap"
          >
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Importing...
              </>
            ) : (
              'Import'
            )}
          </Button>
        </div>
        <p className="text-xs text-gray-500">
          Only album links work. Extract track metadata and cover art from Spotify.
        </p>
      </CardContent>
    </Card>
  );
}