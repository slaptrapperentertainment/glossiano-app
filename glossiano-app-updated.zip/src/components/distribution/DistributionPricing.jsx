import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Check, Zap, Crown, Rocket } from 'lucide-react';

export default function DistributionPricing() {
  const tiers = [
    {
      name: 'Starter',
      price: 4.99,
      period: '/release',
      description: 'Perfect for single releases',
      icon: Zap,
      color: 'from-blue-600 to-cyan-600',
      features: [
        'Unlimited music stores',
        'Automatic royalty payments',
        '90+ platforms included',
        'ISRC & UPC generation',
        'Basic analytics',
        'Email support'
      ],
      cta: 'Get Started',
      popular: false
    },
    {
      name: 'Pro',
      price: 7.99,
      period: '/year',
      description: 'Best for active artists',
      icon: Rocket,
      color: 'from-pink-600 to-orange-600',
      features: [
        'Unlimited releases & updates',
        'Priority distribution',
        'Advanced analytics dashboard',
        'Playlist pitch tool',
        'Social media integration',
        'Priority support',
        'Early access to features'
      ],
      cta: 'Choose Pro',
      popular: true
    },
    {
      name: 'Label',
      price: 19.99,
      period: '/year',
      description: 'For labels & teams',
      icon: Crown,
      color: 'from-purple-600 to-pink-600',
      features: [
        'Everything in Pro',
        'Multiple artist management',
        'Team collaboration tools',
        'Advanced royalty splitting',
        'Custom branding',
        'API access',
        'Dedicated account manager',
        'Video distribution'
      ],
      cta: 'Contact Sales',
      popular: false
    }
  ];

  return (
    <div className="py-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Distribution That Won't Break the Bank
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Better prices than DistroKid. Keep 100% of your royalties. Distribute to 90+ platforms instantly.
          </p>
          
          {/* Price Comparison */}
          <div className="mt-8 inline-block bg-gray-900/50 border border-green-500/30 rounded-lg p-4">
            <p className="text-sm text-gray-300 mb-2">vs DistroKid</p>
            <div className="flex gap-8 items-center">
              <div>
                <p className="text-xs text-gray-400">DistroKid</p>
                <p className="text-2xl font-bold text-gray-300">$12/year</p>
              </div>
              <p className="text-green-400 font-bold">We're 33% cheaper</p>
              <div>
                <p className="text-xs text-gray-400">Our Pro Plan</p>
                <p className="text-2xl font-bold text-green-400">$7.99/year</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {tiers.map((tier, idx) => {
            const Icon = tier.icon;
            return (
              <motion.div
                key={tier.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className={tier.popular ? 'md:scale-105' : ''}
              >
                <Card className={`h-full border-2 ${tier.popular ? 'border-green-500/60 bg-gradient-to-b from-green-900/20 to-black' : 'border-gray-700 bg-gray-900/30'} relative overflow-hidden`}>
                  {tier.popular && (
                    <div className="absolute top-0 right-0 bg-gradient-to-r from-green-500 to-emerald-500 text-black text-xs font-bold px-4 py-1 rounded-bl-lg">
                      MOST POPULAR
                    </div>
                  )}

                  <CardHeader>
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <CardTitle className="text-2xl text-white mb-2">{tier.name}</CardTitle>
                        <p className="text-sm text-gray-400">{tier.description}</p>
                      </div>
                      <div className={`p-3 rounded-lg bg-gradient-to-br ${tier.color}`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                    </div>

                    <div className="py-4 border-y border-gray-700">
                      <div className="flex items-baseline gap-1">
                        <span className="text-4xl font-bold text-white">${tier.price}</span>
                        <span className="text-gray-400">{tier.period}</span>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-6">
                    <ul className="space-y-3">
                      {tier.features.map((feature, fidx) => (
                        <li key={fidx} className="flex items-start gap-3">
                          <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-300 text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <Button
                      className={`w-full ${tier.popular 
                        ? 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700' 
                        : 'bg-gray-700 hover:bg-gray-600'} text-white`}
                    >
                      {tier.cta}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* What's Included */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gray-900/40 border border-gray-700 rounded-lg p-8"
        >
          <h3 className="text-2xl font-bold text-white mb-8">All Plans Include</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { title: '100% Royalty Ownership', desc: 'You keep every penny of your earnings' },
              { title: '90+ Platforms', desc: 'Spotify, Apple Music, YouTube, and more' },
              { title: 'Instant Publishing', desc: 'Get your music live within 24 hours' },
              { title: 'Real-time Analytics', desc: 'Track streams, revenue, and demographics' },
              { title: 'Royalty Splitting', desc: 'Automatically pay collaborators' },
              { title: 'No Hidden Fees', desc: 'What you see is what you pay' }
            ].map((item, idx) => (
              <div key={idx} className="flex gap-4">
                <div className="w-1 bg-gradient-to-b from-green-500 to-emerald-500 rounded-full flex-shrink-0"></div>
                <div>
                  <h4 className="text-white font-semibold mb-1">{item.title}</h4>
                  <p className="text-gray-400 text-sm">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}