import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Music, Upload, Zap, TrendingUp, Globe } from 'lucide-react';

export default function DistributionOnboarding({ onStart }) {
  const [step, setStep] = useState(0);

  const steps = [
    {
      icon: Music,
      title: "Upload Your Music",
      description: "Choose your audio file and cover art. We accept all major formats."
    },
    {
      icon: Globe,
      title: "Select Platforms",
      description: "Pick which streaming services you want to distribute to. Spotify, Apple Music, YouTube, and more."
    },
    {
      icon: Zap,
      title: "Set Release Date",
      description: "Choose when your music goes live. We'll handle all the technical details."
    },
    {
      icon: TrendingUp,
      title: "Track Analytics",
      description: "Monitor streams, earnings, and performance across all platforms in real-time."
    }
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <h2 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-yellow-500">
          Get Your Music on Every Platform
        </h2>
        <p className="text-gray-300 text-lg max-w-2xl mx-auto">
          Upload once. Distribute to Spotify, Apple Music, YouTube Music, Amazon Music, and 100+ more platforms. Keep 100% of your royalties.
        </p>
      </motion.div>

      {/* How It Works */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 my-12">
        {steps.map((item, idx) => {
          const Icon = item.icon;
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <Card className="bg-gradient-to-br from-pink-900/20 to-black border-yellow-500/20 h-full">
                <CardContent className="pt-6 text-center space-y-3">
                  <div className="flex justify-center">
                    <div className="bg-gradient-to-br from-pink-500 to-yellow-400 p-3 rounded-lg">
                      <Icon className="h-6 w-6 text-black" />
                    </div>
                  </div>
                  <h3 className="text-white font-bold text-sm">{idx + 1}. {item.title}</h3>
                  <p className="text-gray-400 text-xs">{item.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Key Benefits */}
      <Card className="bg-gradient-to-br from-yellow-900/20 to-black border-yellow-500/40">
        <CardContent className="pt-6">
          <h3 className="text-white font-bold text-lg mb-6">Why Slap Trapper Distribution?</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              { title: "Keep 100% of Royalties", desc: "We don't take a cut. All earnings go directly to you." },
              { title: "Instant Global Distribution", desc: "Reach 2B+ listeners across all major platforms instantly." },
              { title: "Real-Time Analytics", desc: "Track streams, earnings, and growth in your dashboard." },
              { title: "No Monthly Fees", desc: "One-time per release. No hidden charges or subscriptions." },
              { title: "24/7 Support", desc: "Get help whenever you need it from our team." },
              { title: "Express Distribution", desc: "Get live in 1-2 days instead of weeks." }
            ].map((benefit, idx) => (
              <div key={idx} className="flex gap-3">
                <CheckCircle className="h-5 w-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-semibold text-sm">{benefit.title}</p>
                  <p className="text-gray-400 text-xs">{benefit.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="text-center"
      >
        <Button
          onClick={onStart}
          className="bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white px-12 py-6 text-lg font-bold rounded-full shadow-2xl shadow-pink-500/50"
        >
          <Upload className="mr-2 h-5 w-5" />
          Start Distributing Now
        </Button>
        <p className="text-gray-400 text-sm mt-4">
          Takes just 5 minutes to upload and go live 🎵
        </p>
      </motion.div>

      {/* FAQ Preview */}
      <Card className="bg-black/30 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Quick Questions?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm">
          <div>
            <p className="text-yellow-400 font-semibold mb-1">Which platforms will my music be on?</p>
            <p className="text-gray-400">Spotify, Apple Music, YouTube Music, Amazon Music, Tidal, Deezer, Pandora, SoundCloud, and 100+ more.</p>
          </div>
          <div>
            <p className="text-yellow-400 font-semibold mb-1">How long does it take to go live?</p>
            <p className="text-gray-400">Standard: 3-5 business days. Express: 1-2 days for an additional fee.</p>
          </div>
          <div>
            <p className="text-yellow-400 font-semibold mb-1">Do you take a percentage of earnings?</p>
            <p className="text-gray-400">No. You keep 100% of all streaming royalties. We only charge a one-time distribution fee.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}