import React from 'react';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Play } from 'lucide-react';
import { useCart } from '@/components/cart/CartContext';
import { toast } from 'sonner';

export default function QuickBuyWidget({ track, onPlay, isPlaying }) {
  const { addToCart } = useCart();

  const handleQuickBuy = (e) => {
    e.stopPropagation();
    if (track.for_sale && track.price) {
      addToCart({
        id: track.id,
        title: track.title,
        price: track.price,
        artist: track.artist,
        image: track.cover_image
      });
      toast.success(`✅ "${track.title}" added to cart!`);
    }
  };

  return (
    <div className="flex gap-2 w-full">
      <Button
        onClick={onPlay}
        size="sm"
        className="flex-1 bg-black/50 hover:bg-black/70 border border-yellow-500/30 text-yellow-400 hover:text-yellow-300"
      >
        <Play className="h-4 w-4 mr-1" />
        {isPlaying ? 'Playing' : 'Play'}
      </Button>
      {track.for_sale && track.price && (
        <Button
          onClick={handleQuickBuy}
          size="sm"
          className="flex-1 bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white font-bold"
        >
          <ShoppingCart className="h-4 w-4 mr-1" />
          ${track.price}
        </Button>
      )}
    </div>
  );
}