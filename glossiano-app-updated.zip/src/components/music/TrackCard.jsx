import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, Pause, Lock } from 'lucide-react';

export default function TrackCard({ track, isMemberOnly = false }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audio] = useState(new Audio(track.audio_url));

  const handlePlayPause = () => {
    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  };

  React.useEffect(() => {
    const handleEnded = () => setIsPlaying(false);
    audio.addEventListener('ended', handleEnded);
    return () => audio.removeEventListener('ended', handleEnded);
  }, [audio]);

  return (
    <Card className="bg-slate-800/50 border-slate-700 hover:border-amber-500 transition-colors overflow-hidden">
      <CardContent className="p-0">
        <div className="relative aspect-square bg-gradient-to-br from-slate-700 to-slate-900">
          {track.cover_image ? (
            <img
              src={track.cover_image}
              alt={track.title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <span className="text-slate-500">No cover</span>
            </div>
          )}
          <button
            onClick={handlePlayPause}
            className="absolute inset-0 flex items-center justify-center bg-black/0 hover:bg-black/40 transition-colors group"
          >
            <div className="bg-amber-500 hover:bg-amber-600 rounded-full p-3 transform group-hover:scale-110 transition-transform">
              {isPlaying ? (
                <Pause className="h-6 w-6 text-white" />
              ) : (
                <Play className="h-6 w-6 text-white ml-0.5" />
              )}
            </div>
          </button>
          {isMemberOnly && (
            <div className="absolute top-2 right-2 bg-amber-500 rounded-full p-1.5">
              <Lock className="h-4 w-4 text-white" />
            </div>
          )}
        </div>
        <div className="p-4 space-y-2">
          <h3 className="font-semibold text-white truncate">{track.title}</h3>
          <p className="text-sm text-gray-400 truncate">{track.artist}</p>
          {track.duration && (
            <p className="text-xs text-gray-500">{track.duration}</p>
          )}
          <Button
            onClick={handlePlayPause}
            variant="outline"
            className="w-full border-slate-600 text-amber-500 hover:bg-amber-500 hover:text-white mt-2"
          >
            {isPlaying ? 'Playing...' : 'Play Now'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}