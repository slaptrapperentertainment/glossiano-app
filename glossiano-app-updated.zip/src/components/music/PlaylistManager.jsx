import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Trash2, Plus, Save } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function PlaylistManager({ tracks, onLoadPlaylist }) {
  const [playlists, setPlaylists] = useState([]);
  const [showSaveForm, setShowSaveForm] = useState(false);
  const [playlistName, setPlaylistName] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadPlaylists();
  }, []);

  const loadPlaylists = async () => {
    try {
      const saved = localStorage.getItem('slap_trapper_playlists');
      if (saved) {
        setPlaylists(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Failed to load playlists:', error);
    }
  };

  const savePlaylist = async () => {
    if (!playlistName.trim()) {
      toast.error('Please enter a playlist name');
      return;
    }

    setIsSaving(true);
    try {
      const newPlaylist = {
        id: Date.now().toString(),
        name: playlistName,
        trackIds: tracks.map(t => t.id),
        trackCount: tracks.length,
        createdAt: new Date().toISOString()
      };

      const updated = [...playlists, newPlaylist];
      localStorage.setItem('slap_trapper_playlists', JSON.stringify(updated));
      setPlaylists(updated);
      setPlaylistName('');
      setShowSaveForm(false);
      toast.success(`Playlist "${playlistName}" saved!`);
    } catch (error) {
      toast.error('Failed to save playlist');
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  };

  const deletePlaylist = (id) => {
    const updated = playlists.filter(p => p.id !== id);
    localStorage.setItem('slap_trapper_playlists', JSON.stringify(updated));
    setPlaylists(updated);
    toast.success('Playlist deleted');
  };

  return (
    <div className="space-y-4 mt-6 border-t border-yellow-500/20 pt-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold text-white">My Playlists</h3>
        {!showSaveForm ? (
          <Button
            size="sm"
            onClick={() => setShowSaveForm(true)}
            className="bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border border-yellow-500/30"
          >
            <Save className="h-4 w-4 mr-2" />
            Save Playlist
          </Button>
        ) : null}
      </div>

      {showSaveForm && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex gap-2"
        >
          <Input
            placeholder="Playlist name..."
            value={playlistName}
            onChange={(e) => setPlaylistName(e.target.value)}
            className="bg-black/30 border-yellow-500/30 text-white h-9"
            onKeyPress={(e) => e.key === 'Enter' && savePlaylist()}
          />
          <Button
            size="sm"
            onClick={savePlaylist}
            disabled={isSaving}
            className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
          >
            {isSaving ? 'Saving...' : 'Save'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setShowSaveForm(false)}
            className="text-gray-400"
          >
            Cancel
          </Button>
        </motion.div>
      )}

      {playlists.length > 0 ? (
        <div className="space-y-2">
          {playlists.map(playlist => (
            <motion.button
              key={playlist.id}
              onClick={() => onLoadPlaylist(playlist)}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="w-full p-3 bg-black/30 border border-yellow-500/20 rounded-lg hover:bg-black/50 hover:border-yellow-500/40 transition-all text-left group"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-white group-hover:text-yellow-400 transition-colors">
                    {playlist.name}
                  </p>
                  <p className="text-xs text-gray-500">
                    {playlist.trackCount} songs • {new Date(playlist.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deletePlaylist(playlist.id);
                  }}
                  className="text-gray-500 hover:text-red-400 transition-colors"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </motion.button>
          ))}
        </div>
      ) : (
        <p className="text-sm text-gray-500 text-center py-4">No saved playlists yet</p>
      )}
    </div>
  );
}