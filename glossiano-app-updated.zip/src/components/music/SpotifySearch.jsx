import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Music, Play, ExternalLink, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function SpotifySearch({ onTrackSelect }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();
    
    if (!query.trim()) {
      toast.error('Please enter a search term');
      return;
    }

    setIsSearching(true);

    try {
      const response = await base44.functions.invoke('searchSpotify', {
        query: query,
        type: 'track',
        limit: 10
      });

      setResults(response.data.tracks || []);
      
      if (response.data.tracks?.length === 0) {
        toast.info('No tracks found');
      }
    } catch (error) {
      toast.error('Search failed: ' + error.message);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-green-900/30 to-black border-green-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Music className="h-6 w-6 text-green-500" />
          Spotify Music Search
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <form onSubmit={handleSearch} className="flex gap-2">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for tracks, artists..."
            className="bg-black/50 border-green-500/30 text-white flex-1"
          />
          <Button
            type="submit"
            disabled={isSearching}
            className="bg-green-600 hover:bg-green-700"
          >
            {isSearching ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" />
            )}
          </Button>
        </form>

        {results.length > 0 && (
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {results.map((track) => (
              <div
                key={track.id}
                className="flex items-center gap-3 p-3 bg-black/30 rounded-lg border border-green-500/20 hover:border-green-500/40 transition-all"
              >
                {track.cover_image && (
                  <img
                    src={track.cover_image}
                    alt={track.title}
                    className="w-12 h-12 rounded object-cover"
                  />
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">{track.title}</p>
                  <p className="text-gray-400 text-sm truncate">{track.artist}</p>
                  <p className="text-gray-500 text-xs">{track.duration}</p>
                </div>
                <div className="flex gap-2">
                  {track.preview_url && (
                    <Button
                      size="sm"
                      onClick={() => onTrackSelect?.(track)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Play className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => window.open(track.spotify_url, '_blank')}
                    className="border-green-500/30"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {results.length === 0 && !isSearching && (
          <div className="text-center py-8 text-gray-400">
            <Music className="h-12 w-12 mx-auto mb-3 opacity-30" />
            <p>Search for any track on Spotify</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}