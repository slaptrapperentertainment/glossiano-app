import React, { useState, useRef, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Music, Radio, Shuffle, Repeat, Heart } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import SpotifySearch from './SpotifySearch';
import PlaylistManager from './PlaylistManager';

export default function MusicPlayer() {
  const [currentTrack, setCurrentTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [trackSource, setTrackSource] = useState('local');
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState('off');
  const [liked, setLiked] = useState(false);
  const [playlist, setPlaylist] = useState([]);
  const audioRef = useRef(null);

  const { data: tracks = [] } = useQuery({
    queryKey: ['tracks'],
    queryFn: () => base44.entities.Track.list('-created_date'),
    initialData: [],
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    setPlaylist(tracks);
  }, [tracks]);

  useEffect(() => {
    if (playlist.length > 0 && !currentTrack) {
      setCurrentTrack(playlist[0]);
    }
  }, [playlist, currentTrack]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);
    const handleEnded = () => {
      if (trackSource === 'local') {
        if (repeatMode === 'one') {
          audio.currentTime = 0;
          audio.play();
        } else {
          handleNext();
        }
      }
    };

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('loadedmetadata', updateDuration);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('loadedmetadata', updateDuration);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [currentTrack, trackSource, repeatMode]);

  const togglePlay = () => {
    if (isPlaying) {
      audioRef.current?.pause();
    } else {
      audioRef.current?.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    if (isShuffled) {
      const randomIndex = Math.floor(Math.random() * playlist.length);
      selectTrack(playlist[randomIndex], 'local');
    } else {
      const currentIndex = playlist.findIndex(t => t.id === currentTrack?.id);
      const nextIndex = repeatMode === 'all' && currentIndex === playlist.length - 1 ? 0 : (currentIndex + 1) % playlist.length;
      selectTrack(playlist[nextIndex], 'local');
    }
  };

  const handlePrevious = () => {
    if (currentTime > 3) {
      audioRef.current.currentTime = 0;
      return;
    }
    
    if (isShuffled) {
      const randomIndex = Math.floor(Math.random() * playlist.length);
      selectTrack(playlist[randomIndex], 'local');
    } else {
      const currentIndex = playlist.findIndex(t => t.id === currentTrack?.id);
      const prevIndex = currentIndex === 0 ? playlist.length - 1 : currentIndex - 1;
      selectTrack(playlist[prevIndex], 'local');
    }
  };

  const toggleShuffle = () => {
    setIsShuffled(!isShuffled);
  };

  const toggleRepeat = () => {
    const modes = ['off', 'all', 'one'];
    const currentIndex = modes.indexOf(repeatMode);
    const nextIndex = (currentIndex + 1) % modes.length;
    setRepeatMode(modes[nextIndex]);
  };

  const toggleLike = () => {
    setLiked(!liked);
  };

  const handleSeek = (value) => {
    const newTime = value[0];
    setCurrentTime(newTime);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
    }
  };

  const handleVolumeChange = (value) => {
    const newVolume = value[0];
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
    if (newVolume === 0) {
      setIsMuted(true);
    } else {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    if (isMuted) {
      setVolume(0.5);
      audioRef.current.volume = 0.5;
    } else {
      setVolume(0);
      audioRef.current.volume = 0;
    }
    setIsMuted(!isMuted);
  };

  const formatTime = (time) => {
    if (isNaN(time)) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const selectTrack = async (track, source = 'local') => {
    setCurrentTrack(track);
    setTrackSource(source);
    setIsPlaying(true);
    setTimeout(() => audioRef.current?.play(), 100);
    
    if (source === 'local' && track.id) {
      try {
        await base44.functions.invoke('incrementPlayCount', { trackId: track.id });
      } catch (error) {
        console.error('Failed to track play count:', error);
      }
    }
  };

  const handleSpotifyTrackSelect = (spotifyTrack) => {
    if (spotifyTrack.preview_url) {
      selectTrack({
        ...spotifyTrack,
        audio_url: spotifyTrack.preview_url
      }, 'spotify');
    }
  };

  return (
    <div className="space-y-6">
      {/* Current Track Display */}
      {currentTrack && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative"
        >
          <Card className={`bg-gradient-to-br ${trackSource === 'spotify' ? 'from-green-900/40 to-black border-green-500/40' : 'from-pink-900/40 to-black border-yellow-500/40'} overflow-hidden`}>
            <div className="flex flex-col md:flex-row gap-6 p-6">
              <div className="w-full md:w-64 h-64 flex-shrink-0">
                <img
                  src={currentTrack.cover_image || 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400'}
                  alt={currentTrack.title}
                  className="w-full h-full object-cover rounded-lg shadow-2xl"
                />
              </div>

              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <h2 className="text-3xl font-bold text-white mb-2">{currentTrack.title}</h2>
                  <p className={`${trackSource === 'spotify' ? 'text-green-400' : 'text-yellow-400'} text-lg mb-2`}>{currentTrack.artist}</p>
                  {trackSource === 'spotify' && (
                    <p className="text-xs text-green-500 mb-2">🎵 Spotify Preview (30 seconds)</p>
                  )}
                  {currentTrack.album && (
                    <p className="text-gray-400 text-sm">
                      {currentTrack.album} {currentTrack.year && `• ${currentTrack.year}`}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Slider
                    value={[currentTime]}
                    max={duration || 100}
                    step={0.1}
                    onValueChange={handleSeek}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-400">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-2">
                    {trackSource === 'local' && (
                      <>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={toggleShuffle}
                          className={`text-white ${isShuffled ? 'text-yellow-400' : 'hover:text-yellow-400'}`}
                        >
                          <Shuffle className="h-5 w-5" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={handlePrevious}
                          className="text-white hover:text-yellow-400"
                        >
                          <SkipBack className="h-6 w-6" />
                        </Button>
                      </>
                    )}
                    <Button
                      size="icon"
                      onClick={togglePlay}
                      className={`w-14 h-14 ${trackSource === 'spotify' ? 'bg-green-600 hover:bg-green-700' : 'bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600'}`}
                    >
                      {isPlaying ? (
                        <Pause className="h-6 w-6" />
                      ) : (
                        <Play className="h-6 w-6 ml-1" />
                      )}
                    </Button>
                    {trackSource === 'local' && (
                      <>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={handleNext}
                          className="text-white hover:text-yellow-400"
                        >
                          <SkipForward className="h-6 w-6" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={toggleRepeat}
                          className={`text-white ${repeatMode !== 'off' ? 'text-yellow-400' : 'hover:text-yellow-400'}`}
                        >
                          <Repeat className="h-5 w-5" />
                          {repeatMode === 'one' && (
                            <span className="absolute text-[10px] font-bold">1</span>
                          )}
                        </Button>
                      </>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={toggleLike}
                      className={`text-white ${liked ? 'text-pink-500' : 'hover:text-pink-400'}`}
                    >
                      <Heart className={`h-5 w-5 ${liked ? 'fill-current' : ''}`} />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={toggleMute}
                      className="text-white hover:text-yellow-400"
                    >
                      {isMuted || volume === 0 ? (
                        <VolumeX className="h-5 w-5" />
                      ) : (
                        <Volume2 className="h-5 w-5" />
                      )}
                    </Button>
                    <Slider
                      value={[volume]}
                      max={1}
                      step={0.01}
                      onValueChange={handleVolumeChange}
                      className="w-24"
                    />
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      )}

      {/* Tabs for Local and Spotify */}
      <Tabs defaultValue="local" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-black/50 border border-pink-500/30">
          <TabsTrigger value="local" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-yellow-500">
            <Radio className="h-4 w-4 mr-2" />
            Local Tracks
          </TabsTrigger>
          <TabsTrigger value="spotify" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-600 data-[state=active]:to-green-500">
            <Music className="h-4 w-4 mr-2" />
            Spotify Search
          </TabsTrigger>
        </TabsList>

        <TabsContent value="local" className="space-y-2 mt-6">
          <h3 className="text-xl font-bold text-white mb-4">Playlist ({playlist.length})</h3>
          {playlist.length > 0 ? (
            playlist.map((track, index) => (
              <motion.div
                key={track.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <button
                  onClick={() => selectTrack(track, 'local')}
                  className={`w-full p-4 rounded-lg border transition-all ${
                    currentTrack?.id === track.id && trackSource === 'local'
                      ? 'bg-gradient-to-r from-pink-900/60 to-yellow-900/40 border-yellow-500/60'
                      : 'bg-black/30 border-yellow-500/20 hover:border-yellow-500/40 hover:bg-black/50'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 flex-shrink-0">
                      <img
                        src={track.cover_image || 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=100'}
                        alt={track.title}
                        className="w-full h-full object-cover rounded"
                      />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-medium text-white">{track.title}</p>
                      <p className="text-sm text-gray-400">{track.artist}</p>
                    </div>
                    <div className="text-sm text-gray-400">
                      {track.duration || formatTime(0)}
                    </div>
                    {track.play_count > 0 && (
                      <span className="text-xs text-gray-500">{track.play_count} plays</span>
                    )}
                  </div>
                </button>
              </motion.div>
            ))
          ) : (
            <div className="text-center py-12 text-gray-400">
              <Music className="h-16 w-16 mx-auto mb-4 opacity-30" />
              <p>No local tracks available</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="spotify" className="mt-6">
          <SpotifySearch onTrackSelect={handleSpotifyTrackSelect} />
        </TabsContent>
      </Tabs>

      <PlaylistManager
        tracks={playlist}
        onLoadPlaylist={(savedPlaylist) => {
          const playlistTracks = tracks.filter(t => savedPlaylist.trackIds.includes(t.id));
          if (playlistTracks.length > 0) {
            setPlaylist(playlistTracks);
            selectTrack(playlistTracks[0], 'local');
            toast.success(`Loaded "${savedPlaylist.name}"`);
          }
        }}
      />

      <audio
        ref={audioRef}
        src={currentTrack?.audio_url}
        preload="metadata"
      />
    </div>
  );
}