import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShoppingCart, X, ArrowRight, Music2 } from 'lucide-react';
import { useCart } from '@/components/cart/CartContext';
import { motion, AnimatePresence } from 'framer-motion';

export default function QuickCheckoutDrawer() {
  const { cart, total, removeFromCart } = useCart();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Floating Cart Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white rounded-full p-4 shadow-2xl z-40 flex items-center gap-2 hover:scale-110 transition-transform"
      >
        <ShoppingCart className="h-6 w-6" />
        {cart.length > 0 && (
          <span className="bg-white text-pink-600 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
            {cart.length}
          </span>
        )}
      </button>

      {/* Drawer */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/50 z-40"
            />

            {/* Drawer Content */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 120 }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-gradient-to-b from-black to-pink-950/30 border-l border-yellow-500/30 shadow-2xl z-50 flex flex-col"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-yellow-500/20">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5 text-yellow-400" />
                  Your Cart
                </h2>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X className="h-6 w-6 text-gray-400" />
                </button>
              </div>

              {/* Items */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {cart.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-gray-400">
                    <Music2 className="h-12 w-12 mb-2 opacity-30" />
                    <p className="text-sm">No items in cart</p>
                  </div>
                ) : (
                  cart.map((item) => (
                    <Card key={item.id} className="bg-black/50 border-yellow-500/20">
                      <CardContent className="p-4 flex gap-3">
                        {item.image && (
                          <img
                            src={item.image}
                            alt={item.title}
                            className="w-16 h-16 rounded object-cover flex-shrink-0"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <h4 className="text-white font-semibold text-sm line-clamp-2">{item.title}</h4>
                          <p className="text-yellow-400 text-xs">{item.artist}</p>
                          <p className="text-white font-bold text-sm mt-1">${item.price.toFixed(2)}</p>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="p-1 hover:bg-red-500/20 text-red-400 rounded transition-colors"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>

              {/* Footer */}
              {cart.length > 0 && (
                <div className="border-t border-yellow-500/20 p-4 space-y-3 bg-black/80">
                  <div className="flex justify-between items-center text-white">
                    <span className="font-semibold">Total:</span>
                    <span className="text-lg font-bold text-yellow-400">${total.toFixed(2)}</span>
                  </div>
                  <Link to={createPageUrl('Cart')} onClick={() => setIsOpen(false)}>
                    <Button className="w-full bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600 text-white font-bold">
                      Proceed to Checkout
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}