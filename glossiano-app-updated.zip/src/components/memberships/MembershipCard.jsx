import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Check, Star } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function MembershipCard({ 
  membership, 
  isPopular = false, 
  isCurrentTier = false,
  onSelectMonthly,
  onSelectYearly 
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -10 }}
      className={cn(
        'h-full',
        isPopular && 'md:scale-105 md:z-10'
      )}
    >
      <Card className={cn(
        'relative overflow-hidden h-full flex flex-col',
        isPopular 
          ? 'bg-gradient-to-br from-pink-900/40 to-purple-900/30 border-pink-500/60 shadow-2xl' 
          : 'bg-gradient-to-br from-gray-900/40 to-black border-gray-700/40'
      )}>
        {isPopular && (
          <div className="absolute top-0 right-0 bg-gradient-to-r from-pink-600 to-yellow-500 px-4 py-1 text-xs font-bold text-white flex items-center gap-1">
            <Star className="w-3 h-3" />
            POPULAR
          </div>
        )}

        <CardHeader>
          <CardTitle className="text-2xl text-white">{membership.tier_name}</CardTitle>
          <CardDescription className="text-gray-300 mt-2">
            {membership.description}
          </CardDescription>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col gap-6">
          {/* Pricing */}
          <div className="space-y-2">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold text-white">
                ${membership.price_monthly}
              </span>
              <span className="text-gray-400">/month</span>
            </div>
            {membership.price_yearly && (
              <p className="text-sm text-gray-400">
                or ${membership.price_yearly}/year (save {Math.round((1 - membership.price_yearly / (membership.price_monthly * 12)) * 100)}%)
              </p>
            )}
          </div>

          {/* Features */}
          <div className="space-y-3 flex-1">
            {membership.features.map((feature, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm">{feature}</span>
              </div>
            ))}

            {membership.early_access_days && (
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm">{membership.early_access_days} days early access to new music</span>
              </div>
            )}

            {membership.merch_discount > 0 && (
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm">{membership.merch_discount}% off merch</span>
              </div>
            )}

            {membership.exclusive_content && (
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm">Exclusive behind-the-scenes content</span>
              </div>
            )}

            {membership.discord_access && (
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm">Private Discord community</span>
              </div>
            )}

            {membership.meet_and_greet && (
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm">Virtual meet and greets</span>
              </div>
            )}

            {membership.monthly_bonus && (
              <div className="flex items-start gap-3 pt-2 border-t border-gray-700">
                <Star className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm font-semibold">Monthly Bonus: {membership.monthly_bonus}</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-4">
            <Button
              onClick={() => onSelectMonthly(membership.id)}
              disabled={isCurrentTier}
              className={cn(
                'w-full',
                isPopular
                  ? 'bg-gradient-to-r from-pink-600 to-yellow-500 hover:from-pink-700 hover:to-yellow-600'
                  : 'bg-gray-700 hover:bg-gray-600'
              )}
            >
              {isCurrentTier ? 'Current Plan' : 'Subscribe Monthly'}
            </Button>
            {membership.price_yearly && (
              <Button
                onClick={() => onSelectYearly(membership.id)}
                variant="outline"
                className="w-full border-gray-600 hover:bg-gray-900"
              >
                Subscribe Yearly
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}