import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { CartProvider } from '@/components/cart/CartContext';
import VisitCounter from '@/components/common/VisitCounter';
import DJPlayer from '@/components/home/DJPlayer';
import QuickCheckoutDrawer from '@/components/music/QuickCheckoutDrawer';

export default function Layout({ children }) {
  const { data: settings = [] } = useQuery({
    queryKey: ['settings'],
    queryFn: () => base44.entities.Settings.list('', 1)
  });

  const primaryColor = settings[0]?.primary_color || '#ec4899';

  return (
    <CartProvider>
    <div className="min-h-screen flex flex-col bg-black">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
        
        * {
          font-family: 'Inter', sans-serif;
        }
        
        :root {
          --color-primary: ${primaryColor};
        }

        body {
          background: #000;
        }

        .bg-amber-500, .bg-amber-600 { 
          background: linear-gradient(135deg, #ec4899 0%, #fbbf24 100%) !important; 
        }
        .hover\\:bg-amber-600:hover, .hover\\:bg-amber-700:hover { 
          background: linear-gradient(135deg, #db2777 0%, #f59e0b 100%) !important; 
        }
        .text-amber-500, .text-amber-600 { 
          color: #fbbf24 !important; 
        }
        .border-amber-500 { 
          border-color: #ec4899 !important; 
        }
      `}</style>
      <Header />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
      <DJPlayer />
      <QuickCheckoutDrawer />
      <div className="fixed bottom-6 left-6 z-30 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-lg shadow-lg">
        <VisitCounter />
      </div>
      </div>
      </CartProvider>
  );
}