export const tracks = [
  {
    id: "glossiano-apple-artist",
    title: "Glossiano Artist Page",
    artist: "Glossiano",
    apple_music_url: "https://music.apple.com/us/artist/glossiano/1815215870",
    price: 1.29,
    purchase_enabled: false
  }
];