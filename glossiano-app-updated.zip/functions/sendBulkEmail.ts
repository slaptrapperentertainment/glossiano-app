import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { emails, subject, message } = await req.json();

    if (!emails || emails.length === 0) {
      return Response.json({ error: 'No recipients provided' }, { status: 400 });
    }

    if (!subject || !message) {
      return Response.json({ error: 'Subject and message are required' }, { status: 400 });
    }

    const results = [];
    const failed = [];

    for (const email of emails) {
      try {
        await base44.integrations.Core.SendEmail({
          to: email,
          subject: subject,
          from_name: 'Slap Trapper Entertainment',
          body: message
        });
        results.push(email);
      } catch (error) {
        failed.push({ email, error: error.message });
      }
    }

    return Response.json({
      success: true,
      sent: results.length,
      failed: failed.length,
      failedEmails: failed
    });

  } catch (error) {
    console.error('Bulk email error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});