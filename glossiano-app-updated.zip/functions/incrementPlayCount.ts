import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { trackId } = await req.json();

    if (!trackId) {
      return Response.json({ error: 'Track ID required' }, { status: 400 });
    }

    const track = await base44.asServiceRole.entities.Track.get(trackId);
    
    if (!track) {
      return Response.json({ error: 'Track not found' }, { status: 404 });
    }

    const newCount = (track.play_count || 0) + 1;
    
    await base44.asServiceRole.entities.Track.update(trackId, {
      play_count: newCount
    });

    return Response.json({ success: true, play_count: newCount });

  } catch (error) {
    console.error('Play count error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});