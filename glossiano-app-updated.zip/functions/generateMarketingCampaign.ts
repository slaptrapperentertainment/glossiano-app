import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { distribution_id } = body;

    // Get distribution details
    const distribution = await base44.entities.Distribution.read(distribution_id);
    if (!distribution || distribution.created_by !== user.email) {
      return Response.json({ error: 'Distribution not found' }, { status: 404 });
    }

    // Generate campaign idea using AI
    const campaignPrompt = `Create a viral marketing campaign concept for this music release:

Artist: ${distribution.artist_name}
Title: ${distribution.release_title}
Genre: ${distribution.genre}
Release Date: ${distribution.release_date}
${distribution.lyrics ? `Song Theme: ${distribution.lyrics.substring(0, 200)}...` : ''}

Provide:
1. Campaign concept (catchy, trendy, shareable)
2. Target audience description
3. Key marketing angles that would appeal to listeners
4. Viral potential factors

Keep it concise and actionable.`;

    const campaignResponse = await base44.integrations.Core.InvokeLLM({
      prompt: campaignPrompt
    });

    // Generate social media content for each platform
    const platforms = ['instagram', 'tiktok', 'twitter', 'youtube'];
    const socialContent = [];

    for (const platform of platforms) {
      const platformPrompt = generatePlatformPrompt(platform, distribution);
      const contentResponse = await base44.integrations.Core.InvokeLLM({
        prompt: platformPrompt
      });
      
      socialContent.push({
        platform,
        content_type: 'post',
        content: contentResponse,
        suggested_visuals: getVisualSuggestion(platform, distribution),
        best_posting_time: getBestPostingTime(platform)
      });
    }

    // Generate promotion strategy
    const strategyPrompt = `Create an optimized release promotion strategy for:

Artist: ${distribution.artist_name}
Title: ${distribution.release_title}
Genre: ${distribution.genre}
Estimated Monthly Streams: 5000-10000 (conservative estimate for new release)

Provide:
1. Phased promotion timeline (pre-release, launch week, weeks 2-4)
2. Primary marketing channels to focus on
3. Recommended budget allocation (% for paid ads, influencer, organic)
4. Key milestones to track
5. Optimization tactics based on early performance

Keep it strategic and data-driven.`;

    const strategyResponse = await base44.integrations.Core.InvokeLLM({
      prompt: strategyPrompt
    });

    // Calculate expected metrics
    const expectedReach = 50000 + Math.random() * 150000;
    const estimatedConversion = 3 + Math.random() * 5;

    // Create marketing campaign
    const campaign = await base44.entities.MarketingCampaign.create({
      distribution_id,
      artist_name: distribution.artist_name,
      release_title: distribution.release_title,
      campaign_name: `${distribution.release_title} Launch Campaign`,
      campaign_idea: campaignResponse,
      target_audience: extractTargetAudience(campaignResponse),
      social_content: socialContent,
      promotion_strategy: strategyResponse,
      budget_allocation: {
        paid_ads: 0.5,
        influencer: 0.3,
        organic: 0.2
      },
      expected_reach: Math.round(expectedReach),
      estimated_conversion: Math.round(estimatedConversion * 10) / 10,
      status: 'draft'
    });

    return Response.json({
      success: true,
      campaign_id: campaign.id,
      campaign_name: campaign.campaign_name,
      expected_reach: campaign.expected_reach,
      estimated_conversion: campaign.estimated_conversion
    });

  } catch (error) {
    console.error('Error in generateMarketingCampaign:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function generatePlatformPrompt(platform, distribution) {
  const basePrompt = `Create compelling ${platform} content for this music release:

Artist: ${distribution.artist_name}
Title: ${distribution.release_title}
Genre: ${distribution.genre}`;

  const platformGuides = {
    instagram: `${basePrompt}

Generate:
1. Catchy caption (max 150 chars) with relevant emojis
2. Hashtag strategy (#music, #${distribution.genre.toLowerCase()}, #newmusic, etc.)
3. Call-to-action for listeners
4. Visual description (aesthetic, mood, color palette)`,
    
    tiktok: `${basePrompt}

Generate:
1. Hook/first 3 seconds copy (must be attention-grabbing)
2. Trend ideas (sounds, dances, challenges to use)
3. Hashtag recommendations (#FYP, #ForYouPage, etc.)
4. Video format suggestions`,
    
    twitter: `${basePrompt}

Generate:
1. Tweet (280 chars max) with urgency/excitement
2. Conversation starter questions
3. Thread ideas for deeper engagement
4. Retweet-worthy stats or facts about the release`,
    
    youtube: `${basePrompt}

Generate:
1. Video title (60 chars max, SEO-friendly)
2. Video description outline
3. Thumbnail text suggestion
4. Suggested video formats (lyric video, behind-the-scenes, audio visualizer)`
  };

  return platformGuides[platform] || basePrompt;
}

function getVisualSuggestion(platform, distribution) {
  const suggestions = {
    instagram: 'High-quality album art with artist photo overlay, vibrant colors matching genre mood',
    tiktok: 'Quick clips of song highlights, trendy transitions, on-beat cuts with captions',
    twitter: 'Album cover with bold text overlay, artist candid photo, or animated GIF',
    youtube: 'Professional video with artist performing/vibing, animated text, visual effects'
  };
  return suggestions[platform] || '';
}

function getBestPostingTime(platform) {
  const times = {
    instagram: '6-9 PM (peak engagement)',
    tiktok: '9-11 PM (high user activity)',
    twitter: '8-10 AM & 5-7 PM (business hours)',
    youtube: 'Friday 4-5 PM (weekend prep viewing)'
  };
  return times[platform] || '';
}

function extractTargetAudience(response) {
  // Extract audience info from AI response
  if (response.includes('Gen Z') || response.includes('18-24')) {
    return 'Gen Z & Young Adults (18-24), Hip-hop/Urban music fans';
  }
  return 'Music lovers interested in new releases';
}