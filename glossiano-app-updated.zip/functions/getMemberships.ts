import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Get all active membership tiers, sorted by position
    const memberships = await base44.asServiceRole.entities.Membership.filter(
      { active: true },
      'position',
      100
    );

    return Response.json({
      success: true,
      memberships: memberships.sort((a, b) => (a.position || 0) - (b.position || 0))
    });
  } catch (error) {
    console.error('Error fetching memberships:', error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});