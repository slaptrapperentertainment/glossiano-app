import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { cart, customerName, customerEmail, customerPhone, shippingAddress } = await req.json();

    // Check if user is the app owner
    const isOwner = user.email === 'slaptrapperentertainment@gmail.com';

    if (!isOwner) {
      return Response.json({ error: 'Not authorized for free orders' }, { status: 403 });
    }

    // Calculate total
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    // Create order with paid status (no payment needed)
    const order = await base44.entities.Order.create({
      customer_email: customerEmail,
      customer_name: customerName,
      customer_phone: customerPhone,
      shipping_address: shippingAddress,
      items: cart.map(item => ({
        product_id: item.id,
        title: item.title,
        price: item.price,
        quantity: item.quantity
      })),
      total_amount: total,
      status: 'paid',
      notes: 'Free order - App owner'
    });

    // Update product stock
    for (const item of cart) {
      const product = await base44.entities.Product.list('', 1, { id: item.id });
      if (product.length > 0) {
        const newStock = Math.max(0, (product[0].stock || 0) - item.quantity);
        await base44.entities.Product.update(item.id, { stock: newStock });
      }
    }

    return Response.json({
      success: true,
      orderId: order.id,
      message: 'Order processed successfully (free)'
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});