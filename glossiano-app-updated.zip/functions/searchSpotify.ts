import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { query, type = 'track', limit = 20 } = await req.json();

    if (!query) {
      return Response.json({ error: 'Search query required' }, { status: 400 });
    }

    // Get Spotify access token
    const tokenResponse = await base44.functions.invoke('getSpotifyToken');
    const { access_token } = tokenResponse.data;

    // Search Spotify
    const searchUrl = `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=${type}&limit=${limit}`;
    const response = await fetch(searchUrl, {
      headers: {
        'Authorization': `Bearer ${access_token}`
      }
    });

    const data = await response.json();

    // Format results
    const tracks = data.tracks?.items.map(track => ({
      id: track.id,
      title: track.name,
      artist: track.artists.map(a => a.name).join(', '),
      album: track.album.name,
      cover_image: track.album.images[0]?.url || '',
      preview_url: track.preview_url,
      spotify_url: track.external_urls.spotify,
      duration_ms: track.duration_ms,
      duration: `${Math.floor(track.duration_ms / 60000)}:${String(Math.floor((track.duration_ms % 60000) / 1000)).padStart(2, '0')}`
    })) || [];

    return Response.json({ tracks });

  } catch (error) {
    console.error('Spotify search error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});