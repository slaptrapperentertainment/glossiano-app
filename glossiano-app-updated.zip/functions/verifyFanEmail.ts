import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { email, name } = await req.json();

    // Check for duplicates
    const existingFans = await base44.asServiceRole.entities.Fan.filter({ email });
    
    if (existingFans.length > 0) {
      return Response.json({ 
        error: 'This email is already registered',
        isDuplicate: true 
      }, { status: 400 });
    }

    // Generate verification token
    const verificationToken = crypto.randomUUID();
    
    // Create fan with unverified status
    const fan = await base44.asServiceRole.entities.Fan.create({
      email,
      name,
      email_verified: false,
      verification_token: verificationToken,
      source: 'signup',
      subscribed: false // Not subscribed until verified
    });

    // Send verification email
    const verificationUrl = `${req.headers.get('origin')}/verify-email?token=${verificationToken}`;
    
    await base44.integrations.Core.SendEmail({
      to: email,
      subject: 'Verify Your Email - Slap Trapper Entertainment',
      from_name: 'Slap Trapper Entertainment',
      body: `
Hey ${name}!

Welcome to the Slap Trapper Entertainment family! 🎵

Please verify your email by clicking the link below:

${verificationUrl}

Once verified, you'll get:
✓ Early access to new releases
✓ Exclusive behind-the-scenes content
✓ VIP event invites
✓ West Coast hip-hop updates

If you didn't sign up for this, just ignore this email.

Stay real,
Slap Trapper Entertainment
      `
    });

    return Response.json({ 
      success: true,
      message: 'Verification email sent! Check your inbox.'
    });

  } catch (error) {
    console.error('Verification error:', error);
    return Response.json({ 
      error: error.message 
    }, { status: 500 });
  }
});