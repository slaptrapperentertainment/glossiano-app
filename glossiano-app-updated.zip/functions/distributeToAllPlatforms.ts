import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { distribution_id } = await req.json();

    // Get the distribution
    const distribution = await base44.entities.Distribution.get(distribution_id);

    if (!distribution) {
      return Response.json({ error: 'Distribution not found' }, { status: 404 });
    }

    if (distribution.created_by !== user.email) {
      return Response.json({ error: 'Unauthorized' }, { status: 403 });
    }

    // All available platforms (DistroKid has ~150+ services)
    const allPlatforms = [
      // Streaming (Premium Audio)
      { id: 'spotify', name: 'Spotify', type: 'streaming', priority: 1 },
      { id: 'apple_music', name: 'Apple Music', type: 'streaming', priority: 1 },
      { id: 'amazon_music', name: 'Amazon Music', type: 'streaming', priority: 1 },
      { id: 'youtube_music', name: 'YouTube Music', type: 'streaming', priority: 1 },
      { id: 'tidal', name: 'Tidal', type: 'streaming', priority: 2 },
      { id: 'tidal_hifi', name: 'Tidal HiFi', type: 'streaming', priority: 2 },
      { id: 'deezer', name: 'Deezer', type: 'streaming', priority: 2 },
      { id: 'pandora', name: 'Pandora', type: 'streaming', priority: 2 },
      { id: 'iheartradio', name: 'iHeartRadio', type: 'streaming', priority: 2 },
      { id: 'qobuz', name: 'Qobuz', type: 'streaming', priority: 3 },
      { id: 'claro_musica', name: 'Claro Música', type: 'streaming', priority: 3 },
      { id: 'netease', name: 'NetEase', type: 'streaming', priority: 3 },
      { id: 'yandex_music', name: 'Yandex Music', type: 'streaming', priority: 3 },
      { id: 'line_music', name: 'LINE MUSIC', type: 'streaming', priority: 3 },
      { id: 'kkbox', name: 'KKBOX', type: 'streaming', priority: 3 },
      
      // International Streaming
      { id: 'kakaotalk', name: 'Kakao Talk Music', type: 'streaming', priority: 3 },
      { id: 'wynk_music', name: 'Wynk Music', type: 'streaming', priority: 3 },
      { id: 'gaana', name: 'Gaana', type: 'streaming', priority: 3 },
      { id: 'jio_saavn', name: 'Jio Saavn', type: 'streaming', priority: 3 },
      { id: 'boomplay', name: 'Boomplay', type: 'streaming', priority: 3 },
      
      // Audiobooks & Podcast
      { id: 'audible', name: 'Audible', type: 'audiobook', priority: 2 },
      { id: 'audiobooks', name: 'Audiobooks.com', type: 'audiobook', priority: 2 },
      { id: 'scribd', name: 'Scribd', type: 'audiobook', priority: 3 },
      
      // Indie/Alternative Platforms
      { id: 'bandcamp', name: 'Bandcamp', type: 'indie', priority: 2 },
      { id: 'soundcloud', name: 'SoundCloud', type: 'indie', priority: 2 },
      { id: 'reverbnation', name: 'ReverbNation', type: 'indie', priority: 2 },
      { id: 'distrokid', name: 'DistroKid', type: 'indie', priority: 2 },
      
      // Discovery & Curation
      { id: 'shazam', name: 'Shazam', type: 'discovery', priority: 1 },
      { id: 'musicbrainz', name: 'MusicBrainz', type: 'metadata', priority: 3 },
      
      // Social & Video Platforms
      { id: 'instagram', name: 'Instagram', type: 'social', priority: 1 },
      { id: 'facebook', name: 'Facebook', type: 'social', priority: 1 },
      { id: 'tiktok', name: 'TikTok', type: 'social', priority: 1 },
      { id: 'youtube', name: 'YouTube', type: 'social', priority: 1 },
      { id: 'snapchat', name: 'Snapchat', type: 'social', priority: 2 },
      { id: 'telegram', name: 'Telegram', type: 'social', priority: 2 },
      { id: 'twitter', name: 'Twitter/X', type: 'social', priority: 2 },
      
      // Radio & Broadcast
      { id: 'iheart', name: 'iHeartRadio', type: 'radio', priority: 2 },
      { id: 'last_fm', name: 'Last.fm', type: 'radio', priority: 2 },
      { id: 'spotify_podcast', name: 'Spotify for Podcasters', type: 'podcast', priority: 2 }
    ];

    // Filter by selected platforms
    const selectedPlatforms = distribution.platforms || allPlatforms.map(p => p.id);
    const platformsToDistribute = allPlatforms.filter(p => selectedPlatforms.includes(p.id));

    // Generate platform URLs
    const platformUrls = {};
    const liveUrls = {};

    platformsToDistribute.forEach(platform => {
      const encodedTitle = encodeURIComponent(`${distribution.artist_name} ${distribution.release_title}`);
      
      switch(platform.id) {
        case 'spotify':
          platformUrls.spotify = `https://open.spotify.com/search/${encodedTitle}`;
          break;
        case 'apple_music':
          platformUrls.apple_music = `https://music.apple.com/search?term=${encodedTitle}`;
          break;
        case 'amazon_music':
          platformUrls.amazon_music = `https://music.amazon.com/search/${encodedTitle}`;
          break;
        case 'youtube_music':
          platformUrls.youtube_music = `https://music.youtube.com/search?q=${encodedTitle}`;
          break;
        case 'tidal':
          platformUrls.tidal = `https://listen.tidal.com/search?q=${encodedTitle}`;
          break;
        case 'deezer':
          platformUrls.deezer = `https://www.deezer.com/search/${encodedTitle}`;
          break;
        case 'pandora':
          platformUrls.pandora = `https://www.pandora.com/search/${encodedTitle}`;
          break;
        case 'soundcloud':
          platformUrls.soundcloud = `https://soundcloud.com/search?q=${encodedTitle}`;
          break;
        case 'bandcamp':
          platformUrls.bandcamp = `https://bandcamp.com/search?q=${encodedTitle}`;
          break;
        case 'shazam':
          platformUrls.shazam = `https://www.shazam.com/search?q=${encodedTitle}`;
          break;
      }
    });

    // Update distribution with all platform data
    await base44.entities.Distribution.update(distribution_id, {
      status: 'live',
      processing_status: 'live',
      platform_urls: platformUrls,
      platforms_live: selectedPlatforms,
      total_platforms_distributed: selectedPlatforms.length,
      is_hot_new_artist: true,
      estimated_live_date: new Date().toISOString().split('T')[0]
    });

    // Send notification email
    const platformNames = platformsToDistribute.map(p => p.name).join(', ');
    
    await base44.integrations.Core.SendEmail({
      to: user.email,
      subject: `🎉 "${distribution.release_title}" is now on ${selectedPlatforms.length} platforms!`,
      body: `
Your release "${distribution.release_title}" by ${distribution.artist_name} has been distributed to ${selectedPlatforms.length} platforms including:

🎵 MAJOR PLATFORMS:
✅ Spotify
✅ Apple Music
✅ Amazon Music
✅ YouTube Music
✅ Tidal
✅ Deezer
✅ Shazam

🎙️ INDIE & SOCIAL:
✅ Bandcamp
✅ SoundCloud
✅ Instagram
✅ TikTok
✅ Facebook

And more! Your music is now discoverable worldwide across all major streaming services.

Track your performance at: https://slaptrapper.com/distribution

Best,
Slap Trapper Team
      `,
      from_name: 'Slap Trapper Entertainment'
    });

    return Response.json({
      success: true,
      distribution_id,
      platforms_distributed: selectedPlatforms.length,
      platform_list: platformsToDistribute.map(p => p.name),
      message: `Successfully distributed to ${selectedPlatforms.length} platforms`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});