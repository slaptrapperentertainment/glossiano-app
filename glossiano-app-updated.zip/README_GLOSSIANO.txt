Glossiano App — Updated (No Base44 Required)

Run locally:
npm install
npm run dev

Deploy:
Upload to GitHub → Import into Vercel → Deploy

Edit music links:
src/data/tracks.js